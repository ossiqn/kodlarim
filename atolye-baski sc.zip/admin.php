<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] === 'update_durum') {
            $stmt = $db->prepare("UPDATE siparisler SET durum = ? WHERE id = ?");
            $stmt->execute([$_POST['durum'], $_POST['id']]);
            header("Location: admin.php?tab=siparisler&msg=ok");
            exit;
        }
        if ($_POST['action'] === 'delete_order') {
            $stmt = $db->prepare("DELETE FROM siparisler WHERE id = ?");
            $stmt->execute([$_POST['id']]);
            header("Location: admin.php?tab=siparisler&msg=deleted");
            exit;
        }
        if ($_POST['action'] === 'update_ayarlar') {
            $stmt = $db->prepare("UPDATE ayarlar SET logo_metni = ?, site_adi = ? WHERE id = 1");
            $stmt->execute([trim($_POST['logo_metni']), trim($_POST['site_adi'])]);
            header("Location: admin.php?tab=ayarlar&msg=ok");
            exit;
        }
        if ($_POST['action'] === 'delete_user') {
            $stmt = $db->prepare("DELETE FROM kullanicilar WHERE id = ? AND rol != 'admin'");
            $stmt->execute([$_POST['id']]);
            header("Location: admin.php?tab=kullanicilar&msg=deleted");
            exit;
        }
        if ($_POST['action'] === 'make_admin') {
            $stmt = $db->prepare("UPDATE kullanicilar SET rol = 'admin' WHERE id = ?");
            $stmt->execute([$_POST['id']]);
            header("Location: admin.php?tab=kullanicilar&msg=ok");
            exit;
        }
    }
}

$tab = $_GET['tab'] ?? 'dashboard';

$stats = [];
$stats['toplam_siparis'] = $db->query("SELECT COUNT(*) FROM siparisler")->fetchColumn();
$stats['bekleyen'] = $db->query("SELECT COUNT(*) FROM siparisler WHERE durum='BEKLEMEDE'")->fetchColumn();
$stats['gonderilen'] = $db->query("SELECT COUNT(*) FROM siparisler WHERE durum='BASKIYA GÖNDERİLDİ'")->fetchColumn();
$stats['tamamlanan'] = $db->query("SELECT COUNT(*) FROM siparisler WHERE durum='TAMAMLANDI'")->fetchColumn();
$stats['toplam_gelir'] = $db->query("SELECT COALESCE(SUM(fiyat),0) FROM siparisler WHERE durum!='İPTAL'")->fetchColumn();
$stats['toplam_kullanici'] = $db->query("SELECT COUNT(*) FROM kullanicilar WHERE rol='kullanici'")->fetchColumn();

$siparisler = $db->query("SELECT s.*, k.ad_soyad, k.eposta FROM siparisler s LEFT JOIN kullanicilar k ON s.kullanici_id=k.id ORDER BY s.olusturma DESC")->fetchAll(PDO::FETCH_ASSOC);
$kullanicilar = $db->query("SELECT * FROM kullanicilar ORDER BY olusturma DESC")->fetchAll(PDO::FETCH_ASSOC);

try {
    $ayarlar = $db->query("SELECT * FROM ayarlar LIMIT 1")->fetch(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $ayarlar = ['logo_metni' => 'Atölye Baskı', 'site_adi' => 'Cam Baskı Sistemi'];
}

$logo_metni = $ayarlar['logo_metni'];
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Panel — <?php echo htmlspecialchars($logo_metni); ?></title>
<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Mono:wght@300;400;500&family=Instrument+Sans:wght@400;500;600&display=swap" rel="stylesheet">
<style>
:root{--bg:#f7f5f0;--bg2:#eeeae2;--bg3:#e5e0d6;--ink:#1a1714;--ink2:#4a4540;--ink3:#8a8078;--ink4:rgba(26,23,20,.07);--acc:#2d5a27;--acc2:#3d7a35;--acc-l:rgba(45,90,39,.1);--red:#c0392b;--gold:#c8973a;--border:rgba(26,23,20,.11);--border2:rgba(26,23,20,.2);--r:6px;--r2:12px}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{background:var(--bg);color:var(--ink);font-family:'Instrument Sans',sans-serif;font-size:14px;min-height:100vh;display:flex;flex-direction:column}
.topbar{background:var(--ink);color:#f7f5f0;display:flex;align-items:center;justify-content:space-between;padding:0 32px;height:52px;flex-shrink:0}
.topbar-logo{font-family:'DM Serif Display',serif;font-size:18px;color:#f7f5f0}
.topbar-logo span{color:#a3c99a}
.topbar-right{display:flex;align-items:center;gap:12px;font-size:12px;color:rgba(247,245,240,.6)}
.topbar-right a{color:#a3c99a;text-decoration:none;font-weight:600}
.topbar-right a:hover{text-decoration:underline}

.layout{display:flex;flex:1;min-height:0}
.sidebar{width:200px;background:var(--bg2);border-right:1px solid var(--border);padding:20px 0;flex-shrink:0}
.nav-section{font-size:9px;font-weight:600;letter-spacing:1.5px;text-transform:uppercase;color:var(--ink3);padding:0 18px;margin-bottom:6px;margin-top:18px;font-family:'DM Mono',monospace}
.nav-section:first-child{margin-top:0}
.nav-item{display:flex;align-items:center;gap:9px;padding:9px 18px;font-size:13px;font-weight:500;color:var(--ink2);cursor:pointer;text-decoration:none;transition:all .15s;border-left:3px solid transparent}
.nav-item:hover{background:var(--ink4);color:var(--ink)}
.nav-item.active{color:var(--acc);background:var(--acc-l);border-left-color:var(--acc);font-weight:600}
.nav-item .badge{margin-left:auto;background:var(--red);color:#fff;font-size:9px;padding:2px 6px;border-radius:10px;font-family:'DM Mono',monospace}

.content{flex:1;padding:32px;overflow-y:auto}
.page-title{font-family:'DM Serif Display',serif;font-size:28px;margin-bottom:4px}
.page-sub{font-size:12px;color:var(--ink3);margin-bottom:28px;font-family:'DM Mono',monospace}

.stat-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:14px;margin-bottom:32px}
.stat-card{background:#fff;border:1px solid var(--border);border-radius:var(--r2);padding:20px;transition:box-shadow .2s}
.stat-card:hover{box-shadow:0 4px 16px rgba(26,23,20,.08)}
.stat-label{font-size:10px;font-weight:600;letter-spacing:1.2px;text-transform:uppercase;color:var(--ink3);margin-bottom:8px;font-family:'DM Mono',monospace}
.stat-val{font-family:'DM Serif Display',serif;font-size:32px;color:var(--ink)}
.stat-val.green{color:var(--acc)}
.stat-val.gold{color:var(--gold)}

.card{background:#fff;border:1px solid var(--border);border-radius:var(--r2);overflow:hidden;margin-bottom:20px}
.card-head{padding:16px 20px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between}
.card-title{font-size:13px;font-weight:700;color:var(--ink)}
.card-sub{font-size:11px;color:var(--ink3);font-family:'DM Mono',monospace}
table{width:100%;border-collapse:collapse}
th{padding:10px 16px;text-align:left;font-size:10px;font-weight:600;letter-spacing:1px;text-transform:uppercase;color:var(--ink3);background:var(--bg2);font-family:'DM Mono',monospace;border-bottom:1px solid var(--border)}
td{padding:12px 16px;border-bottom:1px solid var(--border);font-size:13px;vertical-align:middle}
tr:last-child td{border-bottom:none}
tr:hover td{background:rgba(247,245,240,.6)}
.thumb{width:40px;height:44px;object-fit:cover;border-radius:5px;border:1px solid var(--border);background:var(--bg3)}
.thumb-empty{width:40px;height:44px;border-radius:5px;background:var(--bg3);display:inline-block}
.status-select{font-family:'DM Mono',monospace;font-size:10px;font-weight:700;padding:4px 8px;border-radius:20px;border:1px solid transparent;cursor:pointer;outline:none;appearance:none;-webkit-appearance:none;text-align:center}
.status-select.BEKLEMEDE{background:#fef3cd;color:#8a6d0a;border-color:rgba(138,109,10,.2)}
.status-select.BASKIYA{background:#d4edda;color:var(--acc);border-color:rgba(45,90,39,.2)}
.status-select.TAMAMLANDI{background:#cce5ff;color:#004085;border-color:rgba(0,64,133,.2)}
.status-select.IPTAL{background:#f8d7da;color:var(--red);border-color:rgba(192,57,43,.2)}
.btn-sm{padding:5px 11px;border-radius:var(--r);font-size:11px;font-weight:600;border:none;cursor:pointer;transition:all .15s;font-family:'Instrument Sans',sans-serif}
.btn-danger{background:rgba(192,57,43,.1);color:var(--red)}
.btn-danger:hover{background:rgba(192,57,43,.2)}
.btn-primary{background:var(--acc-l);color:var(--acc)}
.btn-primary:hover{background:rgba(45,90,39,.18)}
.btn-main{padding:10px 20px;border-radius:var(--r);background:var(--acc);color:#fff;font-family:'Instrument Sans',sans-serif;font-size:13px;font-weight:700;border:none;cursor:pointer;transition:all .18s}
.btn-main:hover{background:var(--acc2)}

.form-group{margin-bottom:18px}
.form-label{display:block;font-size:10px;font-weight:600;letter-spacing:1px;text-transform:uppercase;color:var(--ink3);font-family:'DM Mono',monospace;margin-bottom:6px}
.form-input{width:100%;padding:10px 13px;border:1.5px solid var(--border);border-radius:var(--r);background:var(--bg);color:var(--ink);font-family:'Instrument Sans',sans-serif;font-size:13px;outline:none;transition:border-color .18s;max-width:400px;display:block}
.form-input:focus{border-color:var(--acc)}

.alert{padding:10px 16px;border-radius:var(--r);font-size:12px;margin-bottom:18px;border:1px solid;font-family:'DM Mono',monospace}
.alert-ok{background:#e8f5e4;color:var(--acc);border-color:rgba(45,90,39,.2)}
.alert-del{background:#fde8e8;color:var(--red);border-color:rgba(192,57,43,.2)}

.empty-state{padding:48px;text-align:center;color:var(--ink3);font-family:'DM Mono',monospace;font-size:13px}
.rol-badge{font-size:9px;padding:2px 8px;border-radius:10px;font-family:'DM Mono',monospace;font-weight:700}
.rol-admin{background:rgba(200,151,58,.15);color:var(--gold)}
.rol-user{background:var(--ink4);color:var(--ink3)}

.modal-overlay{position:fixed;inset:0;background:rgba(26,23,20,.6);z-index:1000;display:none;align-items:center;justify-content:center}
.modal-overlay.open{display:flex}
.modal{background:#fff;border-radius:var(--r2);padding:28px;max-width:340px;width:90%;box-shadow:0 20px 60px rgba(0,0,0,.2)}
.modal h3{font-family:'DM Serif Display',serif;font-size:20px;margin-bottom:8px}
.modal p{font-size:13px;color:var(--ink3);margin-bottom:20px}
.modal-btns{display:flex;gap:8px;justify-content:flex-end}

.sidebar-toggle{display:none}
@media(max-width:768px){
  .sidebar{display:none}
  .content{padding:20px}
  .stat-grid{grid-template-columns:1fr 1fr}
}
</style>
</head>
<body>

<div class="topbar">
  <div class="topbar-logo">◈ <span><?php echo htmlspecialchars($logo_metni); ?></span> <span style="font-size:11px;color:rgba(247,245,240,.4);font-family:'DM Mono',monospace;margin-left:8px">ADMIN</span></div>
  <div class="topbar-right">
    👤 <?php echo htmlspecialchars($_SESSION['user_name']); ?>
    &nbsp;·&nbsp;
    <a href="index.php">Stüdyoya Git</a>
    &nbsp;·&nbsp;
    <a href="logout.php">Çıkış</a>
  </div>
</div>

<div class="layout">
  <aside class="sidebar">
    <div class="nav-section">Yönetim</div>
    <a href="admin.php?tab=dashboard" class="nav-item <?php echo $tab==='dashboard'?'active':''; ?>">
      📊 Dashboard
    </a>
    <a href="admin.php?tab=siparisler" class="nav-item <?php echo $tab==='siparisler'?'active':''; ?>">
      📦 Siparişler
      <?php if($stats['bekleyen']>0): ?><span class="badge"><?php echo $stats['bekleyen']; ?></span><?php endif; ?>
    </a>
    <div class="nav-section">Ayarlar</div>
    <a href="admin.php?tab=kullanicilar" class="nav-item <?php echo $tab==='kullanicilar'?'active':''; ?>">
      👥 Kullanıcılar
    </a>
    <a href="admin.php?tab=ayarlar" class="nav-item <?php echo $tab==='ayarlar'?'active':''; ?>">
      ⚙️ Site Ayarları
    </a>
  </aside>

  <main class="content">

    <?php if ($tab === 'dashboard'): ?>
    <div class="page-title">Dashboard</div>
    <div class="page-sub">Genel istatistikler</div>

    <div class="stat-grid">
      <div class="stat-card">
        <div class="stat-label">Toplam Sipariş</div>
        <div class="stat-val"><?php echo $stats['toplam_siparis']; ?></div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Bekleyen</div>
        <div class="stat-val" style="color:var(--gold)"><?php echo $stats['bekleyen']; ?></div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Baskıda</div>
        <div class="stat-val" style="color:var(--acc)"><?php echo $stats['gonderilen']; ?></div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Tamamlanan</div>
        <div class="stat-val" style="color:#1a56db"><?php echo $stats['tamamlanan']; ?></div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Toplam Gelir</div>
        <div class="stat-val green">₺<?php echo number_format($stats['toplam_gelir'], 0); ?></div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Kullanıcılar</div>
        <div class="stat-val"><?php echo $stats['toplam_kullanici']; ?></div>
      </div>
    </div>

    <div class="card">
      <div class="card-head">
        <div>
          <div class="card-title">Son Siparişler</div>
          <div class="card-sub">En güncel 10 sipariş</div>
        </div>
        <a href="admin.php?tab=siparisler" style="font-size:12px;color:var(--acc);text-decoration:none;font-weight:600">Tümünü Gör →</a>
      </div>
      <?php $son = array_slice($siparisler, 0, 10); ?>
      <?php if (empty($son)): ?>
        <div class="empty-state">Henüz sipariş yok.</div>
      <?php else: ?>
      <table>
        <thead><tr><th>No</th><th>Müşteri</th><th>Ürün</th><th>Fiyat</th><th>Durum</th><th>Tarih</th></tr></thead>
        <tbody>
          <?php foreach ($son as $s): ?>
          <tr>
            <td><span style="font-family:'DM Mono',monospace;font-size:11px"><?php echo htmlspecialchars($s['siparis_no']); ?></span></td>
            <td><?php echo htmlspecialchars($s['ad_soyad'] ?? $s['musteri_adi'] ?? '—'); ?></td>
            <td style="font-size:12px;color:var(--ink2)"><?php echo htmlspecialchars($s['urun']); ?> · <?php echo htmlspecialchars($s['boyut']); ?></td>
            <td><span style="font-family:'DM Serif Display',serif;font-size:16px">₺<?php echo number_format($s['fiyat'],0); ?></span></td>
            <td><span class="rol-badge" style="background:<?php
              $durum_colors=['BEKLEMEDE'=>'rgba(138,109,10,.12)','BASKIYA GÖNDERİLDİ'=>'rgba(45,90,39,.12)','TAMAMLANDI'=>'rgba(0,64,133,.1)','İPTAL'=>'rgba(192,57,43,.1)'];
              $durum_text=['BEKLEMEDE'=>'#8a6d0a','BASKIYA GÖNDERİLDİ'=>'#2d5a27','TAMAMLANDI'=>'#004085','İPTAL'=>'#c0392b'];
              echo $durum_colors[$s['durum']] ?? 'var(--ink4)';
            ?>;color:<?php echo $durum_text[$s['durum']] ?? 'var(--ink3)'; ?>"><?php echo htmlspecialchars($s['durum']); ?></span></td>
            <td style="font-size:11px;color:var(--ink3);font-family:'DM Mono',monospace"><?php echo date('d.m H:i', strtotime($s['olusturma'])); ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      <?php endif; ?>
    </div>

    <?php elseif ($tab === 'siparisler'): ?>
    <div class="page-title">Siparişler</div>
    <div class="page-sub">Tüm siparişleri yönet</div>

    <?php if (isset($_GET['msg'])): ?>
      <div class="alert <?php echo $_GET['msg']==='ok'?'alert-ok':'alert-del'; ?>">
        <?php echo $_GET['msg']==='ok'?'✓ Güncellendi.':'✓ Silindi.'; ?>
      </div>
    <?php endif; ?>

    <div class="card">
      <?php if (empty($siparisler)): ?>
        <div class="empty-state">Henüz sipariş yok.</div>
      <?php else: ?>
      <table>
        <thead><tr><th>Görsel</th><th>No</th><th>Müşteri</th><th>Ürün</th><th>Fiyat</th><th>Durum</th><th>Tarih</th><th>İşlem</th></tr></thead>
        <tbody>
          <?php foreach ($siparisler as $s): ?>
          <tr>
            <td>
              <?php if ($s['thumbnail']): ?>
                <img class="thumb" src="<?php echo $s['thumbnail']; ?>" alt="">
              <?php else: ?>
                <div class="thumb-empty"></div>
              <?php endif; ?>
            </td>
            <td><span style="font-family:'DM Mono',monospace;font-size:11px;font-weight:600"><?php echo htmlspecialchars($s['siparis_no']); ?></span></td>
            <td>
              <div style="font-weight:600;font-size:13px"><?php echo htmlspecialchars($s['ad_soyad'] ?? '—'); ?></div>
              <div style="font-size:10px;color:var(--ink3)"><?php echo htmlspecialchars($s['eposta'] ?? ''); ?></div>
            </td>
            <td>
              <div style="font-size:12px"><?php echo htmlspecialchars($s['urun']); ?></div>
              <div style="font-size:10px;color:var(--ink3);font-family:'DM Mono',monospace"><?php echo htmlspecialchars($s['boyut']); ?> · <?php echo htmlspecialchars($s['yon']); ?></div>
              <?php if ($s['eklentiler']): ?><div style="font-size:10px;color:var(--acc)"><?php echo htmlspecialchars($s['eklentiler']); ?></div><?php endif; ?>
            </td>
            <td><span style="font-family:'DM Serif Display',serif;font-size:18px">₺<?php echo number_format($s['fiyat'],0); ?></span></td>
            <td>
              <form method="POST" style="display:inline">
                <input type="hidden" name="action" value="update_durum">
                <input type="hidden" name="id" value="<?php echo $s['id']; ?>">
                <?php $dc=['BEKLEMEDE','BASKIYA GÖNDERİLDİ','TAMAMLANDI','İPTAL']; $dcls=str_replace(' GÖNDERİLDİ','',str_replace('İ','I',$s['durum']));?>
                <select name="durum" onchange="this.form.submit()" class="status-select <?php echo str_replace(' ','_',str_replace('İ','I',$s['durum'])); ?>">
                  <?php foreach ($dc as $d): ?>
                    <option value="<?php echo $d; ?>" <?php echo $s['durum']===$d?'selected':''; ?>><?php echo $d; ?></option>
                  <?php endforeach; ?>
                </select>
              </form>
            </td>
            <td style="font-size:11px;color:var(--ink3);font-family:'DM Mono',monospace"><?php echo date('d.m.Y H:i', strtotime($s['olusturma'])); ?></td>
            <td>
              <button class="btn-sm btn-danger" onclick="confirmDelete(<?php echo $s['id']; ?>,'order')">Sil</button>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      <?php endif; ?>
    </div>

    <?php elseif ($tab === 'kullanicilar'): ?>
    <div class="page-title">Kullanıcılar</div>
    <div class="page-sub">Kayıtlı kullanıcıları yönet</div>

    <?php if (isset($_GET['msg'])): ?>
      <div class="alert <?php echo $_GET['msg']==='ok'?'alert-ok':'alert-del'; ?>">
        <?php echo $_GET['msg']==='ok'?'✓ Güncellendi.':'✓ Silindi.'; ?>
      </div>
    <?php endif; ?>

    <div class="card">
      <table>
        <thead><tr><th>ID</th><th>Ad Soyad</th><th>E-Posta</th><th>Rol</th><th>Kayıt Tarihi</th><th>İşlem</th></tr></thead>
        <tbody>
          <?php foreach ($kullanicilar as $k): ?>
          <tr>
            <td style="font-family:'DM Mono',monospace;font-size:11px;color:var(--ink3)">#<?php echo $k['id']; ?></td>
            <td style="font-weight:600"><?php echo htmlspecialchars($k['ad_soyad']); ?></td>
            <td style="font-size:12px;color:var(--ink2)"><?php echo htmlspecialchars($k['eposta']); ?></td>
            <td><span class="rol-badge <?php echo $k['rol']==='admin'?'rol-admin':'rol-user'; ?>"><?php echo strtoupper($k['rol']); ?></span></td>
            <td style="font-size:11px;color:var(--ink3);font-family:'DM Mono',monospace"><?php echo date('d.m.Y', strtotime($k['olusturma'])); ?></td>
            <td style="display:flex;gap:5px;align-items:center">
              <?php if ($k['rol'] !== 'admin'): ?>
                <form method="POST" style="display:inline">
                  <input type="hidden" name="action" value="make_admin">
                  <input type="hidden" name="id" value="<?php echo $k['id']; ?>">
                  <button type="submit" class="btn-sm btn-primary" onclick="return confirm('Admin yap?')">Admin Yap</button>
                </form>
                <button class="btn-sm btn-danger" onclick="confirmDelete(<?php echo $k['id']; ?>,'user')">Sil</button>
              <?php else: ?>
                <span style="font-size:11px;color:var(--ink3)">—</span>
              <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <?php elseif ($tab === 'ayarlar'): ?>
    <div class="page-title">Site Ayarları</div>
    <div class="page-sub">Genel site konfigürasyonu</div>

    <?php if (isset($_GET['msg']) && $_GET['msg'] === 'ok'): ?>
      <div class="alert alert-ok">✓ Ayarlar kaydedildi.</div>
    <?php endif; ?>

    <div class="card">
      <div class="card-head"><div class="card-title">Görünüm</div></div>
      <div style="padding:24px">
        <form method="POST">
          <input type="hidden" name="action" value="update_ayarlar">
          <div class="form-group">
            <label class="form-label">Logo / Site Adı</label>
            <input type="text" name="logo_metni" class="form-input" value="<?php echo htmlspecialchars($ayarlar['logo_metni']); ?>">
          </div>
          <div class="form-group">
            <label class="form-label">Site Başlığı</label>
            <input type="text" name="site_adi" class="form-input" value="<?php echo htmlspecialchars($ayarlar['site_adi']); ?>">
          </div>
          <button type="submit" class="btn-main">Kaydet</button>
        </form>
      </div>
    </div>

    <?php endif; ?>

  </main>
</div>

<div class="modal-overlay" id="deleteModal">
  <div class="modal">
    <h3>Emin misin?</h3>
    <p id="deleteModalText">Bu kayıt kalıcı olarak silinecek.</p>
    <div class="modal-btns">
      <button class="btn-sm" style="padding:8px 16px;border:1px solid var(--border);border-radius:var(--r);background:transparent;cursor:pointer" onclick="document.getElementById('deleteModal').classList.remove('open')">İptal</button>
      <form method="POST" id="deleteForm">
        <input type="hidden" name="action" id="deleteAction" value="">
        <input type="hidden" name="id" id="deleteId" value="">
        <button type="submit" class="btn-sm btn-danger" style="padding:8px 16px;font-size:12px">Sil</button>
      </form>
    </div>
  </div>
</div>

<script>
function confirmDelete(id, type) {
  document.getElementById('deleteId').value = id;
  document.getElementById('deleteAction').value = type === 'order' ? 'delete_order' : 'delete_user';
  document.getElementById('deleteModalText').textContent = type === 'order' ? 'Bu sipariş kalıcı olarak silinecek.' : 'Bu kullanıcı kalıcı olarak silinecek.';
  document.getElementById('deleteModal').classList.add('open');
}
document.getElementById('deleteModal').addEventListener('click', function(e) {
  if (e.target === this) this.classList.remove('open');
});
</script>
</body>
</html>
