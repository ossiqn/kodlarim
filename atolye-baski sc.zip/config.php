<?php
$host = 'localhost';
$dbname = 'baskisistemi';
$username = 'root';
$password = '';

try {
    $db = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die('<div style="font-family:sans-serif;padding:40px;color:#c0392b">Veritabanı bağlantı hatası: ' . $e->getMessage() . '</div>');
}
