<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_name = $_SESSION['user_name'];
$user_role = $_SESSION['user_role'];

try {
    $ayarlar = $db->query("SELECT logo_metni FROM ayarlar LIMIT 1")->fetch(PDO::FETCH_ASSOC);
    $logo_metni = $ayarlar['logo_metni'];
} catch (Exception $e) {
    $logo_metni = 'Atölye Baskı';
}

$siparisler_q = $db->prepare("SELECT * FROM siparisler WHERE kullanici_id = ? ORDER BY olusturma DESC LIMIT 30");
$siparisler_q->execute([$_SESSION['user_id']]);
$siparisler = $siparisler_q->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo htmlspecialchars($logo_metni); ?></title>
<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Mono:wght@300;400;500&family=Instrument+Sans:wght@400;500;600&display=swap" rel="stylesheet">
<style>
:root{--bg:#f7f5f0;--bg2:#eeeae2;--bg3:#e5e0d6;--ink:#1a1714;--ink2:#4a4540;--ink3:#8a8078;--ink4:rgba(26,23,20,.07);--acc:#2d5a27;--acc2:#3d7a35;--acc-l:rgba(45,90,39,.1);--red:#c0392b;--gold:#c8973a;--border:rgba(26,23,20,.11);--border2:rgba(26,23,20,.2);--shadow:0 2px 8px rgba(26,23,20,.08);--shadow2:0 8px 32px rgba(26,23,20,.14);--r:6px;--r2:12px}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body{background:var(--bg);color:var(--ink);font-family:'Instrument Sans',sans-serif;font-size:14px;line-height:1.5;min-height:100vh}
input[type=file]{display:none}
::-webkit-scrollbar{width:4px}
::-webkit-scrollbar-track{background:transparent}
::-webkit-scrollbar-thumb{background:var(--border2);border-radius:2px}

.topbar{position:sticky;top:0;z-index:200;background:rgba(247,245,240,.96);backdrop-filter:blur(12px);border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;padding:0 32px;height:56px}
.logo{font-family:'DM Serif Display',serif;font-size:22px;letter-spacing:-.5px}
.logo span{color:var(--acc)}
.topnav{display:flex;gap:2px}
.tnav-btn{padding:7px 16px;border-radius:var(--r);font-size:13px;font-weight:500;color:var(--ink2);cursor:pointer;border:none;background:none;font-family:'Instrument Sans',sans-serif;transition:all .18s;position:relative}
.tnav-btn:hover{color:var(--ink);background:var(--ink4)}
.tnav-btn.active{color:var(--acc);font-weight:600}
.tnav-btn.active::after{content:'';position:absolute;bottom:-1px;left:12px;right:12px;height:2px;background:var(--acc);border-radius:1px}
.topbar-right{display:flex;align-items:center;gap:10px}
.status-dot{width:7px;height:7px;border-radius:50%;background:#4caf50;animation:blink 2.5s infinite;display:inline-block}
@keyframes blink{0%,100%{opacity:1}50%{opacity:.35}}
.cart-btn{display:flex;align-items:center;gap:6px;padding:8px 16px;border-radius:var(--r);background:var(--acc);color:#fff;font-size:13px;font-weight:600;font-family:'Instrument Sans',sans-serif;border:none;cursor:pointer;transition:all .18s}
.cart-btn:hover{background:var(--acc2);transform:translateY(-1px);box-shadow:0 4px 16px rgba(45,90,39,.3)}
.user-pill{display:flex;align-items:center;gap:7px;padding:5px 12px;border-radius:30px;background:var(--bg2);border:1px solid var(--border);font-size:12px;color:var(--ink2);font-family:'DM Mono',monospace}
.user-pill a{color:var(--red);text-decoration:none;font-size:11px;margin-left:4px}
.user-pill a:hover{text-decoration:underline}

.page{display:none}
.page.active{display:block}

.studio-layout{display:grid;grid-template-columns:1fr 428px;min-height:calc(100vh - 56px)}

.preview-col{position:sticky;top:56px;height:calc(100vh - 56px);display:flex;flex-direction:column;background:var(--bg2);border-right:1px solid var(--border);overflow:hidden}
.preview-topbar{padding:12px 18px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;flex-shrink:0;gap:10px}
.scene-pills{display:flex;gap:5px;flex-wrap:wrap}
.scene-pill{padding:5px 13px;border-radius:30px;font-family:'DM Mono',monospace;font-size:10px;font-weight:500;cursor:pointer;transition:all .18s;border:1px solid var(--border);background:transparent;color:var(--ink3)}
.scene-pill:hover{border-color:var(--border2);color:var(--ink2)}
.scene-pill.active{background:var(--ink);color:#fff;border-color:var(--ink)}
.orient-badge{display:flex;gap:2px;background:var(--bg3);border:1px solid var(--border);border-radius:30px;padding:3px;flex-shrink:0}
.ob-btn{padding:4px 11px;border-radius:22px;font-size:10px;font-weight:600;font-family:'DM Mono',monospace;cursor:pointer;transition:all .18s;border:none;background:none;color:var(--ink3);white-space:nowrap}
.ob-btn.active{background:var(--ink);color:#fff}

.mockup-stage{flex:1;position:relative;display:flex;align-items:center;justify-content:center;overflow:hidden;cursor:pointer}
.upload-zone{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;z-index:10;border:2px dashed var(--border2);margin:28px;border-radius:var(--r2);transition:all .2s}
.upload-zone.hidden{display:none}
.upload-zone.dragover{border-color:var(--acc);background:var(--acc-l)}
.uz-icon{width:60px;height:60px;border-radius:50%;background:var(--bg);display:grid;place-items:center;font-size:24px;box-shadow:var(--shadow)}
.uz-title{font-family:'DM Serif Display',serif;font-size:20px}
.uz-sub{font-size:11px;color:var(--ink3);font-family:'DM Mono',monospace}
.uz-btn{padding:9px 22px;border-radius:var(--r);background:var(--acc);color:#fff;font-family:'Instrument Sans',sans-serif;font-weight:600;font-size:13px;border:none;cursor:pointer;transition:all .18s}
.uz-btn:hover{background:var(--acc2)}

.photo-strip{border-top:1px solid var(--border);padding:11px 18px;display:flex;align-items:center;justify-content:space-between;flex-shrink:0;background:var(--bg)}
.photo-strip.hidden{display:none}
.strip-left{display:flex;gap:6px}
.strip-btn{display:flex;align-items:center;gap:5px;padding:6px 12px;border-radius:var(--r);font-size:12px;font-weight:500;font-family:'Instrument Sans',sans-serif;cursor:pointer;transition:all .18s;border:1px solid var(--border);background:transparent;color:var(--ink2)}
.strip-btn:hover{border-color:var(--border2);background:var(--ink4)}
.strip-btn.danger:hover{border-color:var(--red);color:var(--red);background:rgba(192,57,43,.06)}
.strip-btn.accent{color:var(--acc);border-color:rgba(45,90,39,.25)}
.strip-btn.accent:hover{background:var(--acc-l)}

.config-col{padding:28px 26px;overflow-y:auto;display:flex;flex-direction:column;gap:0}
.prod-title{font-family:'DM Serif Display',serif;font-size:26px;line-height:1.15;margin-bottom:4px}
.prod-subtitle{font-size:11px;color:var(--ink3);margin-bottom:22px;font-family:'DM Mono',monospace;letter-spacing:.5px}
.section{margin-bottom:24px}
.section-label{font-size:10px;font-weight:600;letter-spacing:1.5px;text-transform:uppercase;color:var(--ink3);margin-bottom:10px;font-family:'DM Mono',monospace}
.shape-grid{display:grid;grid-template-columns:1fr 1fr;gap:7px;margin-bottom:6px}
.shape-btn{padding:11px;border-radius:var(--r);border:2px solid var(--border);background:transparent;cursor:pointer;font-family:'Instrument Sans',sans-serif;font-size:13px;font-weight:600;color:var(--ink2);transition:all .18s;text-align:center}
.shape-btn:hover{border-color:var(--border2)}
.shape-btn.active{border-color:var(--ink);background:var(--ink);color:#fff}
.size-grid{display:grid;grid-template-columns:1fr 1fr 1fr;gap:7px}
.size-btn{padding:11px 7px;border-radius:var(--r);border:2px solid var(--border);cursor:pointer;text-align:center;transition:all .18s;background:transparent;position:relative;font-family:'Instrument Sans',sans-serif}
.size-btn:hover{border-color:var(--border2)}
.size-btn.active{border-color:var(--acc);background:var(--acc-l)}
.size-name{font-size:12px;font-weight:600;color:var(--ink);display:block}
.size-dims{font-size:9px;color:var(--ink3);font-family:'DM Mono',monospace;display:block;margin-top:1px}
.size-badge{position:absolute;top:-7px;left:50%;transform:translateX(-50%);padding:2px 7px;border-radius:10px;font-size:8px;font-weight:700;font-family:'DM Mono',monospace;letter-spacing:.5px;white-space:nowrap}
.badge-gift{background:#e74c3c;color:#fff}
.badge-best{background:var(--acc);color:#fff}
.addon-list{display:flex;flex-direction:column;gap:8px}
.addon-card{display:flex;align-items:flex-start;gap:12px;padding:12px 14px;border-radius:var(--r2);border:2px solid var(--border);cursor:pointer;transition:all .18s;background:transparent;text-align:left;width:100%}
.addon-card:hover{border-color:var(--border2)}
.addon-card.active{border-color:var(--acc);background:var(--acc-l)}
.addon-img{width:48px;height:48px;border-radius:8px;background:var(--bg3);display:grid;place-items:center;font-size:20px;flex-shrink:0}
.addon-content{flex:1;min-width:0}
.addon-name{font-size:13px;font-weight:600;color:var(--ink);margin-bottom:2px}
.addon-desc{font-size:11px;color:var(--ink3);line-height:1.4}
.addon-price{font-family:'DM Mono',monospace;font-size:12px;color:var(--acc);font-weight:500;margin-left:auto;flex-shrink:0;padding-left:8px}
.addon-limited{font-size:10px;color:var(--red);font-weight:600;margin-bottom:2px;display:block}
.wood-variants{display:flex;gap:7px;margin-top:8px;padding:6px 14px 0}
.wood-btn{display:flex;align-items:center;gap:5px;padding:5px 13px;border-radius:20px;font-size:11px;font-weight:500;cursor:pointer;border:2px solid var(--border);transition:all .18s;background:transparent;font-family:'Instrument Sans',sans-serif;color:var(--ink2)}
.wood-btn.active{border-color:var(--ink);background:var(--ink);color:#fff}
.wood-dot{width:10px;height:10px;border-radius:50%;flex-shrink:0}
.order-fields{display:flex;flex-direction:column;gap:9px;margin-bottom:14px}
.field-label{font-size:10px;color:var(--ink3);margin-bottom:3px;font-family:'DM Mono',monospace;letter-spacing:.5px}
.field-input{width:100%;padding:9px 11px;border-radius:var(--r);border:1.5px solid var(--border);background:var(--bg);color:var(--ink);font-family:'Instrument Sans',sans-serif;font-size:13px;outline:none;transition:border-color .18s}
.field-input:focus{border-color:var(--acc)}
.check-list{display:flex;flex-direction:column;gap:7px}
.check-item{display:flex;align-items:center;gap:9px;font-size:12px;color:var(--ink2)}
.check-dot{width:17px;height:17px;border-radius:50%;flex-shrink:0;border:1.5px solid var(--border);display:grid;place-items:center;font-size:8px;transition:all .25s}
.check-dot.ok{background:var(--acc);border-color:var(--acc);color:#fff}
.check-dot.warn{background:#f39c12;border-color:#f39c12;color:#fff}
.check-dot.fail{background:rgba(192,57,43,.1);border-color:var(--red);color:var(--red)}
.sep{height:1px;background:var(--border);margin:20px 0}
.subtotal-bar{display:flex;align-items:center;justify-content:space-between;margin-bottom:12px}
.subtotal-label{font-size:14px;font-weight:600}
.subtotal-price{font-family:'DM Serif Display',serif;font-size:26px}
.cta-btn{width:100%;padding:15px;border-radius:var(--r2);background:var(--acc);color:#fff;font-family:'Instrument Sans',sans-serif;font-weight:700;font-size:15px;border:none;cursor:pointer;transition:all .2s;display:flex;align-items:center;justify-content:center;gap:9px;position:relative;overflow:hidden}
.cta-btn::before{content:'';position:absolute;inset:0;background:linear-gradient(135deg,rgba(255,255,255,.1),transparent);pointer-events:none}
.cta-btn:hover{background:var(--acc2);transform:translateY(-2px);box-shadow:0 8px 28px rgba(45,90,39,.35)}
.cta-btn:active{transform:none}
.cta-btn:disabled{opacity:.45;cursor:not-allowed;transform:none}
.cta-secondary{width:100%;padding:11px;border-radius:var(--r2);background:transparent;color:var(--ink2);font-family:'Instrument Sans',sans-serif;font-weight:500;font-size:13px;border:1.5px solid var(--border);cursor:pointer;transition:all .18s;margin-top:7px}
.cta-secondary:hover{border-color:var(--border2);background:var(--ink4)}

.preview-page-wrap{max-width:1100px;margin:0 auto;padding:48px 32px}
.preview-page-title{font-family:'DM Serif Display',serif;font-size:34px;margin-bottom:6px}
.mockup-gallery{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:40px}
.gallery-scene{border-radius:var(--r2);overflow:hidden;border:1px solid var(--border);background:var(--bg2);position:relative;cursor:pointer;transition:all .25s}
.gallery-scene:first-child{grid-column:1/-1;aspect-ratio:16/6}
.gallery-scene:not(:first-child){aspect-ratio:4/3}
.gallery-scene:hover{transform:translateY(-3px);box-shadow:var(--shadow2)}
.gallery-scene canvas{width:100%;height:100%;display:block}
.gallery-label{position:absolute;bottom:12px;left:12px;background:rgba(247,245,240,.92);backdrop-filter:blur(8px);border:1px solid var(--border);padding:4px 11px;border-radius:20px;font-family:'DM Mono',monospace;font-size:10px;color:var(--ink2)}
.specs-grid{display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:36px}
.spec-card{background:var(--bg2);border:1px solid var(--border);border-radius:var(--r2);padding:18px 22px}
.spec-title{font-size:10px;font-weight:600;letter-spacing:1.5px;text-transform:uppercase;color:var(--ink3);margin-bottom:12px;font-family:'DM Mono',monospace}
.spec-row{display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid var(--border);font-size:12px}
.spec-row:last-child{border-bottom:none}
.spec-key{color:var(--ink3)}
.spec-val{font-family:'DM Mono',monospace;font-weight:500;color:var(--ink)}
.spec-val.ok{color:var(--acc)}
.spec-val.warn{color:#f39c12}
.spec-val.fail{color:var(--red)}
.quality-bar-track{height:4px;background:var(--bg3);border-radius:3px;overflow:hidden;margin-top:5px}
.quality-bar-fill{height:100%;border-radius:3px;transition:width .5s ease,background .5s}

.orders-page-wrap{max-width:800px;margin:0 auto;padding:48px 32px}
.ord-row{display:flex;align-items:center;gap:16px;padding:16px 20px;background:var(--bg2);border:1px solid var(--border);border-radius:var(--r2);margin-bottom:10px}
.ord-thumb{width:52px;height:58px;object-fit:cover;border-radius:6px;border:1px solid var(--border);flex-shrink:0;background:var(--bg3)}
.ord-info{flex:1;min-width:0}
.ord-no{font-weight:600;font-size:14px;margin-bottom:3px}
.ord-sub{font-size:12px;color:var(--ink3)}
.ord-date{font-size:10px;color:var(--ink3);font-family:'DM Mono',monospace;margin-top:2px}
.ord-right{text-align:right;flex-shrink:0}
.ord-price{font-family:'DM Serif Display',serif;font-size:20px}
.ord-status{font-size:9px;background:#e8f5e4;color:var(--acc);border-radius:20px;padding:3px 9px;font-family:'DM Mono',monospace;margin-top:4px;font-weight:600;display:inline-block}

#toast{position:fixed;bottom:26px;right:26px;padding:11px 18px;border-radius:var(--r2);font-family:'DM Mono',monospace;font-size:12px;z-index:9999;opacity:0;transform:translateY(10px);transition:all .25s;pointer-events:none;max-width:320px;box-shadow:0 8px 30px rgba(0,0,0,.12)}
#toast.show{opacity:1;transform:translateY(0)}
#toast.ok{background:var(--ink);color:var(--bg)}
#toast.err{background:#c0392b;color:#fff}

.spin{display:inline-block;width:13px;height:13px;border:2px solid rgba(255,255,255,.3);border-top-color:#fff;border-radius:50%;animation:spin .7s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
</style>
</head>
<body>

<header class="topbar">
  <div class="logo"><?php echo htmlspecialchars($logo_metni); ?><span>.</span></div>
  <nav class="topnav">
    <button class="tnav-btn active" id="tabStudio" onclick="gotoPage('studio')">Stüdyo</button>
    <button class="tnav-btn" id="tabPreview" onclick="gotoPage('onizleme')">Önizleme</button>
    <button class="tnav-btn" id="tabOrders" onclick="gotoPage('siparisler')">Siparişlerim</button>
  </nav>
  <div class="topbar-right">
    <div style="display:flex;align-items:center;gap:6px;font-family:'DM Mono',monospace;font-size:11px;color:var(--ink3)">
      <div class="status-dot"></div>Matbaa Aktif
    </div>
    <?php if ($user_role === 'admin'): ?>
    <a href="admin.php" style="padding:7px 14px;border-radius:var(--r);background:var(--gold);color:#fff;font-size:12px;font-weight:700;text-decoration:none;font-family:'DM Mono',monospace">Admin Panel</a>
    <?php endif; ?>
    <div class="user-pill">
      👤 <?php echo htmlspecialchars($user_name); ?>
      <a href="logout.php">Çıkış</a>
    </div>
    <button class="cart-btn" onclick="sendPrint()">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
      Matbaaya Gönder
    </button>
  </div>
</header>

<input type="file" id="fileInput" accept="image/*">

<div class="page active" id="studioPage">
<div class="studio-layout">

  <div class="preview-col">
    <div class="preview-topbar">
      <div class="scene-pills" id="scenePills">
        <button class="scene-pill active" onclick="setScene('flat',this)">Düz</button>
        <button class="scene-pill" onclick="setScene('desk',this)">Masada</button>
        <button class="scene-pill" onclick="setScene('wall',this)">Duvarda</button>
        <button class="scene-pill" onclick="setScene('hand',this)">Elde</button>
        <button class="scene-pill" onclick="setScene('angle',this)">Açılı</button>
      </div>
      <div class="orient-badge">
        <button class="ob-btn active" id="ob-portrait" onclick="setOrientation('portrait',this)">↕ Dikey</button>
        <button class="ob-btn" id="ob-landscape" onclick="setOrientation('landscape',this)">↔ Yatay</button>
      </div>
    </div>

    <div class="mockup-stage" id="mockupStage" onclick="handleStageClick(event)">
      <div class="upload-zone" id="uploadZone">
        <div class="uz-icon">📸</div>
        <div class="uz-title">Fotoğrafını yükle</div>
        <div class="uz-sub">PNG · JPG · WEBP · Sürükle & Bırak</div>
        <button class="uz-btn" onclick="event.stopPropagation();document.getElementById('fileInput').click()">Dosya Seç</button>
      </div>
      <canvas id="mockupCanvas" width="520" height="580"></canvas>
    </div>

    <div class="photo-strip hidden" id="photoStrip">
      <div class="strip-left">
        <button class="strip-btn" onclick="document.getElementById('fileInput').click()">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
          Fotoğrafı Değiştir
        </button>
        <button class="strip-btn danger" onclick="removePhoto()">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/></svg>
          Kaldır
        </button>
      </div>
      <button class="strip-btn accent" onclick="gotoPage('onizleme')">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
        Tüm sahneler →
      </button>
    </div>
  </div>

  <div class="config-col">
    <div class="prod-title">Cam Baskı</div>
    <div class="prod-subtitle">PREMIUM GLASS PRINT · UV BASKI · PARLAK YÜZEYLİ</div>

    <div class="section">
      <div class="section-label">Şekil</div>
      <div class="shape-grid">
        <button class="shape-btn active" onclick="setShape('rectangle',this)">Dikdörtgen</button>
        <button class="shape-btn" onclick="setShape('square',this)">Kare</button>
      </div>
    </div>

    <div class="section">
      <div class="section-label">Boyut Seçin &nbsp;<span style="font-weight:400;color:var(--ink3);font-size:9px"><a href="#" onclick="event.preventDefault();gotoPage('onizleme')" style="color:var(--acc);text-decoration:none">Boyut rehberi →</a></span></div>
      <div class="size-grid" id="sizeGrid">
        <button class="size-btn" onclick="selectSize(this,'XS',180,120,30)"><span class="size-name">X-Küçük</span><span class="size-dims">18×12 cm</span></button>
        <button class="size-btn" onclick="selectSize(this,'S',210,148,39)"><span class="size-badge badge-gift">Top Gift</span><span class="size-name">Küçük</span><span class="size-dims">21×14.8 cm</span></button>
        <button class="size-btn active" onclick="selectSize(this,'M',297,210,55)"><span class="size-badge badge-best">En Çok Satan</span><span class="size-name">Orta</span><span class="size-dims">29.7×21 cm</span></button>
        <button class="size-btn" onclick="selectSize(this,'L',420,297,85)"><span class="size-name">Büyük</span><span class="size-dims">42×29.7 cm</span></button>
        <button class="size-btn" onclick="selectSize(this,'XL',594,420,120)"><span class="size-name">X-Büyük</span><span class="size-dims">59.4×42 cm</span></button>
      </div>
    </div>

    <div class="section">
      <div class="section-label">Ekstra Seçenekler</div>
      <div class="addon-list">
        <button class="addon-card" id="addon-stand" onclick="toggleAddon('stand',7,this)">
          <div class="addon-img">🔺</div>
          <div class="addon-content">
            <div class="addon-name">Metal Stand <span style="font-size:10px;color:var(--ink3);font-weight:400">+₺7</span></div>
            <div class="addon-desc">Masaüstünde dik durması için metal ayak.</div>
          </div>
          <div id="addon-stand-check" style="width:18px;height:18px;border-radius:50%;border:1.5px solid var(--border);flex-shrink:0;display:grid;place-items:center;font-size:9px;transition:all .2s;margin-top:2px"></div>
        </button>

        <div>
          <button class="addon-card" id="addon-wood" onclick="toggleAddon('wood',15,this)">
            <div class="addon-img">🪵</div>
            <div class="addon-content">
              <span class="addon-limited">⚠ Stok Sınırlı</span>
              <div class="addon-name">Premium Ahşap Stand <span style="font-size:10px;color:var(--ink3);font-weight:400">+₺15</span></div>
              <div class="addon-desc">El yapımı ahşap stand ile masaüstü görünüm.</div>
            </div>
            <div id="addon-wood-check" style="width:18px;height:18px;border-radius:50%;border:1.5px solid var(--border);flex-shrink:0;display:grid;place-items:center;font-size:9px;transition:all .2s;margin-top:2px"></div>
          </button>
          <div class="wood-variants" id="woodVariants" style="display:none">
            <button class="wood-btn active" onclick="setWood('walnut',this)"><div class="wood-dot" style="background:#4a2c0a"></div>Dark Walnut</button>
            <button class="wood-btn" onclick="setWood('oak',this)"><div class="wood-dot" style="background:#c49a2c"></div>Oak</button>
          </div>
        </div>

        <button class="addon-card" id="addon-matte" onclick="toggleAddon('matte',4,this)">
          <div class="addon-img">🔲</div>
          <div class="addon-content">
            <div class="addon-name">Mat Cam <span style="font-size:10px;color:var(--ink3);font-weight:400">+₺4</span></div>
            <div class="addon-desc">Anti-parlama mat yüzey. Aydınlık ortamlar için ideal.</div>
          </div>
          <div id="addon-matte-check" style="width:18px;height:18px;border-radius:50%;border:1.5px solid var(--border);flex-shrink:0;display:grid;place-items:center;font-size:9px;transition:all .2s;margin-top:2px"></div>
        </button>

        <button class="addon-card" id="addon-qr" onclick="toggleAddon('qr',5,this)">
          <div class="addon-img" style="font-size:16px">▪▪<br>▪▪</div>
          <div class="addon-content">
            <div class="addon-name">StoryGlass QR <span style="font-size:10px;color:var(--ink3);font-weight:400">+₺5</span></div>
            <div class="addon-desc">Cam üzerinde gizli QR kod — video veya ses belleğinizi ekleyin.</div>
          </div>
          <div id="addon-qr-check" style="width:18px;height:18px;border-radius:50%;border:1.5px solid var(--border);flex-shrink:0;display:grid;place-items:center;font-size:9px;transition:all .2s;margin-top:2px"></div>
        </button>
      </div>
    </div>

    <div class="section">
      <div class="section-label">Sipariş Bilgileri</div>
      <div class="order-fields">
        <div><div class="field-label">Sipariş No</div><input class="field-input" id="orderId" value="SHP-<?php echo rand(10000,99999); ?>" placeholder="SHP-XXXXX" oninput="updateChecklist()"></div>
        <div><div class="field-label">Müşteri Adı</div><input class="field-input" id="custName" value="<?php echo htmlspecialchars($user_name); ?>" placeholder="Ad Soyad"></div>
        <div><div class="field-label">Baskı Notu (opsiyonel)</div><input class="field-input" id="printNote" placeholder="Özel talimat..."></div>
      </div>
    </div>

    <div class="section">
      <div class="section-label">Baskı Kontrol</div>
      <div class="check-list">
        <div class="check-item"><div class="check-dot fail" id="ck0">✕</div><span id="ckt0">Görsel yüklenmedi</span></div>
        <div class="check-item"><div class="check-dot fail" id="ck1">✕</div><span id="ckt1">DPI hesaplanmadı</span></div>
        <div class="check-item"><div class="check-dot warn" id="ck2">!</div><span id="ckt2">Sipariş no kontrol</span></div>
      </div>
    </div>

    <div class="sep"></div>

    <div class="subtotal-bar">
      <span class="subtotal-label">Toplam</span>
      <span class="subtotal-price" id="subtotalPrice">₺55</span>
    </div>

    <button class="cta-btn" id="printBtn" onclick="sendPrint()" disabled>
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
      Matbaaya Gönder
    </button>
    <button class="cta-secondary" onclick="gotoPage('onizleme')">Tüm sahne önizlemelerini gör →</button>
  </div>

</div>
</div>

<div class="page" id="previewPage">
<div class="preview-page-wrap">
  <div style="display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:36px">
    <div>
      <div class="preview-page-title">Ürünün Nasıl Görünecek?</div>
      <div style="font-size:13px;color:var(--ink3)">Fotoğrafın cam baskı üzerinde farklı ortamlarda nasıl duracağını incele</div>
    </div>
    <button onclick="gotoPage('studio')" style="display:flex;align-items:center;gap:5px;padding:9px 16px;border-radius:var(--r);border:1.5px solid var(--border);background:transparent;font-family:'Instrument Sans',sans-serif;font-size:12px;font-weight:500;cursor:pointer;color:var(--ink2);transition:all .18s;white-space:nowrap;margin-top:4px" onmouseover="this.style.background='var(--ink4)'" onmouseout="this.style.background='transparent'">← Stüdyoya Dön</button>
  </div>

  <div class="mockup-gallery">
    <div class="gallery-scene" onclick="gotoSceneAndStudio('desk')">
      <canvas id="gc-desk"></canvas>
      <div class="gallery-label">📋 Masa Görünümü</div>
    </div>
    <div class="gallery-scene" onclick="gotoSceneAndStudio('hand')">
      <canvas id="gc-hand"></canvas>
      <div class="gallery-label">🤲 Elde Tutma</div>
    </div>
    <div class="gallery-scene" onclick="gotoSceneAndStudio('wall')">
      <canvas id="gc-wall"></canvas>
      <div class="gallery-label">🖼 Duvar Montaj</div>
    </div>
    <div class="gallery-scene" onclick="gotoSceneAndStudio('angle')">
      <canvas id="gc-angle"></canvas>
      <div class="gallery-label">📐 Perspektif Açı</div>
    </div>
  </div>

  <div class="specs-grid">
    <div class="spec-card">
      <div class="spec-title">Görsel Kalite Analizi</div>
      <div class="spec-row"><span class="spec-key">Çözünürlük</span><span class="spec-val" id="sp-res">—</span></div>
      <div class="spec-row"><span class="spec-key">Tahmini DPI</span><span class="spec-val" id="sp-dpi">—</span></div>
      <div class="spec-row"><span class="spec-key">Megapiksel</span><span class="spec-val" id="sp-mp">—</span></div>
      <div class="spec-row" style="border:none;padding-bottom:0">
        <span class="spec-key">Kalite</span><span class="spec-val" id="sp-qlabel">—</span>
      </div>
      <div class="quality-bar-track" style="margin-top:8px">
        <div class="quality-bar-fill" id="sp-qbar" style="width:0%"></div>
      </div>
    </div>
    <div class="spec-card">
      <div class="spec-title">Sipariş Özeti</div>
      <div class="spec-row"><span class="spec-key">Ürün</span><span class="spec-val">Cam Baskı</span></div>
      <div class="spec-row"><span class="spec-key">Boyut</span><span class="spec-val" id="sp-size">—</span></div>
      <div class="spec-row"><span class="spec-key">Yön</span><span class="spec-val" id="sp-orient">—</span></div>
      <div class="spec-row"><span class="spec-key">Ekstralar</span><span class="spec-val" id="sp-addons">—</span></div>
      <div class="spec-row"><span class="spec-key">Sipariş No</span><span class="spec-val" id="sp-order">—</span></div>
      <div class="spec-row" style="border:none;padding-top:10px"><span class="spec-key" style="font-weight:600;color:var(--ink)">Toplam</span><span class="spec-val" style="font-size:18px;color:var(--acc)" id="sp-total">—</span></div>
    </div>
  </div>

  <div style="display:flex;gap:10px">
    <button class="cta-btn" style="max-width:300px" onclick="sendPrint()">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
      Matbaaya Gönder
    </button>
    <button class="cta-secondary" style="max-width:180px" onclick="gotoPage('studio')">← Stüdyoya Dön</button>
  </div>
</div>
</div>

<div class="page" id="siparislerPage">
<div class="orders-page-wrap">
  <div class="preview-page-title" style="margin-bottom:6px">Siparişlerim</div>
  <div style="font-size:13px;color:var(--ink3);margin-bottom:28px">Gönderilen siparişlerin geçmişi</div>
  <div id="ordersList">
    <?php if (empty($siparisler)): ?>
      <div style="color:var(--ink3);font-family:'DM Mono',monospace;font-size:13px;padding:40px;text-align:center;background:var(--bg2);border-radius:var(--r2);border:1px solid var(--border)">Henüz sipariş yok.</div>
    <?php else: ?>
      <?php foreach ($siparisler as $s): ?>
      <div class="ord-row">
        <?php if ($s['thumbnail']): ?>
          <img class="ord-thumb" src="<?php echo $s['thumbnail']; ?>" alt="">
        <?php else: ?>
          <div class="ord-thumb"></div>
        <?php endif; ?>
        <div class="ord-info">
          <div class="ord-no"><?php echo htmlspecialchars($s['siparis_no']); ?></div>
          <div class="ord-sub"><?php echo htmlspecialchars($s['urun']); ?> · <?php echo htmlspecialchars($s['musteri_adi']); ?></div>
          <div class="ord-date"><?php echo date('d.m.Y H:i', strtotime($s['olusturma'])); ?></div>
        </div>
        <div class="ord-right">
          <div class="ord-price">₺<?php echo number_format($s['fiyat'], 0); ?></div>
          <div class="ord-status"><?php echo htmlspecialchars($s['durum']); ?></div>
        </div>
      </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>
</div>
</div>

<div id="toast"></div>

<script>
let userImg=null,userImgDataURL=null,naturalW=0,naturalH=0;
let currentScene='flat',currentOrientation='portrait',currentShape='rectangle';
let currentSize={id:'M',w:297,h:210,price:55};
let addons={},woodChoice='walnut';

function gotoPage(name){
  document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
  document.querySelectorAll('.tnav-btn').forEach(b=>b.classList.remove('active'));
  const pmap={studio:'studioPage',onizleme:'previewPage',siparisler:'siparislerPage'};
  const tmap={studio:'tabStudio',onizleme:'tabPreview',siparisler:'tabOrders'};
  const p=document.getElementById(pmap[name]);if(p)p.classList.add('active');
  const t=document.getElementById(tmap[name]);if(t)t.classList.add('active');
  history.pushState(null,'','#'+name);
  window.scrollTo(0,0);
  if(name==='onizleme'){setTimeout(renderGallery,60);updateSpecs();}
}
window.addEventListener('popstate',()=>{const h=location.hash.replace('#','')||'studio';gotoPage(h);});
(()=>{const h=location.hash.replace('#','')||'studio';gotoPage(h);})();

document.getElementById('fileInput').addEventListener('change',function(e){if(e.target.files[0])loadFile(e.target.files[0]);this.value='';});
function handleStageClick(e){if(!userImg)document.getElementById('fileInput').click();}
const stage=document.getElementById('mockupStage');
stage.addEventListener('dragover',e=>{e.preventDefault();document.getElementById('uploadZone').classList.add('dragover');});
stage.addEventListener('dragleave',()=>{document.getElementById('uploadZone').classList.remove('dragover');});
stage.addEventListener('drop',e=>{
  e.preventDefault();
  document.getElementById('uploadZone').classList.remove('dragover');
  const f=e.dataTransfer.files[0];
  if(f&&f.type.startsWith('image/'))loadFile(f);
});
function loadFile(file){
  const reader=new FileReader();
  reader.onload=ev=>{
    userImgDataURL=ev.target.result;
    const img=new Image();
    img.onload=()=>{
      userImg=img;naturalW=img.naturalWidth;naturalH=img.naturalHeight;
      document.getElementById('uploadZone').classList.add('hidden');
      document.getElementById('photoStrip').classList.remove('hidden');
      document.getElementById('printBtn').disabled=false;
      renderMockup();updateChecklist();
      toast('✓ Yüklendi: '+file.name);
    };
    img.src=ev.target.result;
  };
  reader.readAsDataURL(file);
}
function removePhoto(){
  userImg=null;userImgDataURL=null;naturalW=0;naturalH=0;
  document.getElementById('uploadZone').classList.remove('hidden');
  document.getElementById('photoStrip').classList.add('hidden');
  document.getElementById('printBtn').disabled=true;
  const c=document.getElementById('mockupCanvas');
  c.getContext('2d').clearRect(0,0,c.width,c.height);
  updateChecklist();
}

function setOrientation(o,el){
  currentOrientation=o;
  document.querySelectorAll('.ob-btn').forEach(b=>b.classList.remove('active'));
  el.classList.add('active');
  renderMockup();
  toast('✓ '+(o==='portrait'?'Dikey':'Yatay')+' yön');
}

function setShape(s,el){
  currentShape=s;
  document.querySelectorAll('.shape-btn').forEach(b=>b.classList.remove('active'));
  el.classList.add('active');
  const sg=document.getElementById('sizeGrid');
  if(s==='square'){
    sg.innerHTML=`
      <button class="size-btn active" onclick="selectSize(this,'S',150,150,30)"><span class="size-name">Küçük</span><span class="size-dims">15×15 cm</span></button>
      <button class="size-btn" onclick="selectSize(this,'M',200,200,49)"><span class="size-badge badge-best">Best Seller</span><span class="size-name">Orta</span><span class="size-dims">20×20 cm</span></button>
      <button class="size-btn" onclick="selectSize(this,'L',250,250,70)"><span class="size-name">Büyük</span><span class="size-dims">25×25 cm</span></button>`;
    currentSize={id:'S',w:150,h:150,price:30};
  } else {
    sg.innerHTML=`
      <button class="size-btn" onclick="selectSize(this,'XS',180,120,30)"><span class="size-name">X-Küçük</span><span class="size-dims">18×12 cm</span></button>
      <button class="size-btn" onclick="selectSize(this,'S',210,148,39)"><span class="size-badge badge-gift">Top Gift</span><span class="size-name">Küçük</span><span class="size-dims">21×14.8 cm</span></button>
      <button class="size-btn active" onclick="selectSize(this,'M',297,210,55)"><span class="size-badge badge-best">En Çok Satan</span><span class="size-name">Orta</span><span class="size-dims">29.7×21 cm</span></button>
      <button class="size-btn" onclick="selectSize(this,'L',420,297,85)"><span class="size-name">Büyük</span><span class="size-dims">42×29.7 cm</span></button>
      <button class="size-btn" onclick="selectSize(this,'XL',594,420,120)"><span class="size-name">X-Büyük</span><span class="size-dims">59.4×42 cm</span></button>`;
    currentSize={id:'M',w:297,h:210,price:55};
  }
  addons={};
  renderMockup();updateSubtotal();
}

function selectSize(el,id,w,h,price){
  document.querySelectorAll('.size-btn').forEach(b=>b.classList.remove('active'));
  el.classList.add('active');
  currentSize={id,w,h,price};
  renderMockup();updateSubtotal();updateChecklist();
  toast('✓ Boyut: '+id+' ('+w+'×'+h+'mm)');
}

function toggleAddon(key,price,el){
  if(addons[key]){
    delete addons[key];
    el.classList.remove('active');
    document.getElementById('addon-'+key+'-check').style.cssText='background:transparent;border-color:var(--border);color:var(--ink3)';
    document.getElementById('addon-'+key+'-check').textContent='';
    if(key==='wood')document.getElementById('woodVariants').style.display='none';
  } else {
    addons[key]={price};
    el.classList.add('active');
    const chk=document.getElementById('addon-'+key+'-check');
    chk.style.cssText='background:var(--acc);border-color:var(--acc);color:#fff';
    chk.textContent='✓';
    if(key==='wood')document.getElementById('woodVariants').style.display='flex';
  }
  updateSubtotal();
}

function setWood(type,el){
  woodChoice=type;
  document.querySelectorAll('.wood-btn').forEach(b=>b.classList.remove('active'));
  el.classList.add('active');
}

function updateSubtotal(){
  let t=currentSize.price;
  Object.values(addons).forEach(a=>t+=a.price);
  document.getElementById('subtotalPrice').textContent='₺'+t;
}

function updateChecklist(){
  const hasImg=!!userImg;
  const dpi=naturalW?Math.round((naturalW/(currentSize.w/25.4)+naturalH/(currentSize.h/25.4))/2):0;
  const dpiOk=dpi>=300,dpiWarn=dpi>=150&&dpi<300;
  const ordId=document.getElementById('orderId').value.trim();
  const ordOk=ordId.length>3;
  const set=(i,st,txt)=>{
    const d=document.getElementById('ck'+i),t=document.getElementById('ckt'+i);
    d.className='check-dot '+st;
    d.textContent=st==='ok'?'✓':st==='warn'?'!':'✕';
    t.textContent=txt;
  };
  set(0,hasImg?'ok':'fail',hasImg?'Görsel yüklendi ✓':'Görsel yüklenmedi');
  set(1,hasImg?(dpiOk?'ok':dpiWarn?'warn':'fail'):'fail',hasImg?(dpi+' DPI — '+(dpiOk?'Mükemmel':dpiWarn?'Orta kalite':'Düşük DPI')):'DPI hesaplanmadı');
  set(2,ordOk?'ok':'warn',ordOk?'Sipariş No: '+ordId:'Sipariş numarası eksik');
}

function renderMockup(){
  const c=document.getElementById('mockupCanvas');
  const W=c.width,H=c.height;
  const ctx=c.getContext('2d');
  ctx.clearRect(0,0,W,H);
  const isLand=currentOrientation==='landscape';
  const ratio=isLand?currentSize.w/currentSize.h:currentSize.h/currentSize.w;
  let gw,gh;
  if(currentShape==='square'){gw=Math.min(W,H)*.72;gh=gw;}
  else{const base=Math.min(W*.82,H*.78);gw=ratio>1?base:base/ratio;gh=ratio>1?base/ratio:base;}
  const gx=(W-gw)/2,gy=(H-gh)/2;
  ({flat:drawFlat,desk:drawDesk,wall:drawWall,hand:drawHand,angle:drawAngle}[currentScene]||drawFlat)(ctx,W,H,gw,gh);
}

function getGlassDims(W,H){
  const isLand=currentOrientation==='landscape';
  const ratio=isLand?currentSize.w/currentSize.h:currentSize.h/currentSize.w;
  let gw,gh;
  if(currentShape==='square'){gw=Math.min(W,H)*.72;gh=gw;}
  else{const base=Math.min(W*.82,H*.78);gw=ratio>1?base:base/ratio;gh=ratio>1?base/ratio:base;}
  return{gw,gh};
}

function drawGlass(ctx,x,y,w,h,img){
  ctx.save();
  const r=8;
  ctx.beginPath();
  ctx.moveTo(x+r,y);ctx.lineTo(x+w-r,y);ctx.quadraticCurveTo(x+w,y,x+w,y+r);
  ctx.lineTo(x+w,y+h-r);ctx.quadraticCurveTo(x+w,y+h,x+w-r,y+h);
  ctx.lineTo(x+r,y+h);ctx.quadraticCurveTo(x,y+h,x,y+h-r);
  ctx.lineTo(x,y+r);ctx.quadraticCurveTo(x,y,x+r,y);
  ctx.closePath();
  ctx.clip();
  if(img){ctx.drawImage(img,x,y,w,h);}
  else{ctx.fillStyle='#d0d8e8';ctx.fillRect(x,y,w,h);}
  const gl=ctx.createLinearGradient(x,y,x+w*.6,y+h*.5);
  gl.addColorStop(0,'rgba(255,255,255,.28)');
  gl.addColorStop(.4,'rgba(255,255,255,.06)');
  gl.addColorStop(1,'rgba(255,255,255,0)');
  ctx.fillStyle=gl;ctx.fillRect(x,y,w,h);
  ctx.restore();
  ctx.save();
  ctx.strokeStyle='rgba(255,255,255,.5)';ctx.lineWidth=1.5;
  ctx.beginPath();
  ctx.moveTo(x+r,y);ctx.lineTo(x+w-r,y);ctx.quadraticCurveTo(x+w,y,x+w,y+r);
  ctx.lineTo(x+w,y+h-r);ctx.quadraticCurveTo(x+w,y+h,x+w-r,y+h);
  ctx.lineTo(x+r,y+h);ctx.quadraticCurveTo(x,y+h,x,y+h-r);
  ctx.lineTo(x,y+r);ctx.quadraticCurveTo(x,y,x+r,y);
  ctx.closePath();ctx.stroke();
  ctx.restore();
}

function drawFlat(ctx,W,H,gw,gh){
  const gx=(W-gw)/2,gy=(H-gh)/2;
  ctx.save();
  ctx.shadowColor='rgba(26,23,20,.18)';ctx.shadowBlur=28;ctx.shadowOffsetY=8;
  ctx.fillStyle='transparent';ctx.fillRect(gx,gy,gw,gh);
  ctx.restore();
  drawGlass(ctx,gx,gy,gw,gh,userImg);
}

function drawDesk(ctx,W,H,gw,gh){
  ctx.save();
  const floorY=H*.72;
  const bg=ctx.createLinearGradient(0,0,0,H);
  bg.addColorStop(0,'#e8e4dc');bg.addColorStop(1,'#d5cfc5');
  ctx.fillStyle=bg;ctx.fillRect(0,0,W,H);
  ctx.fillStyle='#c8c0b4';ctx.fillRect(0,floorY,W,H-floorY);
  ctx.strokeStyle='rgba(26,23,20,.08)';ctx.lineWidth=1;
  ctx.beginPath();ctx.moveTo(0,floorY);ctx.lineTo(W,floorY);ctx.stroke();
  ctx.restore();
  const gx=(W-gw)/2,gy=floorY-gh-4;
  ctx.save();
  ctx.shadowColor='rgba(0,0,0,.22)';ctx.shadowBlur=20;ctx.shadowOffsetY=6;
  ctx.fillStyle='transparent';ctx.fillRect(gx,gy,gw,gh);
  ctx.restore();
  const sh=ctx.createLinearGradient(gx+gw*.1,floorY,gx+gw*.5,floorY+gh*.4);
  sh.addColorStop(0,'rgba(0,0,0,.12)');sh.addColorStop(1,'rgba(0,0,0,0)');
  ctx.save();ctx.globalAlpha=.7;ctx.fillStyle=sh;
  ctx.beginPath();ctx.ellipse(gx+gw/2,floorY+4,gw*.4,12,0,0,Math.PI*2);ctx.fill();
  ctx.restore();
  drawGlass(ctx,gx,gy,gw,gh,userImg);
}

function drawHand(ctx,W,H,gw,gh){
  ctx.save();
  const bg=ctx.createLinearGradient(0,0,W,H);
  bg.addColorStop(0,'#e2ddd6');bg.addColorStop(1,'#ccc6bc');
  ctx.fillStyle=bg;ctx.fillRect(0,0,W,H);
  ctx.restore();
  const gx=(W-gw)/2,gy=H*.08;
  ctx.save();
  ctx.shadowColor='rgba(0,0,0,.25)';ctx.shadowBlur=22;ctx.shadowOffsetY=8;
  ctx.fillStyle='transparent';ctx.fillRect(gx,gy,gw,gh);
  ctx.restore();
  drawGlass(ctx,gx,gy,gw,gh,userImg);
  ctx.save();
  ctx.fillStyle='#d4a574';
  const hw=gw*.55,hh=H*.28,hx=gx+(gw-hw)/2,hy=gy+gh-4;
  const gr=ctx.createLinearGradient(hx,hy,hx+hw,hy);
  gr.addColorStop(0,'#c49060');gr.addColorStop(.3,'#e0b888');gr.addColorStop(.7,'#d4a574');gr.addColorStop(1,'#b87d50');
  ctx.fillStyle=gr;
  ctx.beginPath();ctx.roundRect(hx,hy,hw,hh,12);ctx.fill();
  ctx.strokeStyle='rgba(0,0,0,.1)';ctx.lineWidth=1;ctx.stroke();
  ctx.restore();
}

function drawWall(ctx,W,H,gw,gh){
  ctx.save();
  const bg=ctx.createLinearGradient(0,0,0,H);
  bg.addColorStop(0,'#ede8df');bg.addColorStop(1,'#e0d9ce');
  ctx.fillStyle=bg;ctx.fillRect(0,0,W,H);
  for(let i=0;i<W;i+=22){
    ctx.strokeStyle='rgba(26,23,20,.04)';ctx.lineWidth=.5;
    ctx.beginPath();ctx.moveTo(i,0);ctx.lineTo(i,H);ctx.stroke();
  }
  ctx.restore();
  const gx=(W-gw)/2,gy=(H-gh)/2;
  ctx.save();
  ctx.shadowColor='rgba(0,0,0,.28)';ctx.shadowBlur=32;ctx.shadowOffsetX=6;ctx.shadowOffsetY=10;
  ctx.fillStyle='transparent';ctx.fillRect(gx,gy,gw,gh);
  ctx.restore();
  ctx.save();
  ctx.fillStyle='rgba(0,0,0,.06)';
  ctx.beginPath();ctx.ellipse(gx+gw/2,gy+gh+10,gw*.35,8,0,0,Math.PI*2);ctx.fill();
  ctx.restore();
  drawGlass(ctx,gx,gy,gw,gh,userImg);
  ctx.save();
  ctx.fillStyle='#aaa';ctx.shadowColor='rgba(0,0,0,.3)';ctx.shadowBlur=3;
  ctx.beginPath();ctx.arc(gx+gw/2,gy-6,5,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#888';ctx.beginPath();ctx.arc(gx+gw/2,gy-6,2,0,Math.PI*2);ctx.fill();
  ctx.restore();
}

function drawAngle(ctx,W,H,gw,gh){
  ctx.save();
  const bg=ctx.createLinearGradient(0,0,W,H);
  bg.addColorStop(0,'#ddd8cf');bg.addColorStop(1,'#ccc5ba');
  ctx.fillStyle=bg;ctx.fillRect(0,0,W,H);
  ctx.restore();
  const cx=W/2,cy=H/2;
  const ang=-0.18;
  const cos=Math.cos(ang),sin=Math.sin(ang);
  const hw=gw/2,hh=gh/2;
  const pts=[[-hw,-hh],[hw,-hh],[hw,hh],[-hw,hh]].map(([x,y])=>({x:cx+x*cos-y*sin,y:cy+x*sin+y*cos}));
  const[tl,tr,br,bl]=pts;
  ctx.save();
  ctx.shadowColor='rgba(0,0,0,.25)';ctx.shadowBlur=24;ctx.shadowOffsetY=8;
  ctx.beginPath();ctx.moveTo(tl.x,tl.y);ctx.lineTo(tr.x,tr.y);ctx.lineTo(br.x,br.y);ctx.lineTo(bl.x,bl.y);ctx.closePath();
  ctx.fillStyle='transparent';ctx.fill();
  ctx.restore();
  ctx.save();
  ctx.beginPath();ctx.moveTo(tl.x,tl.y);ctx.lineTo(tr.x,tr.y);ctx.lineTo(br.x,br.y);ctx.lineTo(bl.x,bl.y);ctx.closePath();ctx.clip();
  if(userImg)ctx.drawImage(userImg,tl.x,tl.y,tr.x-tl.x,bl.y-tl.y);
  else{ctx.fillStyle='#c0c8d8';ctx.fill();}
  const sh=ctx.createLinearGradient(tl.x,tl.y,tl.x+(tr.x-tl.x)*.5,tl.y+(bl.y-tl.y)*.45);
  sh.addColorStop(0,'rgba(255,255,255,.25)');sh.addColorStop(.25,'rgba(255,255,255,.08)');sh.addColorStop(1,'rgba(255,255,255,0)');
  ctx.fillStyle=sh;ctx.fillRect(tl.x-2,tl.y-2,tr.x-tl.x+4,bl.y-tl.y+4);
  ctx.restore();
  ctx.save();
  ctx.strokeStyle='rgba(255,255,255,.45)';ctx.lineWidth=1.5;
  ctx.beginPath();ctx.moveTo(tl.x,tl.y);ctx.lineTo(tr.x,tr.y);ctx.lineTo(br.x,br.y);ctx.lineTo(bl.x,bl.y);ctx.closePath();ctx.stroke();
  ctx.fillStyle='rgba(0,0,0,.38)';const d=5;
  ctx.beginPath();ctx.moveTo(tl.x,tl.y);ctx.lineTo(tl.x-d,tl.y+d*.5);ctx.lineTo(bl.x-d,bl.y+d*.5);ctx.lineTo(bl.x,bl.y);ctx.closePath();ctx.fill();
  ctx.restore();
}

function setScene(s,el){
  currentScene=s;
  document.querySelectorAll('.scene-pill').forEach(b=>b.classList.remove('active'));
  el.classList.add('active');
  renderMockup();
}

function gotoSceneAndStudio(s){
  currentScene=s;
  document.querySelectorAll('.scene-pill').forEach(b=>b.classList.remove('active'));
  const pills=document.querySelectorAll('.scene-pill');
  const map={flat:0,desk:1,wall:2,hand:3,angle:4};
  if(pills[map[s]])pills[map[s]].classList.add('active');
  gotoPage('studio');
  setTimeout(renderMockup,60);
}

function renderGallery(){
  [{id:'gc-desk',scene:'desk',W:900,H:337},
   {id:'gc-hand',scene:'hand',W:440,H:330},
   {id:'gc-wall',scene:'wall',W:440,H:330},
   {id:'gc-angle',scene:'angle',W:440,H:330}
  ].forEach(({id,scene,W,H})=>{
    const el=document.getElementById(id);if(!el)return;
    el.width=W;el.height=H;
    const ctx=el.getContext('2d');
    ctx.clearRect(0,0,W,H);
    const{gw,gh}=getGlassDims(W,H);
    const saved=currentScene;currentScene=scene;
    ({desk:drawDesk,hand:drawHand,wall:drawWall,angle:drawAngle}[scene])(ctx,W,H,gw,gh);
    currentScene=saved;
  });
}

function updateSpecs(){
  const dpi=naturalW?Math.round((naturalW/(currentSize.w/25.4)+naturalH/(currentSize.h/25.4))/2):0;
  const mp=naturalW?(naturalW*naturalH/1e6).toFixed(1):null;
  const qLabel=dpi>=300?'MÜKEMMEL ✓':dpi>=150?'ORTA':'DÜŞÜK';
  const qClass=dpi>=300?'ok':dpi>=150?'warn':'fail';
  const qPct=dpi?Math.min(100,Math.round(dpi/3)):0;
  const s=(id,v,c='')=>{const el=document.getElementById(id);if(el){el.textContent=v;if(c)el.className='spec-val '+c;}};
  s('sp-res',naturalW?naturalW+'×'+naturalH+'px':'—');
  s('sp-dpi',dpi?dpi+' DPI':'—',qClass);
  s('sp-mp',mp?mp+' MP':'—');
  s('sp-qlabel',dpi?qLabel:'—',qClass);
  const qb=document.getElementById('sp-qbar');
  if(qb){qb.style.width=qPct+'%';qb.style.background=dpi>=300?'#2d5a27':dpi>=150?'#f39c12':'#c0392b';}
  s('sp-size',currentSize.id+' · '+currentSize.w+'×'+currentSize.h+'mm');
  s('sp-orient',currentOrientation==='portrait'?'Dikey':'Yatay');
  const an=Object.keys(addons).map(k=>({stand:'Stand',wood:'Ahşap',matte:'Mat Cam',qr:'QR'}[k])).join(', ');
  s('sp-addons',an||'Yok');
  s('sp-order',document.getElementById('orderId')?.value||'—');
  let t=currentSize.price;Object.values(addons).forEach(a=>t+=a.price);
  s('sp-total','₺'+t);
}

async function sendPrint(){
  if(!userImg){toast('⚠ Önce görsel yükleyin',true);return;}
  const btn=document.getElementById('printBtn');
  if(btn){btn.innerHTML='<span class="spin"></span>&nbsp; Gönderiliyor...';btn.disabled=true;}

  const order={
    order_id:document.getElementById('orderId').value,
    customer_name:document.getElementById('custName').value||'—',
    product:'Cam Baskı '+currentSize.id,
    size:currentSize.w+'×'+currentSize.h+'mm',
    orientation:currentOrientation,
    addons:Object.keys(addons),
    price:currentSize.price+Object.values(addons).reduce((s,a)=>s+a.price,0),
    thumbnail:document.getElementById('mockupCanvas').toDataURL('image/jpeg',.5),
    sent_at:new Date().toISOString()
  };

  try {
    const res=await fetch('save_order.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(order)});
    const data=await res.json();
    if(data.ok){
      toast('✓ Gönderildi: '+data.siparis_no);
      document.getElementById('orderId').value='SHP-'+Math.floor(10000+Math.random()*90000);
      updateChecklist();
    } else {
      toast('✕ Hata: '+(data.msg||'Bilinmeyen hata'),true);
    }
  } catch(e){
    toast('✕ Bağlantı hatası',true);
  }

  const icon='<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>';
  if(btn){btn.innerHTML=icon+' Matbaaya Gönder';btn.disabled=false;}
}

function toast(msg,isErr=false){
  const el=document.getElementById('toast');
  el.textContent=msg;el.className='show '+(isErr?'err':'ok');
  clearTimeout(el._t);el._t=setTimeout(()=>el.className='',3200);
}

updateChecklist();updateSubtotal();renderMockup();
</script>
</body>
</html>
