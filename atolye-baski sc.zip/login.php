<?php
session_start();
require_once 'config.php';

if (isset($_SESSION['user_id'])) {
    header("Location: " . ($_SESSION['user_role'] === 'admin' ? 'admin.php' : 'index.php'));
    exit;
}

$mesaj = '';
$mesaj_tur = '';
$yonlendir = false;
$hedef_sayfa = 'index.php';

if (isset($_GET['msg']) && $_GET['msg'] == 'yeni_kayit') {
    $mesaj = 'Kayıt başarılı! Giriş yapabilirsiniz.';
    $mesaj_tur = 'info';
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $eposta = trim($_POST['eposta']);
    $sifre = $_POST['sifre'];

    if (!empty($eposta) && !empty($sifre)) {
        $sorgu = $db->prepare("SELECT * FROM kullanicilar WHERE eposta = ?");
        $sorgu->execute([$eposta]);
        $kullanici = $sorgu->fetch(PDO::FETCH_ASSOC);

        if ($kullanici && password_verify($sifre, $kullanici['sifre'])) {
            $_SESSION['user_id'] = $kullanici['id'];
            $_SESSION['user_name'] = $kullanici['ad_soyad'];
            $_SESSION['user_role'] = $kullanici['rol'];
            $hedef_sayfa = $kullanici['rol'] === 'admin' ? 'admin.php' : 'index.php';
            $mesaj = 'Giriş başarılı! Yönlendiriliyorsunuz...';
            $mesaj_tur = 'success';
            $yonlendir = true;
        } else {
            $mesaj = 'E-posta adresi veya şifre hatalı!';
            $mesaj_tur = 'danger';
        }
    } else {
        $mesaj = 'Lütfen tüm alanları doldurun!';
        $mesaj_tur = 'warning';
    }
}

try {
    $ayarlar = $db->query("SELECT logo_metni FROM ayarlar LIMIT 1")->fetch(PDO::FETCH_ASSOC);
    $logo_metni = $ayarlar['logo_metni'];
} catch (Exception $e) {
    $logo_metni = 'Atölye Baskı';
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Giriş Yap — <?php echo htmlspecialchars($logo_metni); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Mono:wght@300;400;500&family=Instrument+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root{--bg:#f7f5f0;--bg2:#eeeae2;--ink:#1a1714;--ink2:#4a4540;--ink3:#8a8078;--acc:#2d5a27;--acc2:#3d7a35;--acc-l:rgba(45,90,39,.1);--border:rgba(26,23,20,.11);--border2:rgba(26,23,20,.2);--r:6px;--r2:14px}
        *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
        body{background:var(--bg);color:var(--ink);font-family:'Instrument Sans',sans-serif;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px}
        .card{background:#fff;border-radius:var(--r2);border:1px solid var(--border);box-shadow:0 20px 60px rgba(26,23,20,.1);width:100%;max-width:440px;padding:44px 40px}
        .logo{font-family:'DM Serif Display',serif;font-size:24px;color:var(--ink);text-decoration:none;display:block;margin-bottom:32px}
        .logo span{color:var(--acc)}
        h2{font-family:'DM Serif Display',serif;font-size:28px;margin-bottom:4px}
        .sub{font-size:12px;color:var(--ink3);font-family:'DM Mono',monospace;margin-bottom:28px}
        .field{margin-bottom:16px}
        .field label{display:block;font-size:10px;font-weight:600;letter-spacing:1.2px;text-transform:uppercase;color:var(--ink3);font-family:'DM Mono',monospace;margin-bottom:7px}
        .field input{width:100%;padding:11px 14px;border:1.5px solid var(--border);border-radius:var(--r);background:var(--bg);color:var(--ink);font-family:'Instrument Sans',sans-serif;font-size:14px;outline:none;transition:border-color .18s}
        .field input:focus{border-color:var(--acc);background:#fff}
        .btn{width:100%;padding:13px;border-radius:var(--r);background:var(--acc);color:#fff;font-family:'Instrument Sans',sans-serif;font-size:14px;font-weight:700;border:none;cursor:pointer;transition:all .18s;letter-spacing:.5px;margin-top:8px}
        .btn:hover{background:var(--acc2)}
        .links{margin-top:22px;text-align:center;font-size:13px;color:var(--ink3)}
        .links a{color:var(--acc);font-weight:600;text-decoration:none}
        .links a:hover{text-decoration:underline}
        .alert{padding:12px 16px;border-radius:var(--r);font-size:13px;margin-bottom:20px;border:1px solid}
        .alert-success{background:#e8f5e4;color:var(--acc);border-color:rgba(45,90,39,.2)}
        .alert-danger{background:#fde8e8;color:#c0392b;border-color:rgba(192,57,43,.2)}
        .alert-warning{background:#fef9e4;color:#8a6d0a;border-color:rgba(138,109,10,.2)}
        .alert-info{background:#e8f0fe;color:#1a56db;border-color:rgba(26,86,219,.2)}
        .success-wrap{text-align:center;padding:20px 0}
        .check{font-size:64px;margin-bottom:16px}
        .spinner{display:inline-block;width:28px;height:28px;border:3px solid var(--border);border-top-color:var(--acc);border-radius:50%;animation:spin .8s linear infinite;margin-top:20px}
        @keyframes spin{to{transform:rotate(360deg)}}
    </style>
</head>
<body>
<div class="card">
    <a href="index.php" class="logo">◈ <span><?php echo htmlspecialchars($logo_metni); ?></span></a>

    <?php if ($yonlendir): ?>
        <div class="success-wrap">
            <div class="check">✓</div>
            <h2>Hoş Geldiniz!</h2>
            <p style="color:var(--ink3);margin-top:8px;font-size:13px">Yönlendiriliyorsunuz...</p>
            <div class="spinner"></div>
        </div>
        <script>setTimeout(()=>location.href='<?php echo $hedef_sayfa; ?>',2200)</script>
    <?php else: ?>
        <h2>Giriş Yap</h2>
        <p class="sub">Devam etmek için bilgilerinizi girin</p>

        <?php if ($mesaj): ?>
            <div class="alert alert-<?php echo $mesaj_tur; ?>"><?php echo $mesaj; ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="field">
                <label>E-Posta</label>
                <input type="email" name="eposta" required placeholder="mail@ornek.com">
            </div>
            <div class="field">
                <label>Şifre</label>
                <input type="password" name="sifre" required placeholder="••••••••">
            </div>
            <button type="submit" class="btn">Giriş Yap</button>
        </form>

        <div class="links">
            Hesabın yok mu? <a href="register.php">Kayıt Ol</a>
            &nbsp;·&nbsp; <a href="index.php">Ana Sayfa</a>
        </div>
    <?php endif; ?>
</div>
</body>
</html>
