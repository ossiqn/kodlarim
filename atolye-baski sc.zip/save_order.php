<?php
session_start();
require_once 'config.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['ok' => false, 'msg' => 'Oturum açmanız gerekiyor.']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
if (!$data) {
    echo json_encode(['ok' => false, 'msg' => 'Geçersiz veri.']);
    exit;
}

$siparis_no = trim($data['order_id'] ?? '');
$musteri_adi = trim($data['customer_name'] ?? '');
$urun = trim($data['product'] ?? 'Cam Baskı');
$boyut = trim($data['size'] ?? '');
$yon = trim($data['orientation'] ?? '');
$eklentiler = implode(', ', $data['addons'] ?? []);
$fiyat = floatval($data['price'] ?? 0);
$thumbnail = $data['thumbnail'] ?? null;
$kullanici_id = $_SESSION['user_id'];

if (empty($siparis_no)) {
    echo json_encode(['ok' => false, 'msg' => 'Sipariş numarası boş olamaz.']);
    exit;
}

$kontrol = $db->prepare("SELECT id FROM siparisler WHERE siparis_no = ?");
$kontrol->execute([$siparis_no]);
if ($kontrol->rowCount() > 0) {
    $siparis_no = $siparis_no . '-' . rand(100, 999);
}

$ekle = $db->prepare("INSERT INTO siparisler (siparis_no, kullanici_id, musteri_adi, urun, boyut, yon, eklentiler, fiyat, thumbnail, durum) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'BASKIYA GÖNDERİLDİ')");

if ($ekle->execute([$siparis_no, $kullanici_id, $musteri_adi, $urun, $boyut, $yon, $eklentiler, $fiyat, $thumbnail])) {
    echo json_encode(['ok' => true, 'siparis_no' => $siparis_no]);
} else {
    echo json_encode(['ok' => false, 'msg' => 'Kayıt hatası.']);
}
