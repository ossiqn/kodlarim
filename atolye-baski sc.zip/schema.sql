CREATE DATABASE IF NOT EXISTS baskisistemi CHARACTER SET utf8mb4 COLLATE utf8mb4_turkish_ci;
USE baskisistemi;

CREATE TABLE IF NOT EXISTS kullanicilar (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ad_soyad VARCHAR(100) NOT NULL,
    eposta VARCHAR(150) NOT NULL UNIQUE,
    sifre VARCHAR(255) NOT NULL,
    rol ENUM('kullanici','admin') DEFAULT 'kullanici',
    olusturma DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS siparisler (
    id INT AUTO_INCREMENT PRIMARY KEY,
    siparis_no VARCHAR(30) NOT NULL UNIQUE,
    kullanici_id INT NOT NULL,
    musteri_adi VARCHAR(100),
    urun VARCHAR(100),
    boyut VARCHAR(50),
    yon VARCHAR(20),
    eklentiler TEXT,
    fiyat DECIMAL(10,2),
    thumbnail LONGTEXT,
    durum ENUM('BEKLEMEDE','BASKIYA GÖNDERİLDİ','TAMAMLANDI','İPTAL') DEFAULT 'BEKLEMEDE',
    olusturma DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (kullanici_id) REFERENCES kullanicilar(id)
);

CREATE TABLE IF NOT EXISTS ayarlar (
    id INT AUTO_INCREMENT PRIMARY KEY,
    logo_metni VARCHAR(100) DEFAULT 'Atölye Baskı',
    site_adi VARCHAR(100) DEFAULT 'Cam Baskı Sistemi'
);

INSERT IGNORE INTO ayarlar (id, logo_metni, site_adi) VALUES (1, 'Atölye Baskı', 'Cam Baskı Sistemi');

INSERT IGNORE INTO kullanicilar (ad_soyad, eposta, sifre, rol) VALUES
('Admin', 'admin@admin.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');
