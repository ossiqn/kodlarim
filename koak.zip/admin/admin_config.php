<?php
session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$db_path = __DIR__ . '/database.db';

try {
    $db = new PDO('sqlite:' . $db_path);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    $check = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='admin_users'");
    
    if (!$check || !$check->fetch()) {
        
        $db->exec("CREATE TABLE settings (
            id INTEGER PRIMARY KEY,
            setting_key TEXT UNIQUE,
            setting_value TEXT
        )");
        
        $db->exec("CREATE TABLE pages (
            id INTEGER PRIMARY KEY,
            page_name TEXT UNIQUE,
            page_title TEXT,
            page_content TEXT,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )");
        
        $db->exec("CREATE TABLE gallery (
            id INTEGER PRIMARY KEY,
            title TEXT,
            description TEXT,
            image_path TEXT,
            sort_order INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )");
        
        $db->exec("CREATE TABLE news (
            id INTEGER PRIMARY KEY,
            title TEXT,
            description TEXT,
            content TEXT,
            image_path TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            status TEXT DEFAULT 'active'
        )");
        
        $db->exec("CREATE TABLE sliders (
            id INTEGER PRIMARY KEY,
            title TEXT,
            description TEXT,
            image_path TEXT,
            sort_order INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )");
        
        $db->exec("CREATE TABLE admin_users (
            id INTEGER PRIMARY KEY,
            username TEXT UNIQUE,
            password TEXT,
            email TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )");
        
        $hashed = password_hash('admin123', PASSWORD_BCRYPT);
        $db->exec("INSERT INTO admin_users (username, password, email) VALUES ('admin', '$hashed', 'admin@example.com')");
    }
    
} catch(Exception $e) {
    die("VERITABANI HATASI: " . $e->getMessage() . " --- " . $e->getTraceAsString());
}

function e($text) {
    return htmlspecialchars($text ?? '', ENT_QUOTES, 'UTF-8');
}

function getSetting($key, $default = '') {
    global $db;
    try {
        $stmt = $db->prepare("SELECT setting_value FROM settings WHERE setting_key = ?");
        if (!$stmt) return $default;
        $stmt->execute([$key]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result ? $result['setting_value'] : $default;
    } catch(Exception $e) {
        return $default;
    }
}

function updateSetting($key, $value) {
    global $db;
    try {
        $stmt = $db->prepare("INSERT OR REPLACE INTO settings (setting_key, setting_value) VALUES (?, ?)");
        return $stmt && $stmt->execute([$key, $value]);
    } catch(Exception $e) {
        return false;
    }
}

function getPageContent($page_name) {
    global $db;
    try {
        $stmt = $db->prepare("SELECT page_content, page_title FROM pages WHERE page_name = ?");
        if (!$stmt) return ['page_content' => '', 'page_title' => ''];
        $stmt->execute([$page_name]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: ['page_content' => '', 'page_title' => ''];
    } catch(Exception $e) {
        return ['page_content' => '', 'page_title' => ''];
    }
}

function updatePageContent($page_name, $title, $content) {
    global $db;
    try {
        $stmt = $db->prepare("INSERT OR REPLACE INTO pages (page_name, page_title, page_content, updated_at) VALUES (?, ?, ?, CURRENT_TIMESTAMP)");
        return $stmt && $stmt->execute([$page_name, $title, $content]);
    } catch(Exception $e) {
        return false;
    }
}

function getNews($options = []) {
    global $db;
    try {
        $limit = $options['limit'] ?? 10;
        $stmt = $db->prepare("SELECT * FROM news WHERE status = 'active' ORDER BY created_at DESC LIMIT ?");
        if (!$stmt) return [];
        $stmt->execute([$limit]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch(Exception $e) {
        return [];
    }
}

function isLoggedIn() {
    return isset($_SESSION['admin_id']) && !empty($_SESSION['admin_id']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit;
    }
}

function logout() {
    session_destroy();
    header('Location: login.php');
    exit;
}
?>