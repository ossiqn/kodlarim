<?php
require_once __DIR__ . '/config.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'update_site_settings':
                $keys = [
                    'site_title','email','phone','address','facebook','twitter','instagram','youtube',
                    'hero_title','hero_desc','about_title','about_desc',
                    'stat1_num','stat1_text','stat2_num','stat2_text',
                    'stat3_num','stat3_text','stat4_num','stat4_text'
                ];
                foreach ($keys as $k) {
                    $val = $_POST[$k] ?? '';
                    $chk = $db->prepare("SELECT COUNT(*) FROM settings WHERE setting_key = ?");
                    $chk->execute([$k]);
                    if ($chk->fetchColumn() > 0) {
                        $db->prepare("UPDATE settings SET setting_value = ? WHERE setting_key = ?")->execute([$val, $k]);
                    } else {
                        $db->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?)")->execute([$k, $val]);
                    }
                }
                if (!empty($_FILES['logo']['name'])) {
                    $upload_dir = __DIR__ . '/uploads/';
                    if (!file_exists($upload_dir)) mkdir($upload_dir, 0777, true);
                    $file_name = 'logo_' . time() . '.' . pathinfo($_FILES['logo']['name'], PATHINFO_EXTENSION);
                    if (move_uploaded_file($_FILES['logo']['tmp_name'], $upload_dir . $file_name)) {
                        $db->prepare("UPDATE settings SET setting_value = ? WHERE setting_key = 'logo'")->execute(['uploads/' . $file_name]);
                    }
                }
                $success = 'Site ayarları başarıyla güncellendi!';
                break;
        }
    }
}

$defaults = [
    'site_title' => 'KOAK | Arama Kurtarma Derneği',
    'email'      => 'bilgi@koak.org.tr',
    'phone'      => '+90 537 608 85 01',
    'address'    => 'Örnek Mah. Kurtuluş Cad. No:123',
    'facebook'   => '#', 'twitter' => '#', 'instagram' => '#', 'youtube' => '#', 'logo' => '',
    'hero_title' => 'HAYAT KURTARMAK İÇİN BURADAYIZ',
    'hero_desc'  => 'Gönüllü ekibimizle afetlerde ve acil durumlarda din, dil, ırk ayrımı gözetmeksizin profesyonel arama kurtarma hizmeti veriyoruz.',
    'about_title'=> 'Biz Kimiz?',
    'about_desc' => 'Doğal afetlerde ve acil durumlarda yardıma ihtiyacı olan her canlının yanında olmak için kurulmuş, tamamen gönüllülük esasına dayalı bir arama kurtarma derneğiyiz. Düzenli eğitimlerimiz ve donanımlı ekibimizle her an göreve hazırız.',
    'stat1_num'  => '450', 'stat1_text' => 'Aktif Gönüllü',
    'stat2_num'  => '120', 'stat2_text' => 'Operasyon',
    'stat3_num'  => '3000', 'stat3_text' => 'Kurtarılan Can',
    'stat4_num'  => '85',  'stat4_text' => 'Eğitim Semineri'
];
$settings = $defaults;
try {
    $rows = $db->query("SELECT setting_key, setting_value FROM settings")->fetchAll(PDO::FETCH_KEY_PAIR);
    $settings = array_merge($defaults, $rows);
} catch(Exception $e) {}

try {
    $pages_count      = $db->query("SELECT COUNT(*) as count FROM pages")->fetch()['count'];
    $gallery_count    = $db->query("SELECT COUNT(*) as count FROM gallery")->fetch()['count'];
    $news_count       = $db->query("SELECT COUNT(*) as count FROM news")->fetch()['count'];
    $sliders_count    = $db->query("SELECT COUNT(*) as count FROM sliders")->fetch()['count'];
    $categories_count = $db->query("SELECT COUNT(*) as count FROM categories")->fetch()['count'];
} catch(Exception $e) {
    $pages_count = $gallery_count = $news_count = $sliders_count = $categories_count = 0;
}

$admin_name = e($_SESSION['admin_user']['fullname'] ?? $_SESSION['admin_user']['username'] ?? 'Admin');
$admin_initials = strtoupper(substr($admin_name, 0, 2));
?>
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard — Admin Panel</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
  <style>
    *, *::before, *::after { margin: 0; padding: 0; box-sizing: border-box; }

    :root {
      --sidebar-w: 248px;
      --topbar-h:  60px;
      --bg:        #f4f6f9;
      --surface:   #ffffff;
      --border:    #e8eaf0;
      --text:      #1a1d2e;
      --text-2:    #5a6272;
      --text-3:    #9aa3b2;
      --accent:    #4f6ef7;
      --accent-2:  #6c47ff;
      --accent-bg: #eef1fe;
      --green:     #22c55e;
      --green-bg:  #dcfce7;
      --amber:     #f59e0b;
      --amber-bg:  #fef3c7;
      --rose:      #f43f5e;
      --rose-bg:   #ffe4e6;
      --purple:    #a855f7;
      --purple-bg: #f3e8ff;
      --radius:    12px;
      --radius-sm: 8px;
      --shadow:    0 1px 3px rgba(0,0,0,0.07), 0 4px 12px rgba(0,0,0,0.04);
      --shadow-md: 0 4px 16px rgba(0,0,0,0.10);
    }

    html { font-size: 15px; }
    body { font-family: 'Plus Jakarta Sans', sans-serif; background: var(--bg); color: var(--text); min-height: 100vh; display: flex; }

    .sidebar { width: var(--sidebar-w); background: var(--surface); border-right: 1px solid var(--border); display: flex; flex-direction: column; position: fixed; top: 0; left: 0; bottom: 0; z-index: 100; transition: transform .28s cubic-bezier(.4,0,.2,1); }
    .sidebar-logo { height: var(--topbar-h); display: flex; align-items: center; padding: 0 20px; border-bottom: 1px solid var(--border); gap: 10px; text-decoration: none; }
    .sidebar-logo-icon { width: 32px; height: 32px; background: linear-gradient(135deg, var(--accent), var(--accent-2)); border-radius: 9px; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 14px; flex-shrink: 0; }
    .sidebar-logo-text { font-size: 15px; font-weight: 700; color: var(--text); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }

    .sidebar-nav { flex: 1; padding: 16px 12px; overflow-y: auto; }
    .nav-label { font-size: 10.5px; font-weight: 700; letter-spacing: .1em; text-transform: uppercase; color: var(--text-3); padding: 0 8px; margin: 18px 0 6px; }
    .nav-label:first-child { margin-top: 0; }

    .nav-item { display: flex; align-items: center; gap: 10px; padding: 9px 10px; border-radius: var(--radius-sm); text-decoration: none; color: var(--text-2); font-size: 13.5px; font-weight: 500; transition: background .15s, color .15s; margin-bottom: 2px; }
    .nav-item i { width: 18px; text-align: center; font-size: 13px; flex-shrink: 0; }
    .nav-item:hover { background: var(--bg); color: var(--text); }
    .nav-item.active { background: var(--accent-bg); color: var(--accent); font-weight: 600; }
    .nav-item.active i { color: var(--accent); }
    .nav-badge { margin-left: auto; background: var(--accent-bg); color: var(--accent); font-size: 11px; font-weight: 700; padding: 2px 7px; border-radius: 20px; }

    .sidebar-footer { padding: 14px 12px; border-top: 1px solid var(--border); }
    .sidebar-user { display: flex; align-items: center; gap: 10px; padding: 9px 10px; border-radius: var(--radius-sm); cursor: pointer; transition: background .15s; }
    .sidebar-user:hover { background: var(--bg); }
    .user-avatar { width: 32px; height: 32px; border-radius: 50%; background: linear-gradient(135deg, var(--accent), var(--accent-2)); color: #fff; font-size: 12px; font-weight: 700; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
    .user-info { flex: 1; min-width: 0; }
    .user-name { font-size: 13px; font-weight: 600; color: var(--text); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .user-role { font-size: 11px; color: var(--text-3); }
    .sidebar-user .logout-icon { color: var(--text-3); font-size: 13px; flex-shrink: 0; }

    .sidebar-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.4); z-index: 99; }
    .topbar { position: fixed; top: 0; left: var(--sidebar-w); right: 0; height: var(--topbar-h); background: var(--surface); border-bottom: 1px solid var(--border); display: flex; align-items: center; padding: 0 24px; gap: 16px; z-index: 90; }
    .topbar-hamburger { display: none; background: none; border: none; cursor: pointer; padding: 6px; color: var(--text-2); font-size: 18px; }
    .topbar-title { font-size: 16px; font-weight: 700; color: var(--text); }
    .topbar-right { margin-left: auto; display: flex; align-items: center; gap: 10px; }
    .topbar-date { font-size: 12.5px; color: var(--text-3); }

    .main { margin-left: var(--sidebar-w); margin-top: var(--topbar-h); padding: 28px 28px 48px; flex: 1; min-width: 0; }

    .alert { display: flex; align-items: flex-start; gap: 12px; padding: 14px 18px; border-radius: var(--radius); margin-bottom: 24px; font-size: 14px; }
    .alert-success { background: var(--green-bg); color: #15803d; border: 1px solid #bbf7d0; }
    .alert i { margin-top: 1px; flex-shrink: 0; }

    .page-header { display: flex; align-items: flex-end; justify-content: space-between; margin-bottom: 24px; flex-wrap: wrap; gap: 12px; }
    .page-header h1 { font-size: 22px; font-weight: 700; color: var(--text); }
    .page-header p { font-size: 13px; color: var(--text-3); margin-top: 2px; }

    .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 28px; }
    .stat-card { background: var(--surface); border-radius: var(--radius); padding: 20px 22px; box-shadow: var(--shadow); display: flex; flex-direction: column; gap: 14px; position: relative; overflow: hidden; border: 1px solid var(--border); transition: transform .18s, box-shadow .18s; }
    .stat-card:hover { transform: translateY(-2px); box-shadow: var(--shadow-md); }
    .stat-card-top { display: flex; align-items: center; justify-content: space-between; }
    .stat-icon-wrap { width: 42px; height: 42px; border-radius: 11px; display: flex; align-items: center; justify-content: center; font-size: 17px; flex-shrink: 0; }
    .stat-icon-wrap.blue   { background: var(--accent-bg);  color: var(--accent); }
    .stat-icon-wrap.green  { background: var(--green-bg);   color: var(--green); }
    .stat-icon-wrap.amber  { background: var(--amber-bg);   color: var(--amber); }
    .stat-icon-wrap.rose   { background: var(--rose-bg);    color: var(--rose); }
    .stat-icon-wrap.purple { background: var(--purple-bg);  color: var(--purple); }
    .stat-card-link { font-size: 12px; color: var(--text-3); text-decoration: none; display: flex; align-items: center; gap: 4px; transition: color .15s; }
    .stat-card-link:hover { color: var(--accent); }
    .stat-num { font-size: 30px; font-weight: 700; color: var(--text); line-height: 1; }
    .stat-label { font-size: 13px; color: var(--text-2); font-weight: 500; }

    .card { background: var(--surface); border-radius: var(--radius); box-shadow: var(--shadow); border: 1px solid var(--border); margin-bottom: 20px; }
    .card-header { padding: 18px 24px; border-bottom: 1px solid var(--border); display: flex; align-items: center; gap: 10px; }
    .card-header-icon { width: 34px; height: 34px; border-radius: 9px; background: var(--accent-bg); color: var(--accent); display: flex; align-items: center; justify-content: center; font-size: 14px; flex-shrink: 0; }
    .card-header h2 { font-size: 15px; font-weight: 700; color: var(--text); }
    .card-header p  { font-size: 12.5px; color: var(--text-3); margin-top: 1px; }
    .card-body { padding: 24px; }

    .form-section-label { font-size: 11px; font-weight: 700; letter-spacing: .1em; text-transform: uppercase; color: var(--text-3); margin: 0 0 14px; padding-bottom: 8px; border-bottom: 1px solid var(--border); }
    .form-section-label:not(:first-child) { margin-top: 30px; }

    .form-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 16px; }
    .form-group { margin-bottom: 16px; }
    .form-group:last-child { margin-bottom: 0; }

    label { display: block; margin-bottom: 6px; font-size: 13px; font-weight: 600; color: var(--text-2); }
    label i { margin-right: 5px; color: var(--text-3); font-size: 12px; }

    input[type="text"], input[type="email"], input[type="tel"], input[type="url"], input[type="number"] { width: 100%; padding: 9px 13px; border: 1.5px solid var(--border); border-radius: var(--radius-sm); font-size: 14px; font-family: 'Plus Jakarta Sans', sans-serif; color: var(--text); background: #fff; transition: border-color .18s, box-shadow .18s; outline: none; }
    input[type="text"]:focus, input[type="email"]:focus, input[type="tel"]:focus, input[type="url"]:focus, input[type="number"]:focus { border-color: var(--accent); box-shadow: 0 0 0 3px rgba(79,110,247,.12); }
    
    textarea { width: 100%; padding: 9px 13px; border: 1.5px solid var(--border); border-radius: var(--radius-sm); font-size: 14px; font-family: 'Plus Jakarta Sans', sans-serif; color: var(--text); background: #fff; outline: none; resize: vertical; min-height: 80px; }
    textarea:focus { border-color: var(--accent); box-shadow: 0 0 0 3px rgba(79,110,247,.12); }

    input[type="file"] { width: 100%; font-size: 13px; color: var(--text-2); padding: 8px 12px; border: 1.5px dashed var(--border); border-radius: var(--radius-sm); background: var(--bg); cursor: pointer; transition: border-color .18s; }
    input[type="file"]:hover { border-color: var(--accent); }

    .logo-status { display: inline-flex; align-items: center; gap: 6px; margin-top: 8px; font-size: 12.5px; color: var(--green); background: var(--green-bg); padding: 4px 10px; border-radius: 20px; }

    .btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 20px; border-radius: var(--radius-sm); font-size: 13.5px; font-weight: 600; font-family: 'Plus Jakarta Sans', sans-serif; cursor: pointer; border: none; transition: all .18s; text-decoration: none; white-space: nowrap; }
    .btn-primary { background: linear-gradient(135deg, var(--accent), var(--accent-2)); color: #fff; box-shadow: 0 2px 8px rgba(79,110,247,.28); }
    .btn-primary:hover { transform: translateY(-1px); box-shadow: 0 6px 16px rgba(79,110,247,.38); }

    .quick-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(190px, 1fr)); gap: 14px; }
    .quick-card { display: flex; flex-direction: column; align-items: flex-start; gap: 14px; padding: 20px; border-radius: var(--radius); text-decoration: none; border: 1.5px solid var(--border); background: var(--surface); transition: all .18s; }
    .quick-card:hover { transform: translateY(-2px); box-shadow: var(--shadow-md); border-color: transparent; }
    .quick-icon { width: 44px; height: 44px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 18px; }
    .quick-icon.blue   { background: var(--accent-bg);  color: var(--accent); }
    .quick-icon.green  { background: var(--green-bg);   color: var(--green); }
    .quick-icon.amber  { background: var(--amber-bg);   color: var(--amber); }
    .quick-icon.rose   { background: var(--rose-bg);    color: var(--rose); }
    .quick-icon.purple { background: var(--purple-bg);  color: var(--purple); }
    .quick-label { font-size: 13.5px; font-weight: 600; color: var(--text); }
    .quick-sub   { font-size: 12px; color: var(--text-3); margin-top: 2px; }
    .quick-arrow { margin-top: auto; font-size: 12px; color: var(--text-3); }

    .divider { border: none; border-top: 1px solid var(--border); margin: 20px 0; }

    @media (max-width: 1024px) { .stats-grid { grid-template-columns: repeat(3, 1fr); } }
    @media (max-width: 768px) {
      .sidebar { transform: translateX(-100%); }
      .sidebar.open { transform: translateX(0); box-shadow: var(--shadow-md); }
      .sidebar-overlay.open { display: block; }
      .topbar { left: 0; }
      .topbar-hamburger { display: flex; }
      .main { margin-left: 0; padding: 20px 16px 48px; }
      .stats-grid { grid-template-columns: repeat(2, 1fr); gap: 12px; }
      .quick-grid { grid-template-columns: repeat(2, 1fr); }
      .card-body { padding: 16px; }
      .card-header { padding: 14px 16px; }
    }
    @media (max-width: 480px) {
      .stats-grid { grid-template-columns: 1fr 1fr; gap: 10px; }
      .stat-num { font-size: 24px; }
      .quick-grid { grid-template-columns: 1fr 1fr; }
      .form-row { grid-template-columns: 1fr; }
      .main { padding: 16px 12px 60px; }
    }
  </style>
</head>
<body>

<div class="sidebar-overlay" id="overlay" onclick="closeSidebar()"></div>

<aside class="sidebar" id="sidebar">
  <a href="admin_index.php" class="sidebar-logo">
    <div class="sidebar-logo-icon"><i class="fas fa-shield-halved"></i></div>
    <span class="sidebar-logo-text">KOAK Admin</span>
  </a>

  <nav class="sidebar-nav">
    <div class="nav-label">Genel</div>
    <a href="admin_index.php" class="nav-item active">
      <i class="fas fa-gauge-high"></i> Dashboard
      <span class="nav-badge">Ana</span>
    </a>

    <div class="nav-label">İçerik Yönetimi</div>
    <a href="pages.php" class="nav-item">
      <i class="fas fa-file-lines"></i> Sayfalar
    </a>
    <a href="news.php" class="nav-item">
      <i class="fas fa-bullhorn"></i> Duyurular
    </a>
    <a href="categories.php" class="nav-item">
      <i class="fas fa-tags"></i> Kategoriler
    </a>
    <a href="gallery.php" class="nav-item">
      <i class="fas fa-images"></i> Galeri
    </a>
    <a href="sliders.php" class="nav-item">
      <i class="fas fa-layer-group"></i> Sliderlar
    </a>

    <div class="nav-label">Ayarlar</div>
    <a href="admin_index.php#settings" class="nav-item">
      <i class="fas fa-gear"></i> Site Ayarları
    </a>
  </nav>

  <div class="sidebar-footer">
    <div class="sidebar-user" onclick="logout()">
      <div class="user-avatar"><?php echo $admin_initials; ?></div>
      <div class="user-info">
        <div class="user-name"><?php echo $admin_name; ?></div>
        <div class="user-role">Yönetici</div>
      </div>
      <i class="fas fa-arrow-right-from-bracket logout-icon"></i>
    </div>
  </div>
</aside>

<header class="topbar">
  <button class="topbar-hamburger" onclick="openSidebar()">
    <i class="fas fa-bars"></i>
  </button>
  <div>
    <div class="topbar-title">Dashboard</div>
  </div>
  <div class="topbar-right">
    <span class="topbar-date" id="topbar-date"></span>
  </div>
</header>

<main class="main">

  <?php if ($success): ?>
    <div class="alert alert-success">
      <i class="fas fa-circle-check"></i>
      <span><?php echo $success; ?></span>
    </div>
  <?php endif; ?>

  <div class="page-header">
    <div>
      <h1>Genel Bakış</h1>
      <p>Hoşgeldiniz, <strong><?php echo $admin_name; ?></strong> — sitenizin özeti aşağıda.</p>
    </div>
  </div>

  <div class="stats-grid">
    <div class="stat-card">
      <div class="stat-card-top">
        <div class="stat-icon-wrap blue"><i class="fas fa-file-lines"></i></div>
        <a href="pages.php" class="stat-card-link">Yönet <i class="fas fa-arrow-right"></i></a>
      </div>
      <div>
        <div class="stat-num"><?php echo $pages_count; ?></div>
        <div class="stat-label">Toplam Sayfa</div>
      </div>
    </div>
    <div class="stat-card">
      <div class="stat-card-top">
        <div class="stat-icon-wrap amber"><i class="fas fa-bullhorn"></i></div>
        <a href="news.php" class="stat-card-link">Yönet <i class="fas fa-arrow-right"></i></a>
      </div>
      <div>
        <div class="stat-num"><?php echo $news_count; ?></div>
        <div class="stat-label">Duyuru</div>
      </div>
    </div>
    <div class="stat-card">
      <div class="stat-card-top">
        <div class="stat-icon-wrap purple"><i class="fas fa-tags"></i></div>
        <a href="categories.php" class="stat-card-link">Yönet <i class="fas fa-arrow-right"></i></a>
      </div>
      <div>
        <div class="stat-num"><?php echo $categories_count; ?></div>
        <div class="stat-label">Kategori</div>
      </div>
    </div>
    <div class="stat-card">
      <div class="stat-card-top">
        <div class="stat-icon-wrap green"><i class="fas fa-images"></i></div>
        <a href="gallery.php" class="stat-card-link">Yönet <i class="fas fa-arrow-right"></i></a>
      </div>
      <div>
        <div class="stat-num"><?php echo $gallery_count; ?></div>
        <div class="stat-label">Galeri Görseli</div>
      </div>
    </div>
    <div class="stat-card">
      <div class="stat-card-top">
        <div class="stat-icon-wrap rose"><i class="fas fa-layer-group"></i></div>
        <a href="sliders.php" class="stat-card-link">Yönet <i class="fas fa-arrow-right"></i></a>
      </div>
      <div>
        <div class="stat-num"><?php echo $sliders_count; ?></div>
        <div class="stat-label">Slider</div>
      </div>
    </div>
  </div>

  <div class="card" id="settings">
    <div class="card-header">
      <div class="card-header-icon"><i class="fas fa-gear"></i></div>
      <div>
        <h2>Site Ayarları ve İçerikler</h2>
        <p>Genel bilgiler, ana sayfa metinleri ve istatistikler</p>
      </div>
    </div>
    <div class="card-body">
      <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="action" value="update_site_settings">

        <p class="form-section-label">Temel İletişim Bilgileri</p>
        <div class="form-row">
          <div class="form-group">
            <label><i class="fas fa-heading"></i> Site Başlığı</label>
            <input type="text" name="site_title" value="<?php echo e($settings['site_title']); ?>" required placeholder="Site adınız">
          </div>
          <div class="form-group">
            <label><i class="fas fa-envelope"></i> E-posta</label>
            <input type="email" name="email" value="<?php echo e($settings['email']); ?>" required placeholder="ornek@site.com">
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label><i class="fas fa-phone"></i> Telefon</label>
            <input type="tel" name="phone" value="<?php echo e($settings['phone']); ?>" required placeholder="+90 5xx xxx xx xx">
          </div>
          <div class="form-group">
            <label><i class="fas fa-map-marker-alt"></i> Adres</label>
            <input type="text" name="address" value="<?php echo e($settings['address']); ?>" required placeholder="Mahalle, Cadde, No">
          </div>
        </div>

        <p class="form-section-label">Sosyal Medya</p>
        <div class="form-row">
          <div class="form-group">
            <label><i class="fab fa-facebook"></i> Facebook URL</label>
            <input type="url" name="facebook" value="<?php echo e($settings['facebook']); ?>" placeholder="https://facebook.com/...">
          </div>
          <div class="form-group">
            <label><i class="fab fa-x-twitter"></i> Twitter / X URL</label>
            <input type="url" name="twitter" value="<?php echo e($settings['twitter']); ?>" placeholder="https://twitter.com/...">
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label><i class="fab fa-instagram"></i> Instagram URL</label>
            <input type="url" name="instagram" value="<?php echo e($settings['instagram']); ?>" placeholder="https://instagram.com/...">
          </div>
          <div class="form-group">
            <label><i class="fab fa-youtube"></i> YouTube URL</label>
            <input type="url" name="youtube" value="<?php echo e($settings['youtube']); ?>" placeholder="https://youtube.com/...">
          </div>
        </div>

        <p class="form-section-label">Ana Sayfa (Karşılama Ekranı)</p>
        <div class="form-row">
          <div class="form-group">
            <label>Karşılama Başlığı</label>
            <input type="text" name="hero_title" value="<?php echo e($settings['hero_title']); ?>">
          </div>
          <div class="form-group">
            <label>Karşılama Açıklaması</label>
            <textarea name="hero_desc"><?php echo e($settings['hero_desc']); ?></textarea>
          </div>
        </div>

        <p class="form-section-label">Hakkımızda & Sahadaki İstatistikler</p>
        <div class="form-row">
          <div class="form-group">
            <label>Biz Kimiz? (Başlık)</label>
            <input type="text" name="about_title" value="<?php echo e($settings['about_title']); ?>">
          </div>
          <div class="form-group">
            <label>Kısa Tanıtım Yazısı</label>
            <textarea name="about_desc"><?php echo e($settings['about_desc']); ?></textarea>
          </div>
        </div>
        
        <div class="form-row">
          <div class="form-group">
            <label>1. İstatistik</label>
            <div style="display:flex; gap:10px;">
              <input type="number" name="stat1_num" value="<?php echo e($settings['stat1_num']); ?>" style="width:100px;" placeholder="Sayı">
              <input type="text" name="stat1_text" value="<?php echo e($settings['stat1_text']); ?>" placeholder="Başlık (Örn: Gönüllü)">
            </div>
          </div>
          <div class="form-group">
            <label>2. İstatistik</label>
            <div style="display:flex; gap:10px;">
              <input type="number" name="stat2_num" value="<?php echo e($settings['stat2_num']); ?>" style="width:100px;" placeholder="Sayı">
              <input type="text" name="stat2_text" value="<?php echo e($settings['stat2_text']); ?>" placeholder="Başlık (Örn: Operasyon)">
            </div>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label>3. İstatistik</label>
            <div style="display:flex; gap:10px;">
              <input type="number" name="stat3_num" value="<?php echo e($settings['stat3_num']); ?>" style="width:100px;" placeholder="Sayı">
              <input type="text" name="stat3_text" value="<?php echo e($settings['stat3_text']); ?>" placeholder="Başlık (Örn: Kurtarılan Can)">
            </div>
          </div>
          <div class="form-group">
            <label>4. İstatistik</label>
            <div style="display:flex; gap:10px;">
              <input type="number" name="stat4_num" value="<?php echo e($settings['stat4_num']); ?>" style="width:100px;" placeholder="Sayı">
              <input type="text" name="stat4_text" value="<?php echo e($settings['stat4_text']); ?>" placeholder="Başlık (Örn: Eğitim)">
            </div>
          </div>
        </div>

        <p class="form-section-label">Logo</p>
        <div class="form-group">
          <label><i class="fas fa-image"></i> Logo Görseli</label>
          <input type="file" name="logo" accept="image/*">
          <?php if ($settings['logo']): ?>
            <span class="logo-status"><i class="fas fa-circle-check"></i> Logo yüklendi</span>
          <?php endif; ?>
        </div>

        <hr class="divider">
        <button type="submit" class="btn btn-primary">
          <i class="fas fa-floppy-disk"></i> Değişiklikleri Kaydet
        </button>
      </form>
    </div>
  </div>

  <div class="card">
    <div class="card-header">
      <div class="card-header-icon"><i class="fas fa-bolt"></i></div>
      <div>
        <h2>Hızlı Erişim</h2>
        <p>Yönetim bölümlerine doğrudan gidin</p>
      </div>
    </div>
    <div class="card-body">
      <div class="quick-grid">
        <a href="pages.php" class="quick-card">
          <div class="quick-icon blue"><i class="fas fa-file-lines"></i></div>
          <div>
            <div class="quick-label">Sayfa Yönetimi</div>
            <div class="quick-sub"><?php echo $pages_count; ?> sayfa</div>
          </div>
          <span class="quick-arrow"><i class="fas fa-arrow-right"></i></span>
        </a>
        <a href="news.php" class="quick-card">
          <div class="quick-icon amber"><i class="fas fa-bullhorn"></i></div>
          <div>
            <div class="quick-label">Duyurular</div>
            <div class="quick-sub"><?php echo $news_count; ?> duyuru</div>
          </div>
          <span class="quick-arrow"><i class="fas fa-arrow-right"></i></span>
        </a>
        <a href="categories.php" class="quick-card">
          <div class="quick-icon purple"><i class="fas fa-tags"></i></div>
          <div>
            <div class="quick-label">Kategoriler</div>
            <div class="quick-sub"><?php echo $categories_count; ?> kategori</div>
          </div>
          <span class="quick-arrow"><i class="fas fa-arrow-right"></i></span>
        </a>
        <a href="gallery.php" class="quick-card">
          <div class="quick-icon green"><i class="fas fa-images"></i></div>
          <div>
            <div class="quick-label">Galeri</div>
            <div class="quick-sub"><?php echo $gallery_count; ?> görsel</div>
          </div>
          <span class="quick-arrow"><i class="fas fa-arrow-right"></i></span>
        </a>
        <a href="sliders.php" class="quick-card">
          <div class="quick-icon rose"><i class="fas fa-layer-group"></i></div>
          <div>
            <div class="quick-label">Sliderlar</div>
            <div class="quick-sub"><?php echo $sliders_count; ?> slider</div>
          </div>
          <span class="quick-arrow"><i class="fas fa-arrow-right"></i></span>
        </a>
      </div>
    </div>
  </div>

</main>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.all.min.js"></script>
<script>
  function openSidebar() {
    document.getElementById('sidebar').classList.add('open');
    document.getElementById('overlay').classList.add('open');
    document.body.style.overflow = 'hidden';
  }
  function closeSidebar() {
    document.getElementById('sidebar').classList.remove('open');
    document.getElementById('overlay').classList.remove('open');
    document.body.style.overflow = '';
  }
  function logout() {
    Swal.fire({
      title: 'Çıkış yapılsın mı?',
      text: 'Oturumunuz kapatılacak.',
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#4f6ef7',
      cancelButtonColor: '#9aa3b2',
      confirmButtonText: 'Evet, çıkış yap',
      cancelButtonText: 'İptal'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = 'logout.php';
      }
    });
  }

  (function() {
    const el = document.getElementById('topbar-date');
    if (!el) return;
    const d = new Date();
    el.textContent = d.toLocaleDateString('tr-TR', { weekday: 'short', day: 'numeric', month: 'long', year: 'numeric' });
  })();

  document.querySelector('a[href="admin_index.php#settings"]')?.addEventListener('click', function(e) {
    const target = document.getElementById('settings');
    if (target) {
      e.preventDefault();
      closeSidebar();
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });

  const settingsForm = document.querySelector('form[action*="update_site_settings"]') || document.querySelector('form');
  if (settingsForm) {
    settingsForm.addEventListener('submit', function(e) {
      if (this.querySelector('input[name="action"][value="update_site_settings"]')) {
        e.preventDefault();
        Swal.fire({
          title: 'Ayarlar kaydedilsin mi?',
          text: 'Site ayarlarınız güncellenecektir.',
          icon: 'question',
          showCancelButton: true,
          confirmButtonColor: '#4f6ef7',
          cancelButtonColor: '#9aa3b2',
          confirmButtonText: 'Evet, kaydet!',
          cancelButtonText: 'İptal',
          reverseButtons: true,
          showLoaderOnConfirm: true,
          preConfirm: () => {
            this.submit();
          }
        });
      }
    });
  }

</script>
</body>
</html>