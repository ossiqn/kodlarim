<?php
require_once __DIR__ . '/config.php';

if (isLoggedIn()) {
    header('Location: admin_index.php');
    exit;
}

$error = '';
$debug = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    
    $debug .= "Username: " . $username . " | ";
    $debug .= "Password length: " . strlen($password) . " | ";
    
    if (empty($username) || empty($password)) {
        $error = 'Kullanıcı adı ve şifre gerekli!';
    } else {
        try {
            $stmt = $db->prepare("SELECT * FROM users WHERE username = ?");
            
            if (!$stmt) {
                $error = 'Veritabanı sorgusu hazırlanamadı!';
            } else {
                $stmt->execute([$username]);
                $user = $stmt->fetch(PDO::FETCH_ASSOC);
                
                $debug .= "User found: " . ($user ? 'YES' : 'NO') . " | ";
                
                if (!$user) {
                    $error = 'Kullanıcı bulunamadı!';
                } else {
                    $verify = password_verify($password, $user['password']);
                    $debug .= "Password verify: " . ($verify ? 'YES' : 'NO') . " | ";
                    
                    if ($verify) {
                        $_SESSION['admin_logged_in'] = true;
                        $_SESSION['admin_user'] = $user;
                        
                        $debug .= "Session set. Admin ID: " . $user['id'] . " | ";
                        
                        ob_end_clean();
                        header('Location: admin_index.php', true, 302);
                        exit;
                    } else {
                        $error = 'Hatalı şifre!';
                    }
                }
            }
        } catch(Exception $e) {
            $error = 'HATA: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Giriş</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-container {
            background: #fff;
            border-radius: 15px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            width: 100%;
            max-width: 400px;
            padding: 40px;
        }
        .login-header {
            text-align: center;
            margin-bottom: 30px;
        }
        .login-header h1 {
            font-size: 28px;
            color: #1a202c;
            margin-bottom: 5px;
            font-weight: 700;
        }
        .login-header p {
            color: #718096;
            font-size: 14px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            color: #2d3748;
            font-weight: 600;
            font-size: 14px;
        }
        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e2e8f0;
            border-radius: 8px;
            font-size: 14px;
            font-family: 'Inter', sans-serif;
            transition: all 0.3s;
        }
        input[type="text"]:focus,
        input[type="password"]:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        .btn-login {
            width: 100%;
            padding: 12px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #fff;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(102, 126, 234, 0.3);
        }
        .alert {
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 13px;
            border: 1px solid #fc8181;
            background: #fed7d7;
            color: #c53030;
        }
        .debug-box {
            display: none;
            padding: 10px;
            border-radius: 8px;
            margin-bottom: 15px;
            font-size: 11px;
            background: #f0f0f0;
            border: 1px solid #ccc;
            font-family: monospace;
            color: #333;
            max-height: 100px;
            overflow-y: auto;
        }
        .help-text {
            background: #f0f4ff;
            border: 1px solid #d6e2ff;
            border-radius: 8px;
            padding: 12px;
            font-size: 12px;
            color: #4a5568;
            margin-top: 15px;
        }
        code {
            background: #fff;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: monospace;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <h1><i class="fas fa-shield-alt" style="color: #667eea; margin-right: 10px;"></i>Admin Panel</h1>
            <p>Yönetim Paneline Hoşgeldiniz</p>
        </div>

        <?php if ($debug): ?>
            <div class="debug-box">
                DEBUG: <?php echo $debug; ?>
            </div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert">
                <i class="fas fa-exclamation-triangle"></i> <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label><i class="fas fa-user"></i> Kullanıcı Adı</label>
                <input type="text" name="username" placeholder="admin" required autofocus>
            </div>

            <div class="form-group">
                <label><i class="fas fa-lock"></i> Şifre</label>
                <input type="password" name="password" placeholder="admin123" required>
            </div>

            <button type="submit" class="btn-login">
                <i class="fas fa-sign-in-alt"></i> Giriş Yap
            </button>
        </form>

        <div class="help-text">
            <strong>Test Hesabı:</strong><br>
            Kullanıcı: <code>admin</code><br>
            Şifre: <code>admin123</code>
        </div>

        <div style="text-align: center; margin-top: 20px; padding-top: 20px; border-top: 1px solid #e2e8f0; font-size: 12px; color: #718096;">
            © <?php echo date('Y'); ?> Admin Panel
        </div>
    </div>
</body>
</html>