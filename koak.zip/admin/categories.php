<?php
require_once __DIR__ . '/config.php';
if (!isLoggedIn()) { header('Location: login.php'); exit; }

$success = '';
$error   = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    switch ($_POST['action']) {
        case 'add_category':
            $name = trim($_POST['name'] ?? '');
            if (empty($name)) {
                $error = 'Kategori adı boş olamaz.';
            } else {
                try {
                    $stmt = $db->prepare("INSERT INTO categories (name) VALUES (?)");
                    $stmt->execute([$name]);
                    $success = 'Kategori başarıyla eklendi!';
                } catch (Exception $e) {
                    $error = 'Hata: ' . $e->getMessage();
                }
            }
            break;
        case 'delete_category':
            $id = intval($_POST['id'] ?? 0);
            try {
                $db->prepare("DELETE FROM categories WHERE id = ?")->execute([$id]);
                $success = 'Kategori silindi.';
            } catch (Exception $e) {
                $error = 'Silme işlemi başarısız.';
            }
            break;
        case 'edit_category':
            $id = intval($_POST['id'] ?? 0);
            $name = trim($_POST['name'] ?? '');
            if (empty($name)) {
                $error = 'Kategori adı boş olamaz.';
            } else {
                try {
                    $stmt = $db->prepare("UPDATE categories SET name = ? WHERE id = ?");
                    $stmt->execute([$name, $id]);
                    $success = 'Kategori güncellendi!';
                } catch (Exception $e) {
                    $error = 'Güncelleme başarısız.';
                }
            }
            break;
    }
}

try {
    $categories = $db->query("SELECT * FROM categories ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) { $categories = []; }

$admin_name     = e($_SESSION['admin_user']['fullname'] ?? $_SESSION['admin_user']['username'] ?? 'Admin');
$admin_initials = strtoupper(substr($admin_name, 0, 2));
?>
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Kategori Yönetimi — Admin Panel</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
  <style>
    :root{--sidebar-w:248px;--topbar-h:60px;--bg:#f4f6f9;--surface:#ffffff;--border:#e8eaf0;--text:#1a1d2e;--text-2:#5a6272;--text-3:#9aa3b2;--accent:#4f6ef7;--accent-2:#6c47ff;--accent-bg:#eef1fe;--green:#22c55e;--green-bg:#dcfce7;--rose:#f43f5e;--rose-bg:#ffe4e6;--radius:12px;--radius-sm:8px;--shadow:0 1px 3px rgba(0,0,0,0.07),0 4px 12px rgba(0,0,0,0.04);--shadow-md:0 4px 16px rgba(0,0,0,0.10);}
    *,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
    html{font-size:15px;}
    body{font-family:'Plus Jakarta Sans',sans-serif;background:var(--bg);color:var(--text);min-height:100vh;display:flex;}
    .sidebar{width:var(--sidebar-w);background:var(--surface);border-right:1px solid var(--border);display:flex;flex-direction:column;position:fixed;top:0;left:0;bottom:0;z-index:100;transition:transform .28s cubic-bezier(.4,0,.2,1);}
    .sidebar-logo{height:var(--topbar-h);display:flex;align-items:center;padding:0 20px;border-bottom:1px solid var(--border);gap:10px;text-decoration:none;}
    .sidebar-logo-icon{width:32px;height:32px;background:linear-gradient(135deg,var(--accent),var(--accent-2));border-radius:9px;display:flex;align-items:center;justify-content:center;color:#fff;font-size:14px;flex-shrink:0;}
    .sidebar-logo-text{font-size:15px;font-weight:700;color:var(--text);}
    .sidebar-nav{flex:1;padding:16px 12px;overflow-y:auto;}
    .nav-label{font-size:10.5px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--text-3);padding:0 8px;margin:18px 0 6px;}
    .nav-label:first-child{margin-top:0;}
    .nav-item{display:flex;align-items:center;gap:10px;padding:9px 10px;border-radius:var(--radius-sm);text-decoration:none;color:var(--text-2);font-size:13.5px;font-weight:500;transition:background .15s,color .15s;margin-bottom:2px;}
    .nav-item i{width:18px;text-align:center;font-size:13px;flex-shrink:0;}
    .nav-item:hover{background:var(--bg);color:var(--text);}
    .nav-item.active{background:var(--accent-bg);color:var(--accent);font-weight:600;}
    .nav-item.active i{color:var(--accent);}
    .sidebar-footer{padding:14px 12px;border-top:1px solid var(--border);}
    .sidebar-user{display:flex;align-items:center;gap:10px;padding:9px 10px;border-radius:var(--radius-sm);cursor:pointer;transition:background .15s;}
    .sidebar-user:hover{background:var(--bg);}
    .user-avatar{width:32px;height:32px;border-radius:50%;background:linear-gradient(135deg,var(--accent),var(--accent-2));color:#fff;font-size:12px;font-weight:700;display:flex;align-items:center;justify-content:center;flex-shrink:0;}
    .user-info{flex:1;min-width:0;}
    .user-name{font-size:13px;font-weight:600;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
    .user-role{font-size:11px;color:var(--text-3);}
    .logout-icon{color:var(--text-3);font-size:13px;flex-shrink:0;}
    .sidebar-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.4);z-index:99;}
    .topbar{position:fixed;top:0;left:var(--sidebar-w);right:0;height:var(--topbar-h);background:var(--surface);border-bottom:1px solid var(--border);display:flex;align-items:center;padding:0 24px;gap:16px;z-index:90;}
    .topbar-hamburger{display:none;background:none;border:none;cursor:pointer;padding:6px;color:var(--text-2);font-size:18px;}
    .topbar-title{font-size:16px;font-weight:700;color:var(--text);}
    .topbar-right{margin-left:auto;display:flex;align-items:center;gap:10px;}
    .topbar-date{font-size:12.5px;color:var(--text-3);}
    .main{margin-left:var(--sidebar-w);margin-top:var(--topbar-h);padding:28px 28px 60px;flex:1;min-width:0;}
    .page-header{display:flex;align-items:flex-end;justify-content:space-between;margin-bottom:24px;flex-wrap:wrap;gap:12px;}
    .page-header h1{font-size:22px;font-weight:700;}
    .page-header p{font-size:13px;color:var(--text-3);margin-top:2px;}
    .card{background:var(--surface);border-radius:var(--radius);box-shadow:var(--shadow);border:1px solid var(--border);margin-bottom:20px;}
    .card-header{padding:18px 24px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:10px;}
    .card-header-icon{width:34px;height:34px;border-radius:9px;background:var(--accent-bg);color:var(--accent);display:flex;align-items:center;justify-content:center;font-size:14px;flex-shrink:0;}
    .card-header h2{font-size:15px;font-weight:700;}
    .card-header p{font-size:12.5px;color:var(--text-3);margin-top:1px;}
    .card-body{padding:24px;}
    .form-group{margin-bottom:16px;}
    .form-group:last-child{margin-bottom:0;}
    label{display:block;margin-bottom:6px;font-size:13px;font-weight:600;color:var(--text-2);}
    input[type="text"]{width:100%;padding:9px 13px;border:1.5px solid var(--border);border-radius:var(--radius-sm);font-size:14px;font-family:'Plus Jakarta Sans',sans-serif;color:var(--text);background:#fff;transition:border-color .18s,box-shadow .18s;outline:none;}
    input[type="text"]:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(79,110,247,.12);}
    .btn{display:inline-flex;align-items:center;gap:8px;padding:10px 20px;border-radius:var(--radius-sm);font-size:13.5px;font-weight:600;font-family:'Plus Jakarta Sans',sans-serif;cursor:pointer;border:none;transition:all .18s;text-decoration:none;white-space:nowrap;}
    .btn-primary{background:linear-gradient(135deg,var(--accent),var(--accent-2));color:#fff;box-shadow:0 2px 8px rgba(79,110,247,.28);}
    .btn-primary:hover{transform:translateY(-1px);box-shadow:0 6px 16px rgba(79,110,247,.38);}
    .btn-danger{background:var(--rose-bg);color:var(--rose);}
    .btn-danger:hover{background:var(--rose);color:#fff;}
    .btn-sm{padding:7px 13px;font-size:12.5px;}
    .btn-icon{width:36px;height:36px;padding:0;display:flex;align-items:center;justify-content:center;}
    hr.divider{border:none;border-top:1px solid var(--border);margin:20px 0;}
    table{width:100%;border-collapse:collapse;}
    th{text-align:left;padding:12px 0;font-size:12.5px;font-weight:700;color:var(--text-3);text-transform:uppercase;border-bottom:1px solid var(--border);}
    td{padding:14px 0;border-bottom:1px solid var(--border);font-size:14px;}
    tr:last-child td{border-bottom:none;}
    .empty-state{text-align:center;padding:48px 20px;}
    .empty-state i{font-size:36px;color:var(--text-3);margin-bottom:12px;display:block;}
    .empty-state p{color:var(--text-3);font-size:14px;}
    @media(max-width:768px){
      .sidebar{transform:translateX(-100%);}
      .sidebar.open{transform:translateX(0);box-shadow:var(--shadow-md);}
      .sidebar-overlay.open{display:block;}
      .topbar{left:0;}
      .topbar-hamburger{display:flex;}
      .main{margin-left:0;padding:20px 16px 60px;}
      .card-body{padding:16px;}
    }
  </style>
</head>
<body>

<div class="sidebar-overlay" id="overlay" onclick="closeSidebar()"></div>

<aside class="sidebar" id="sidebar">
  <a href="admin_index.php" class="sidebar-logo">
    <div class="sidebar-logo-icon"><i class="fas fa-shield-halved"></i></div>
    <span class="sidebar-logo-text">KOAK Admin</span>
  </a>
  <nav class="sidebar-nav">
    <div class="nav-label">Genel</div>
    <a href="admin_index.php" class="nav-item"><i class="fas fa-gauge-high"></i> Dashboard</a>
    <div class="nav-label">İçerik</div>
    <a href="pages.php" class="nav-item"><i class="fas fa-file-lines"></i> Sayfalar</a>
    <a href="news.php" class="nav-item"><i class="fas fa-bullhorn"></i> Duyurular</a>
    <a href="categories.php" class="nav-item active"><i class="fas fa-tags"></i> Kategoriler</a>
    <a href="gallery.php" class="nav-item"><i class="fas fa-images"></i> Galeri</a>
    <a href="sliders.php" class="nav-item"><i class="fas fa-layer-group"></i> Sliderlar</a>
    <div class="nav-label">Ayarlar</div>
    <a href="admin_index.php#settings" class="nav-item"><i class="fas fa-gear"></i> Site Ayarları</a>
  </nav>
  <div class="sidebar-footer">
    <div class="sidebar-user" onclick="logout()">
      <div class="user-avatar"><?php echo $admin_initials; ?></div>
      <div class="user-info">
        <div class="user-name"><?php echo $admin_name; ?></div>
        <div class="user-role">Yönetici</div>
      </div>
      <i class="fas fa-arrow-right-from-bracket logout-icon"></i>
    </div>
  </div>
</aside>

<header class="topbar">
  <button class="topbar-hamburger" onclick="openSidebar()"><i class="fas fa-bars"></i></button>
  <div class="topbar-title">Kategori Yönetimi</div>
  <div class="topbar-right">
    <span class="topbar-date" id="topbar-date"></span>
  </div>
</header>

<main class="main">

  <div class="page-header">
    <div>
      <h1>Kategori Yönetimi</h1>
      <p><?php echo count($categories); ?> kategori</p>
    </div>
  </div>

  <div class="card">
    <div class="card-header">
      <div class="card-header-icon"><i class="fas fa-plus"></i></div>
      <div>
        <h2>Yeni Kategori Ekle</h2>
        <p>Duyurular için yeni bir kategori oluştur</p>
      </div>
    </div>
    <div class="card-body">
      <form id="addCategoryForm">
        <div class="form-group">
          <label><i class="fas fa-tag"></i> Kategori Adı</label>
          <input type="text" name="name" id="categoryName" placeholder="Kategori adını girin..." required>
        </div>
        <hr class="divider">
        <button type="submit" class="btn btn-primary"><i class="fas fa-plus"></i> Ekle</button>
      </form>
    </div>
  </div>

  <div class="card">
    <div class="card-header">
      <div class="card-header-icon"><i class="fas fa-list"></i></div>
      <div>
        <h2>Mevcut Kategoriler</h2>
        <p><?php echo count($categories); ?> adet</p>
      </div>
    </div>
    <div class="card-body">
      <?php if (empty($categories)): ?>
      <div class="empty-state">
        <i class="fas fa-tags"></i>
        <p>Henüz kategori eklenmedi. Yukarıdan yeni kategori ekleyebilirsiniz.</p>
      </div>
      <?php else: ?>
      <table>
        <thead>
          <tr>
            <th>Kategori Adı</th>
            <th style="width:150px;text-align:right;">İşlemler</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($categories as $cat): ?>
          <tr>
            <td><?php echo e($cat['name']); ?></td>
            <td style="text-align:right;display:flex;gap:6px;justify-content:flex-end;">
              <button type="button" class="btn btn-icon btn-primary edit-btn" data-id="<?php echo $cat['id']; ?>" data-name="<?php echo e($cat['name']); ?>" title="Düzenle">
                <i class="fas fa-edit"></i>
              </button>
              <button type="button" class="btn btn-icon btn-danger delete-btn" data-id="<?php echo $cat['id']; ?>" data-name="<?php echo e($cat['name']); ?>" title="Sil">
                <i class="fas fa-trash"></i>
              </button>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      <?php endif; ?>
    </div>
  </div>

</main>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.all.min.js"></script>
<script>
function showNotification(type, message) {
  const Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: true,
    didOpen: (toast) => {
      toast.addEventListener('mouseenter', Swal.stopTimer);
      toast.addEventListener('mouseleave', Swal.resumeTimer);
    }
  });

  Toast.fire({
    icon: type,
    title: message
  });
}

<?php if ($success): ?>
document.addEventListener('DOMContentLoaded', function() {
  showNotification('success', '<?php echo addslashes($success); ?>');
});
<?php elseif ($error): ?>
document.addEventListener('DOMContentLoaded', function() {
  showNotification('error', '<?php echo addslashes($error); ?>');
});
<?php endif; ?>

function openSidebar(){document.getElementById('sidebar').classList.add('open');document.getElementById('overlay').classList.add('open');document.body.style.overflow='hidden';}
function closeSidebar(){document.getElementById('sidebar').classList.remove('open');document.getElementById('overlay').classList.remove('open');document.body.style.overflow='';}
function logout(){Swal.fire({title:'Çıkış yapılsın mı?',text:'Oturumunuz kapatılacak.',icon:'question',showCancelButton:true,confirmButtonColor:'#4f6ef7',cancelButtonColor:'#9aa3b2',confirmButtonText:'Evet, çıkış yap',cancelButtonText:'İptal'}).then(function(result){if(result.isConfirmed){window.location.href='logout.php';}});}

document.addEventListener('DOMContentLoaded', function() {
  const deleteButtons = document.querySelectorAll('.delete-btn');
  deleteButtons.forEach(btn => {
    btn.addEventListener('click', function(e) {
      e.preventDefault();
      const id = this.getAttribute('data-id');
      const name = this.getAttribute('data-name');
      Swal.fire({
        title: 'Kategori silinsin mi?',
        html: `<b>${name}</b> kategorisi silinecek.`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#f43f5e',
        cancelButtonColor: '#9aa3b2',
        confirmButtonText: 'Evet, sil!',
        cancelButtonText: 'İptal',
        reverseButtons: true
      }).then((result) => {
        if (result.isConfirmed) {
          const form = document.createElement('form');
          form.method = 'POST';
          form.style.display = 'none';
          
          const actionInput = document.createElement('input');
          actionInput.name = 'action';
          actionInput.value = 'delete_category';
          
          const idInput = document.createElement('input');
          idInput.name = 'id';
          idInput.value = id;
          
          form.appendChild(actionInput);
          form.appendChild(idInput);
          document.body.appendChild(form);
          form.submit();
        }
      });
    });
  });

  const editButtons = document.querySelectorAll('.edit-btn');
  editButtons.forEach(btn => {
    btn.addEventListener('click', function(e) {
      e.preventDefault();
      const id = this.getAttribute('data-id');
      const name = this.getAttribute('data-name');
      
      Swal.fire({
        title: 'Kategori Düzenle',
        html: `<input type="text" id="editCategoryName" class="swal2-input" placeholder="Kategori adı" value="${name}">`,
        showCancelButton: true,
        confirmButtonColor: '#4f6ef7',
        cancelButtonColor: '#9aa3b2',
        confirmButtonText: 'Kaydet',
        cancelButtonText: 'İptal',
        preConfirm: () => {
          const newName = document.getElementById('editCategoryName').value;
          if (!newName) {
            Swal.showValidationMessage('Kategori adı boş olamaz');
            return false;
          }
          
          const form = document.createElement('form');
          form.method = 'POST';
          form.style.display = 'none';
          
          const actionInput = document.createElement('input');
          actionInput.name = 'action';
          actionInput.value = 'edit_category';
          
          const idInput = document.createElement('input');
          idInput.name = 'id';
          idInput.value = id;
          
          const nameInput = document.createElement('input');
          nameInput.name = 'name';
          nameInput.value = newName;
          
          form.appendChild(actionInput);
          form.appendChild(idInput);
          form.appendChild(nameInput);
          document.body.appendChild(form);
          form.submit();
        }
      });
    });
  });

  const addForm = document.getElementById('addCategoryForm');
  if (addForm) {
    addForm.addEventListener('submit', function(e) {
      e.preventDefault();
      const name = document.getElementById('categoryName').value;
      
      if (!name) {
        Swal.fire({
          icon: 'error',
          title: 'Hata',
          text: 'Lütfen kategori adını girin!'
        });
        return;
      }
      
      Swal.fire({
        title: 'Kategori eklensin mi?',
        html: `<b>${name}</b> kategorisi eklenecek.`,
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#4f6ef7',
        cancelButtonColor: '#9aa3b2',
        confirmButtonText: 'Evet, ekle!',
        cancelButtonText: 'İptal',
        reverseButtons: true,
        showLoaderOnConfirm: true,
        preConfirm: () => {
          const form = document.createElement('form');
          form.method = 'POST';
          form.style.display = 'none';
          
          const actionInput = document.createElement('input');
          actionInput.name = 'action';
          actionInput.value = 'add_category';
          
          const nameInput = document.createElement('input');
          nameInput.name = 'name';
          nameInput.value = name;
          
          form.appendChild(actionInput);
          form.appendChild(nameInput);
          document.body.appendChild(form);
          form.submit();
        }
      });
    });
  }
});

(function(){const el=document.getElementById('topbar-date');if(el)el.textContent=new Date().toLocaleDateString('tr-TR',{weekday:'short',day:'numeric',month:'long',year:'numeric'});})();
</script>
</body>
</html>