<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// İŞTE BÜTÜN SORUNU ÇÖZEN NÜKLEER KOD: Tarayıcının eski bozuk çerezini eziyoruz!
session_name('KOAK_PANEL');
session_start();

if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

date_default_timezone_set('Europe/Istanbul');

if (!is_dir(__DIR__ . '/uploads')) {
    @mkdir(__DIR__ . '/uploads', 0755, true);
}

try {
    $host = 'localhost';
    $dbname = 'arama';
    $user = 'root';
    $pass = ''; 
    
    $db = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $pass);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (Exception $ex) {
    die("Veritabanı Hatası: " . $ex->getMessage());
}

function createSlug($text) {
    $turkce = ['ç','ğ','ı','ö','ş','ü','Ç','Ğ','İ','Ö','Ş','Ü',' '];
    $duz = ['c','g','i','o','s','u','c','g','i','o','s','u','-'];
    $text = str_replace($turkce, $duz, $text);
    return trim(preg_replace('/-+/', '-', preg_replace('/[^a-z0-9\-]/', '', strtolower($text))), '-');
}

function timeAgo($date) {
    if (empty($date)) return 'Az önce';
    $diff = time() - strtotime($date);
    if ($diff < 60) return 'Az önce';
    if ($diff < 3600) return floor($diff / 60) . ' dk önce';
    if ($diff < 86400) return floor($diff / 3600) . ' saat önce';
    return date('d.m.Y', strtotime($date));
}

function isLoggedIn() { 
    return isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true; 
}

function e($str) { 
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8'); 
}

function verifyCsrfToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

function getCategories() { 
    global $db; 
    return $db->query("SELECT * FROM categories WHERE is_active = 1 ORDER BY sort_order")->fetchAll(); 
}

function getNewsById($id) { 
    global $db; 
    $st = $db->prepare("
        SELECT n.*, c.name as cat_name, c.slug as cat_slug, c.color as cat_color, c.icon as cat_icon 
        FROM news n 
        LEFT JOIN categories c ON n.category_id = c.id 
        WHERE n.id = ?
    "); 
    $st->execute([$id]); 
    return $st->fetch(); 
}

function getNews($options = []) {
    global $db; 
    $where = ["n.status = 'published'"]; 
    $params = [];
    $limit = $options['limit'] ?? 10; 
    $offset = $options['offset'] ?? 0; 
    
    $allowed_orders = [
        'n.published_at DESC', 'n.published_at ASC',
        'n.views DESC', 'n.views ASC',
        'n.id DESC', 'n.id ASC'
    ];
    $order = $options['orderBy'] ?? 'n.published_at DESC';
    if (!in_array($order, $allowed_orders)) {
        $order = 'n.published_at DESC';
    }
    
    if (!empty($options['category_id'])) {
        $where[] = 'n.category_id=?';
        $params[] = intval($options['category_id']);
    }
    if (!empty($options['is_featured'])) {
        $where[] = 'n.is_featured=1';
    }
    if (!empty($options['is_breaking'])) {
        $where[] = 'n.is_breaking=1';
    }
    if (!empty($options['is_headline'])) {
        $where[] = 'n.is_headline=1';
    }
    if (!empty($options['search'])) {
        $where[] = '(n.title LIKE ? OR n.summary LIKE ?)';
        $params[] = '%' . $options['search'] . '%';
        $params[] = '%' . $options['search'] . '%';
    }
    if (!empty($options['exclude_id'])) {
        $where[] = 'n.id!=?';
        $params[] = intval($options['exclude_id']);
    }
    
    $sql = "SELECT n.*, c.name as cat_name, c.slug as cat_slug, c.color as cat_color, c.icon as cat_icon 
            FROM news n 
            LEFT JOIN categories c ON n.category_id = c.id 
            WHERE " . implode(' AND ', $where) . " 
            ORDER BY $order 
            LIMIT $limit OFFSET $offset";
    
    $st = $db->prepare($sql); 
    $st->execute($params); 
    return $st->fetchAll();
}

function countNews($options = []) {
    global $db;
    $where = ["status='published'"];
    $params = [];
    
    if (!empty($options['category_id'])) {
        $where[] = 'category_id=?';
        $params[] = intval($options['category_id']);
    }
    if (!empty($options['search'])) {
        $where[] = '(title LIKE ? OR summary LIKE ?)';
        $params[] = '%' . $options['search'] . '%';
        $params[] = '%' . $options['search'] . '%';
    }
    
    $st = $db->prepare("SELECT COUNT(*) as c FROM news WHERE " . implode(' AND ', $where));
    $st->execute($params);
    return $st->fetch()['c'];
}

function newsImage($news, $class = '') {
    $imgPath = '';
    
    if (!empty($news['image'])) {
        if (file_exists(__DIR__ . '/' . $news['image'])) {
            $imgPath = 'admin/' . $news['image'];
        } elseif (file_exists(__DIR__ . '/../' . $news['image'])) {
            $imgPath = $news['image'];
        }
    }

    if ($imgPath !== '') {
        return '<img src="' . htmlspecialchars($imgPath, ENT_QUOTES, 'UTF-8') . '" alt="' . htmlspecialchars($news['title'] ?? '', ENT_QUOTES, 'UTF-8') . '" class="' . $class . '" loading="lazy">';
    }

    $gradients = [
        'linear-gradient(135deg, #0f2027 0%, #203a43 50%, #2c5364 100%)',
        'linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)',
        'linear-gradient(135deg, #2d1b69 0%, #6b21a8 50%, #a855f7 100%)',
        'linear-gradient(135deg, #134e5e 0%, #71b280 100%)',
        'linear-gradient(135deg, #c21e1e 0%, #9b1818 100%)'
    ];

    $id = isset($news['id']) ? $news['id'] : 0;
    $gradient = $gradients[$id % count($gradients)];
    $icon = isset($news['cat_icon']) ? $news['cat_icon'] : 'fa-newspaper';

    return '<div class="placeholder-img ' . $class . '" style="background:' . $gradient . '; display:flex; align-items:center; justify-content:center; color:#fff; font-size:40px;">
                <i class="fas ' . e($icon) . '"></i>
            </div>';
}

function formatViews($num) {
    $num = intval($num);
    if ($num >= 1000000) return number_format($num / 1000000, 1) . 'M';
    if ($num >= 1000) return number_format($num / 1000, 1) . 'B';
    return $num;
}

function validateImagePath($filename) {
    if (empty($filename)) return false;
    if (strpos($filename, '/') !== false || strpos($filename, '\\') !== false) return false;
    $full_path = __DIR__ . '/uploads/' . $filename;
    $real_path = realpath($full_path);
    $upload_dir = realpath(__DIR__ . '/uploads');
    if ($real_path === false || strpos($real_path, $upload_dir) !== 0) return false;
    return $real_path;
}

function validateImageUpload($file_array) {
    if (empty($file_array['name']) || $file_array['error'] !== 0) {
        return ['success' => false, 'message' => 'Dosya seçilmemiş veya hata oluştu'];
    }
    $ext = strtolower(pathinfo($file_array['name'], PATHINFO_EXTENSION));
    $allowed_ext = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    
    if (!in_array($ext, $allowed_ext)) {
        return ['success' => false, 'message' => 'Sadece JPG, PNG, GIF ve WEBP desteklenir'];
    }
    if ($file_array['size'] > 5 * 1024 * 1024) {
        return ['success' => false, 'message' => 'Dosya çok büyük! (Max 5MB)'];
    }
    
    $original_name = pathinfo($file_array['name'], PATHINFO_FILENAME);
    $safe_name = preg_replace('/[^a-z0-9_-]/i', '', $original_name);
    if (empty($safe_name)) $safe_name = 'image';
    
    $filename = 'img_' . time() . '_' . mt_rand(1000, 9999) . '_' . substr($safe_name, 0, 20) . '.' . $ext;
    $upload_path = __DIR__ . '/uploads/' . $filename;

    if (!move_uploaded_file($file_array['tmp_name'], $upload_path)) {
        return ['success' => false, 'message' => 'Dosya yüklenemedi. Klasör izinlerini kontrol edin.'];
    }
    return ['success' => true, 'filename' => 'uploads/' . $filename];
}

function validateFontAwesomeIcon($icon) {
    if (!preg_match('/^fa[a-z0-9\-]*$/i', trim($icon))) return 'fa-folder';
    return trim($icon);
}

function validateHexColor($color) {
    if (!preg_match('/^#([0-9a-f]{3}|[0-9a-f]{6})$/i', trim($color))) return '#c21e1e';
    return strtolower(trim($color));
}
?>