<?php
require_once __DIR__ . '/config.php';
if (!isLoggedIn()) { header('Location: login.php'); exit; }

$success = '';
$error   = '';

$upload_dir = __DIR__ . '/uploads/gallery/';
if (!file_exists($upload_dir)) mkdir($upload_dir, 0777, true);

try {
    $gallery = $db->query("SELECT * FROM gallery ORDER BY sort_order ASC")->fetchAll(PDO::FETCH_ASSOC);
} catch(Exception $e) { $gallery = []; }

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    switch ($_POST['action']) {
        case 'add_image':
            if (!empty($_FILES['image']['name'])) {
                $file_name = 'gallery_' . time() . '_' . basename($_FILES['image']['name']);
                if (move_uploaded_file($_FILES['image']['tmp_name'], $upload_dir . $file_name)) {
                    $stmt = $db->prepare("INSERT INTO gallery (title, description, image_path, sort_order) VALUES (?, ?, ?, ?)");
                    $max  = $db->query("SELECT MAX(sort_order) as m FROM gallery")->fetch()['m'] ?? 0;
                    $stmt->execute([$_POST['title'], $_POST['description'], 'uploads/gallery/' . $file_name, $max + 1])
                        ? $success = 'Görsel başarıyla eklendi!' : $error = 'Veritabanı hatası.';
                } else { $error = 'Dosya yüklenemedi.'; }
            }
            break;
        case 'delete_image':
            $id = intval($_POST['id'] ?? 0);
            try {
                $item = $db->query("SELECT image_path FROM gallery WHERE id = $id")->fetch();
                if ($item && file_exists(__DIR__ . '/../' . $item['image_path'])) unlink(__DIR__ . '/../' . $item['image_path']);
                $db->exec("DELETE FROM gallery WHERE id = $id");
                $success = 'Görsel silindi.';
            } catch(Exception $e) { $error = 'Silme işlemi başarısız.'; }
            break;
    }
}

try {
    $gallery = $db->query("SELECT * FROM gallery ORDER BY sort_order ASC")->fetchAll(PDO::FETCH_ASSOC);
} catch(Exception $e) { $gallery = []; }

$admin_name     = e($_SESSION['admin_user']['fullname'] ?? $_SESSION['admin_user']['username'] ?? 'Admin');
$admin_initials = strtoupper(substr($admin_name, 0, 2));
?>
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Galeri Yönetimi — Admin Panel</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
  <style>
    :root{--sidebar-w:248px;--topbar-h:60px;--bg:#f4f6f9;--surface:#ffffff;--border:#e8eaf0;--text:#1a1d2e;--text-2:#5a6272;--text-3:#9aa3b2;--accent:#4f6ef7;--accent-2:#6c47ff;--accent-bg:#eef1fe;--green:#22c55e;--green-bg:#dcfce7;--rose:#f43f5e;--rose-bg:#ffe4e6;--radius:12px;--radius-sm:8px;--shadow:0 1px 3px rgba(0,0,0,0.07),0 4px 12px rgba(0,0,0,0.04);--shadow-md:0 4px 16px rgba(0,0,0,0.10);}
    *,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
    html{font-size:15px;}
    body{font-family:'Plus Jakarta Sans',sans-serif;background:var(--bg);color:var(--text);min-height:100vh;display:flex;}
    .sidebar{width:var(--sidebar-w);background:var(--surface);border-right:1px solid var(--border);display:flex;flex-direction:column;position:fixed;top:0;left:0;bottom:0;z-index:100;transition:transform .28s cubic-bezier(.4,0,.2,1);}
    .sidebar-logo{height:var(--topbar-h);display:flex;align-items:center;padding:0 20px;border-bottom:1px solid var(--border);gap:10px;text-decoration:none;}
    .sidebar-logo-icon{width:32px;height:32px;background:linear-gradient(135deg,var(--accent),var(--accent-2));border-radius:9px;display:flex;align-items:center;justify-content:center;color:#fff;font-size:14px;flex-shrink:0;}
    .sidebar-logo-text{font-size:15px;font-weight:700;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
    .sidebar-nav{flex:1;padding:16px 12px;overflow-y:auto;}
    .nav-label{font-size:10.5px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--text-3);padding:0 8px;margin:18px 0 6px;}
    .nav-label:first-child{margin-top:0;}
    .nav-item{display:flex;align-items:center;gap:10px;padding:9px 10px;border-radius:var(--radius-sm);text-decoration:none;color:var(--text-2);font-size:13.5px;font-weight:500;transition:background .15s,color .15s;margin-bottom:2px;}
    .nav-item i{width:18px;text-align:center;font-size:13px;flex-shrink:0;}
    .nav-item:hover{background:var(--bg);color:var(--text);}
    .nav-item.active{background:var(--accent-bg);color:var(--accent);font-weight:600;}
    .nav-item.active i{color:var(--accent);}
    .sidebar-footer{padding:14px 12px;border-top:1px solid var(--border);}
    .sidebar-user{display:flex;align-items:center;gap:10px;padding:9px 10px;border-radius:var(--radius-sm);cursor:pointer;transition:background .15s;}
    .sidebar-user:hover{background:var(--bg);}
    .user-avatar{width:32px;height:32px;border-radius:50%;background:linear-gradient(135deg,var(--accent),var(--accent-2));color:#fff;font-size:12px;font-weight:700;display:flex;align-items:center;justify-content:center;flex-shrink:0;}
    .user-info{flex:1;min-width:0;}
    .user-name{font-size:13px;font-weight:600;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
    .user-role{font-size:11px;color:var(--text-3);}
    .logout-icon{color:var(--text-3);font-size:13px;flex-shrink:0;}
    .sidebar-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,0.4);z-index:99;}
    .topbar{position:fixed;top:0;left:var(--sidebar-w);right:0;height:var(--topbar-h);background:var(--surface);border-bottom:1px solid var(--border);display:flex;align-items:center;padding:0 24px;gap:16px;z-index:90;}
    .topbar-hamburger{display:none;background:none;border:none;cursor:pointer;padding:6px;color:var(--text-2);font-size:18px;}
    .topbar-title{font-size:16px;font-weight:700;color:var(--text);}
    .topbar-right{margin-left:auto;display:flex;align-items:center;gap:10px;}
    .topbar-date{font-size:12.5px;color:var(--text-3);}
    .main{margin-left:var(--sidebar-w);margin-top:var(--topbar-h);padding:28px 28px 60px;flex:1;min-width:0;}
    .page-header{display:flex;align-items:flex-end;justify-content:space-between;margin-bottom:24px;flex-wrap:wrap;gap:12px;}
    .page-header h1{font-size:22px;font-weight:700;color:var(--text);}
    .page-header p{font-size:13px;color:var(--text-3);margin-top:2px;}
    .alert{display:flex;align-items:flex-start;gap:12px;padding:14px 18px;border-radius:var(--radius);margin-bottom:24px;font-size:14px;}
    .alert i{margin-top:1px;flex-shrink:0;}
    .alert-success{background:var(--green-bg);color:#15803d;border:1px solid #bbf7d0;}
    .alert-error{background:var(--rose-bg);color:#9f1239;border:1px solid #fecdd3;}
    .card{background:var(--surface);border-radius:var(--radius);box-shadow:var(--shadow);border:1px solid var(--border);margin-bottom:20px;}
    .card-header{padding:18px 24px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:10px;}
    .card-header-icon{width:34px;height:34px;border-radius:9px;background:var(--accent-bg);color:var(--accent);display:flex;align-items:center;justify-content:center;font-size:14px;flex-shrink:0;}
    .card-header h2{font-size:15px;font-weight:700;color:var(--text);}
    .card-header p{font-size:12.5px;color:var(--text-3);margin-top:1px;}
    .card-body{padding:24px;}
    .form-row{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px;}
    .form-group{margin-bottom:16px;}
    .form-group:last-child{margin-bottom:0;}
    label{display:block;margin-bottom:6px;font-size:13px;font-weight:600;color:var(--text-2);}
    label i{margin-right:5px;color:var(--text-3);font-size:12px;}
    input[type="text"],textarea{width:100%;padding:9px 13px;border:1.5px solid var(--border);border-radius:var(--radius-sm);font-size:14px;font-family:'Plus Jakarta Sans',sans-serif;color:var(--text);background:#fff;transition:border-color .18s,box-shadow .18s;outline:none;}
    input[type="text"]:focus,textarea:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(79,110,247,.12);}
    textarea{resize:vertical;min-height:80px;}
    input[type="file"]{width:100%;font-size:13px;color:var(--text-2);padding:8px 12px;border:1.5px dashed var(--border);border-radius:var(--radius-sm);background:var(--bg);cursor:pointer;transition:border-color .18s;}
    input[type="file"]:hover{border-color:var(--accent);}
    .btn{display:inline-flex;align-items:center;gap:8px;padding:10px 20px;border-radius:var(--radius-sm);font-size:13.5px;font-weight:600;font-family:'Plus Jakarta Sans',sans-serif;cursor:pointer;border:none;transition:all .18s;text-decoration:none;white-space:nowrap;}
    .btn-primary{background:linear-gradient(135deg,var(--accent),var(--accent-2));color:#fff;box-shadow:0 2px 8px rgba(79,110,247,.28);}
    .btn-primary:hover{transform:translateY(-1px);box-shadow:0 6px 16px rgba(79,110,247,.38);}
    .btn-danger{background:var(--rose-bg);color:var(--rose);}
    .btn-danger:hover{background:var(--rose);color:#fff;}
    .btn-sm{padding:7px 13px;font-size:12.5px;}
    hr.divider{border:none;border-top:1px solid var(--border);margin:20px 0;}

    .gallery-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:16px;margin-top:4px;}
    .gallery-item{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);overflow:hidden;transition:transform .18s,box-shadow .18s;}
    .gallery-item:hover{transform:translateY(-3px);box-shadow:var(--shadow-md);}
    .gallery-thumb{width:100%;height:150px;object-fit:cover;background:var(--bg);display:block;}
    .gallery-thumb-placeholder{width:100%;height:150px;background:var(--bg);display:flex;align-items:center;justify-content:center;color:var(--text-3);font-size:28px;}
    .gallery-info{padding:12px 14px;}
    .gallery-name{font-size:13.5px;font-weight:600;color:var(--text);margin-bottom:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
    .gallery-desc{font-size:12px;color:var(--text-3);margin-bottom:10px;line-height:1.4;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;}
    .gallery-actions{display:flex;gap:8px;}

    .empty-state{text-align:center;padding:48px 20px;}
    .empty-state i{font-size:36px;color:var(--text-3);margin-bottom:12px;display:block;}
    .empty-state p{color:var(--text-3);font-size:14px;}

    @media(max-width:768px){
      .sidebar{transform:translateX(-100%);}
      .sidebar.open{transform:translateX(0);box-shadow:var(--shadow-md);}
      .sidebar-overlay.open{display:block;}
      .topbar{left:0;}
      .topbar-hamburger{display:flex;}
      .main{margin-left:0;padding:20px 16px 60px;}
      .card-body{padding:16px;}
      .card-header{padding:14px 16px;}
      .gallery-grid{grid-template-columns:repeat(2,1fr);}
    }
    @media(max-width:480px){
      .gallery-grid{grid-template-columns:repeat(2,1fr);}
    }
  </style>
</head>
<body>

<div class="sidebar-overlay" id="overlay" onclick="closeSidebar()"></div>

<aside class="sidebar" id="sidebar">
  <a href="admin_index.php" class="sidebar-logo">
    <div class="sidebar-logo-icon"><i class="fas fa-shield-halved"></i></div>
    <span class="sidebar-logo-text">KOAK Admin</span>
  </a>
  <nav class="sidebar-nav">
    <div class="nav-label">Genel</div>
    <a href="admin_index.php" class="nav-item"><i class="fas fa-gauge-high"></i> Dashboard</a>
    <div class="nav-label">İçerik</div>
    <a href="pages.php" class="nav-item"><i class="fas fa-file-lines"></i> Sayfalar</a>
    <a href="news.php" class="nav-item"><i class="fas fa-bullhorn"></i> Duyurular</a>
    <a href="categories.php" class="nav-item"><i class="fas fa-tags"></i> Kategoriler</a>
    <a href="gallery.php" class="nav-item active"><i class="fas fa-images"></i> Galeri</a>
    <a href="sliders.php" class="nav-item"><i class="fas fa-layer-group"></i> Sliderlar</a>
    <div class="nav-label">Ayarlar</div>
    <a href="admin_index.php#settings" class="nav-item"><i class="fas fa-gear"></i> Site Ayarları</a>
  </nav>
  <div class="sidebar-footer">
    <div class="sidebar-user" onclick="logout()">
      <div class="user-avatar"><?php echo $admin_initials; ?></div>
      <div class="user-info">
        <div class="user-name"><?php echo $admin_name; ?></div>
        <div class="user-role">Yönetici</div>
      </div>
      <i class="fas fa-arrow-right-from-bracket logout-icon"></i>
    </div>
  </div>
</aside>

<header class="topbar">
  <button class="topbar-hamburger" onclick="openSidebar()"><i class="fas fa-bars"></i></button>
  <div class="topbar-title">Galeri Yönetimi</div>
  <div class="topbar-right">
    <span class="topbar-date" id="topbar-date"></span>
  </div>
</header>

<main class="main">

  <div class="page-header">
    <div>
      <h1>Galeri Yönetimi</h1>
      <p><?php echo count($gallery); ?> görsel</p>
    </div>
  </div>

  <div class="card">
    <div class="card-header">
      <div class="card-header-icon"><i class="fas fa-cloud-arrow-up"></i></div>
      <div>
        <h2>Yeni Görsel Ekle</h2>
        <p>Galeri için yeni görsel yükle</p>
      </div>
    </div>
    <div class="card-body">
      <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="action" value="add_image">
        <div class="form-row">
          <div class="form-group">
            <label><i class="fas fa-heading"></i> Başlık</label>
            <input type="text" name="title" placeholder="Görsel başlığı" required>
          </div>
          <div class="form-group">
            <label><i class="fas fa-comment"></i> Açıklama</label>
            <input type="text" name="description" placeholder="Kısa açıklama (opsiyonel)">
          </div>
        </div>
        <div class="form-group">
          <label><i class="fas fa-image"></i> Görsel Dosyası</label>
          <input type="file" name="image" accept="image/*" required>
        </div>
        <hr class="divider">
        <button type="submit" class="btn btn-primary"><i class="fas fa-cloud-arrow-up"></i> Yükle</button>
      </form>
    </div>
  </div>

  <div class="card">
    <div class="card-header">
      <div class="card-header-icon"><i class="fas fa-images"></i></div>
      <div>
        <h2>Galeri Görselleri</h2>
        <p><?php echo count($gallery); ?> görsel</p>
      </div>
    </div>
    <div class="card-body">
      <?php if (empty($gallery)): ?>
      <div class="empty-state">
        <i class="fas fa-images"></i>
        <p>Henüz görsel eklenmedi. Yukarıdan yeni görsel yükleyebilirsiniz.</p>
      </div>
      <?php else: ?>
      <div class="gallery-grid">
        <?php foreach ($gallery as $item): ?>
        <div class="gallery-item">
          <?php if (!empty($item['image_path'])): ?>
          <img src="../../<?php echo e($item['image_path']); ?>" alt="<?php echo e($item['title']); ?>" class="gallery-thumb" loading="lazy">
          <?php else: ?>
          <div class="gallery-thumb-placeholder"><i class="fas fa-image"></i></div>
          <?php endif; ?>
          <div class="gallery-info">
            <div class="gallery-name"><?php echo e($item['title']); ?></div>
            <?php if (!empty($item['description'])): ?>
            <div class="gallery-desc"><?php echo e($item['description']); ?></div>
            <?php endif; ?>
            <div class="gallery-actions">
              <form method="POST" style="flex:1;" id="deleteForm<?php echo $item['id']; ?>">
                <input type="hidden" name="action" value="delete_image">
                <input type="hidden" name="id" value="<?php echo $item['id']; ?>">
                <button type="button" class="btn btn-danger btn-sm delete-btn" data-id="<?php echo $item['id']; ?>" data-title="<?php echo e($item['title']); ?>">
                  <i class="fas fa-trash"></i> Sil
                </button>
              </form>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>
  </div>

</main>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.all.min.js"></script>
<script>
function showNotification(type, message) {
  const Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: true,
    didOpen: (toast) => {
      toast.addEventListener('mouseenter', Swal.stopTimer);
      toast.addEventListener('mouseleave', Swal.resumeTimer);
    }
  });

  Toast.fire({
    icon: type,
    title: message
  });
}

<?php if ($success): ?>
document.addEventListener('DOMContentLoaded', function() {
  showNotification('success', '<?php echo addslashes($success); ?>');
});
<?php elseif ($error): ?>
document.addEventListener('DOMContentLoaded', function() {
  showNotification('error', '<?php echo addslashes($error); ?>');
});
<?php endif; ?>

function openSidebar(){document.getElementById('sidebar').classList.add('open');document.getElementById('overlay').classList.add('open');document.body.style.overflow='hidden';}
function closeSidebar(){document.getElementById('sidebar').classList.remove('open');document.getElementById('overlay').classList.remove('open');document.body.style.overflow='';}
function logout(){Swal.fire({title:'Çıkış yapılsın mı?',text:'Oturumunuz kapatılacak.',icon:'question',showCancelButton:true,confirmButtonColor:'#4f6ef7',cancelButtonColor:'#9aa3b2',confirmButtonText:'Evet, çıkış yap',cancelButtonText:'İptal'}).then(function(result){if(result.isConfirmed){window.location.href='logout.php';}});}

document.addEventListener('DOMContentLoaded', function() {
  const deleteButtons = document.querySelectorAll('.delete-btn');
  deleteButtons.forEach(btn => {
    btn.addEventListener('click', function(e) {
      e.preventDefault();
      const id = this.getAttribute('data-id');
      const title = this.getAttribute('data-title');
      Swal.fire({
        title: 'Görsel silinsin mi?',
        html: `<b>${title}</b> görseli silinecek.`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#f43f5e',
        cancelButtonColor: '#9aa3b2',
        confirmButtonText: 'Evet, sil!',
        cancelButtonText: 'İptal',
        reverseButtons: true
      }).then((result) => {
        if (result.isConfirmed) {
          document.getElementById('deleteForm' + id).submit();
        }
      });
    });
  });
});

(function(){const el=document.getElementById('topbar-date');if(el)el.textContent=new Date().toLocaleDateString('tr-TR',{weekday:'short',day:'numeric',month:'long',year:'numeric'});})();
</script>
</body>
</html>