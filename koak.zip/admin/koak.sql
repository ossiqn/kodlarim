
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+03:00";
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE `categories` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL COMMENT 'Kategori adı (örn: Eğitim, Duyuru)',
  `slug` VARCHAR(100) NOT NULL UNIQUE COMMENT 'URL için özel ad (örn: egitim)',
  `description` TEXT DEFAULT NULL COMMENT 'Kategori açıklaması',
  `icon` VARCHAR(50) DEFAULT 'fa-folder' COMMENT 'Font Awesome ikon kodu (opsiyonel)',
  `color` VARCHAR(20) DEFAULT '#c21e1e' COMMENT 'Kategori rengi (opsiyonel)',
  `sort_order` INT(11) NOT NULL DEFAULT 0 COMMENT 'Sıralama (küçükten büyüğe)',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '1: Aktif, 0: Pasif',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_slug` (`slug`),
  INDEX `idx_active_order` (`is_active`, `sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `pages` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `slug` VARCHAR(255) NOT NULL UNIQUE COMMENT 'Sayfanın URL adı (biz-kimiz, yonetim)',
  `title` VARCHAR(255) NOT NULL COMMENT 'Sayfa başlığı',
  `content` LONGTEXT DEFAULT NULL COMMENT 'Sayfa içeriği (HTML)',
  `meta_title` VARCHAR(255) DEFAULT NULL COMMENT 'SEO Başlığı',
  `meta_description` TEXT DEFAULT NULL COMMENT 'SEO Açıklaması',
  `sort_order` INT(11) NOT NULL DEFAULT 0 COMMENT 'Menü sıralaması için',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '1: Yayında, 0: Taslak',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_slug` (`slug`),
  INDEX `idx_active_order` (`is_active`, `sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `gallery` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(255) NOT NULL COMMENT 'Görsel başlığı',
  `description` TEXT DEFAULT NULL COMMENT 'Görsel açıklaması',
  `image_path` VARCHAR(500) NOT NULL COMMENT 'Dosya yolu (uploads/gallery/... )',
  `sort_order` INT(11) NOT NULL DEFAULT 0 COMMENT 'Görsel sıralaması',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '1: Göster, 0: Gizle',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_active_order` (`is_active`, `sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `sliders` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(255) NOT NULL COMMENT 'Slider başlığı',
  `description` TEXT DEFAULT NULL COMMENT 'Kısa açıklama',
  `image_path` VARCHAR(500) NOT NULL COMMENT 'Görsel yolu (uploads/sliders/...)',
  `link` VARCHAR(500) DEFAULT NULL COMMENT 'Opsiyonel buton linki',
  `button_text` VARCHAR(100) DEFAULT 'Detaylar' COMMENT 'Buton yazısı',
  `sort_order` INT(11) NOT NULL DEFAULT 0 COMMENT 'Gösterim sırası',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '1: Aktif, 0: Pasif',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_active_order` (`is_active`, `sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `news` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(255) NOT NULL COMMENT 'Haber/Duyuru başlığı',
  `slug` VARCHAR(255) NOT NULL UNIQUE COMMENT 'URL için benzersiz ad',
  `summary` TEXT DEFAULT NULL COMMENT 'Kısa özet (listeleme sayfasında)',
  `content` LONGTEXT DEFAULT NULL COMMENT 'Detaylı içerik (HTML)',
  `image` VARCHAR(500) DEFAULT NULL COMMENT 'Kapak görseli yolu (uploads/news/...)',
  `category_id` INT(11) UNSIGNED DEFAULT NULL COMMENT 'Kategori ID',
  `views` INT(11) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Görüntülenme sayısı',
  `is_featured` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '1: Öne çıkan',
  `is_breaking` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '1: Son Dakika',
  `is_headline` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '1: Manşet',
  `status` ENUM('published', 'draft') NOT NULL DEFAULT 'draft' COMMENT 'Yayın durumu',
  `published_at` DATETIME DEFAULT NULL COMMENT 'Yayınlanma zamanı',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_slug` (`slug`),
  INDEX `idx_category` (`category_id`),
  INDEX `idx_status_published` (`status`, `published_at`),
  INDEX `idx_featured` (`is_featured`),
  INDEX `idx_breaking` (`is_breaking`),
  FULLTEXT INDEX `ft_search` (`title`, `summary`, `content`),
  CONSTRAINT `fk_news_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `messages` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(255) NOT NULL COMMENT 'Gönderenin adı',
  `email` VARCHAR(255) NOT NULL COMMENT 'E-posta adresi',
  `phone` VARCHAR(50) DEFAULT NULL COMMENT 'Telefon',
  `subject` VARCHAR(255) DEFAULT NULL COMMENT 'Konu / Başlık',
  `message` TEXT NOT NULL COMMENT 'Mesaj içeriği',
  `message_type` ENUM('contact', 'volunteer') NOT NULL DEFAULT 'contact' COMMENT 'contact: İletişim, volunteer: Gönüllü başvurusu',
  `extra_data` JSON DEFAULT NULL COMMENT 'Ek bilgiler (şehir, kan grubu vb.)',
  `is_read` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '0: Okunmadı, 1: Okundu',
  `ip_address` VARCHAR(45) DEFAULT NULL COMMENT 'Gönderen IP',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_read` (`is_read`),
  INDEX `idx_type` (`message_type`),
  INDEX `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `settings` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `setting_key` VARCHAR(100) NOT NULL UNIQUE COMMENT 'Ayar anahtarı',
  `setting_value` TEXT DEFAULT NULL COMMENT 'Ayar değeri',
  `setting_type` ENUM('text', 'textarea', 'image', 'number') NOT NULL DEFAULT 'text' COMMENT 'Ayar tipi (opsiyonel)',
  `updated_at` DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_key` (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `users` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(100) NOT NULL UNIQUE COMMENT 'Kullanıcı adı',
  `password` VARCHAR(255) NOT NULL COMMENT 'Hashlenmiş şifre',
  `email` VARCHAR(255) DEFAULT NULL,
  `fullname` VARCHAR(255) DEFAULT NULL COMMENT 'Tam ad',
  `role` ENUM('admin', 'editor') NOT NULL DEFAULT 'editor' COMMENT 'Yetki seviyesi',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '1: Aktif, 0: Pasif',
  `last_login` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_username` (`username`),
  INDEX `idx_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `categories` (`id`, `name`, `slug`, `icon`, `color`) VALUES
(1, 'Eğitim', 'egitim', 'fa-chalkboard-user', '#2563eb'),
(2, 'Operasyon', 'operasyon', 'fa-truck-medical', '#c21e1e'),
(3, 'Duyuru', 'duyuru', 'fa-bullhorn', '#ca8a04'),
(4, 'Haberler', 'haberler', 'fa-newspaper', '#059669'),
(5, 'Tatbikat', 'tatbikat', 'fa-people-group', '#7c3aed');

INSERT INTO `pages` (`slug`, `title`, `content`, `sort_order`) VALUES
('biz-kimiz', 'Biz Kimiz?', '<h2>KOAK Arama Kurtarma Derneği</h2>\n<p>Doğal afetlerde ve acil durumlarda yardıma ihtiyacı olan her canlının yanında olmak için kurulmuş, tamamen gönüllülük esasına dayalı bir arama kurtarma derneğiyiz. Düzenli eğitimlerimiz ve donanımlı ekibimizle her an göreve hazırız.</p>\n<p>Misyonumuz: Afet bölgelerine en kısa sürede ulaşarak profesyonel arama kurtarma hizmeti vermek. Vizyonumuz ise ülkemizin en saygın ve en hızlı müdahale eden sivil toplum kuruluşlarından biri olmaktır.</p>', 10),
('yonetim', 'Yönetim Kurulu', '<p>Derneğimiz, alanında uzman ve gönüllülük esasıyla çalışan bir yönetim kurulu tarafından yönetilmektedir.</p>\n<ul>\n<li><strong>Ahmet Yılmaz</strong> - Başkan</li>\n<li><strong>Ayşe Demir</strong> - Başkan Yardımcısı</li>\n<li><strong>Mehmet Kaya</strong> - Genel Sekreter</li>\n<li><strong>Fatma Çelik</strong> - Sayman</li>\n</ul>', 20),
('belgeler', 'Belgelerimiz', '<p>Derneğimize ait resmi belgeler ve yönetmelikler aşağıda listelenmiştir.</p>\n<ul>\n<li><a href="#">Tüzük</a></li>\n<li><a href="#">İç Yönetmelik</a></li>\n<li><a href="#">Vergi Muafiyeti Belgesi</a></li>\n<li><a href="#">Faaliyet Raporu 2024</a></li>\n</ul>', 30);

INSERT INTO `sliders` (`title`, `description`, `image_path`, `link`, `button_text`) VALUES
('Hayat Kurtarmak İçin Buradayız', 'Gönüllü ekibimizle afetlerde 7/24 hizmet veriyoruz.', 'uploads/sliders/slide1.jpg', 'biz-kimiz.php', 'Detaylar'),
('Siz de Katılın!', 'Arama kurtarma ekibimize katılarak hayat kurtarın.', 'uploads/sliders/slide2.jpg', 'destek.php', 'Katıl'),
('Profesyonel Eğitimler', 'Tam donanımlı eğitimlerle her an göreve hazırız.', 'uploads/sliders/slide3.jpg', 'faaliyetler.php', 'Eğitimler');

INSERT INTO `gallery` (`title`, `description`, `image_path`) VALUES
('Tatbikat 2024', 'Yıllık arama kurtarma tatbikatımızdan kareler.', 'uploads/gallery/tatbikat1.jpg'),
('Ekipman Tanıtımı', 'Yeni nesil arama kurtarma ekipmanlarımız.', 'uploads/gallery/ekipman.jpg');

INSERT INTO `news` (`title`, `slug`, `summary`, `content`, `category_id`, `status`, `published_at`) VALUES
('Deprem Bölgesine Hareket Ettik', 'deprem-bolgesine-hareket', 'AFAD koordinasyonunda ekiplerimiz bölgeye intikal etti.', '<p>Detaylı bilgiler gelişmelerle birlikte paylaşılacaktır.</p>', 2, 'published', NOW()),
('Temel Arama Kurtarma Eğitimi', 'temel-egitim-2024', 'Yeni dönem temel arama kurtarma eğitimlerimiz başlıyor.', '<p>Başvurular için iletişim sayfasını ziyaret edebilirsiniz.</p>', 1, 'published', NOW());

INSERT INTO `settings` (`setting_key`, `setting_value`) VALUES
('site_title', 'KOAK | Arama Kurtarma Derneği'),
('logo', 'uploads/logo.png'),

('email', 'bilgi@koak.org.tr'),
('phone', '+90 537 608 85 01'),
('address', 'Örnek Mah. Kurtuluş Cad. No:123 Merkez/Türkiye'),

('facebook', 'https://facebook.com/koak'),
('twitter', 'https://twitter.com/koak'),
('instagram', 'https://instagram.com/koak'),
('youtube', 'https://youtube.com/koak'),

('hero_title', 'HAYAT KURTARMAK İÇİN BURADAYIZ'),
('hero_desc', 'Gönüllü ekibimizle afetlerde ve acil durumlarda din, dil, ırk ayrımı gözetmeksizin profesyonel arama kurtarma hizmeti veriyoruz.'),

('about_title', 'Biz Kimiz?'),
('about_desc', 'Doğal afetlerde ve acil durumlarda yardıma ihtiyacı olan her canlının yanında olmak için kurulmuş, tamamen gönüllülük esasına dayalı bir arama kurtarma derneğiyiz.'),

('stat1_num', '450'), ('stat1_text', 'Aktif Gönüllü'),
('stat2_num', '120'), ('stat2_text', 'Operasyon'),
('stat3_num', '3000'), ('stat3_text', 'Kurtarılan Can'),
('stat4_num', '85'),  ('stat4_text', 'Eğitim Semineri'),

('bank1_name', 'Ziraat Bankası'),
('bank1_iban', 'TR12 0000 0000 0000 0000 0000 00'),
('bank1_holder', 'KOAK Arama Kurtarma Derneği'),
('bank2_name', 'Garanti BBVA'),
('bank2_iban', 'TR34 0000 0000 0000 0000 0000 00'),
('bank2_holder', 'KOAK Arama Kurtarma Derneği'),
('sms_text', 'DESTEK'),
('sms_number', '2868'),
('sms_price', '50');

INSERT INTO `users` (`username`, `password`, `fullname`, `role`) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Admin User', 'admin');
