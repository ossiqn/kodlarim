<?php
require_once __DIR__ . '/config.php';
if (!isLoggedIn()) { header('Location: login.php'); exit; }

$success = '';
$error   = '';
$action  = $_GET['action'] ?? 'list';
$id      = isset($_GET['id']) ? intval($_GET['id']) : (isset($_POST['id']) ? intval($_POST['id']) : 0);

if ($action === 'delete' && $id > 0) {
    try {
        $st = $db->prepare("SELECT image FROM news WHERE id = ?");
        $st->execute([$id]);
        $img = $st->fetchColumn();
        if ($img && file_exists(__DIR__ . '/../' . $img)) { @unlink(__DIR__ . '/../' . $img); }
        if ($img && file_exists(__DIR__ . '/' . $img)) { @unlink(__DIR__ . '/' . $img); }
        $db->prepare("DELETE FROM news WHERE id = ?")->execute([$id]);
        header('Location: news.php?msg=deleted');
        exit;
    } catch (Exception $e) {
        $error = 'Silme hatası: ' . $e->getMessage();
    }
}

if ($action === 'toggle' && $id > 0) {
    $st = $db->prepare("SELECT status FROM news WHERE id = ?");
    $st->execute([$id]);
    $newStat = ($st->fetchColumn() === 'published') ? 'draft' : 'published';
    $db->prepare("UPDATE news SET status = ? WHERE id = ?")->execute([$newStat, $id]);
    header('Location: news.php?msg=status_changed');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && in_array($action, ['add', 'edit'])) {
    $title = trim($_POST['title'] ?? '');
    $summary = trim($_POST['summary'] ?? '');
    $content = $_POST['content'] ?? '';
    $cat = isset($_POST['category_id']) && $_POST['category_id'] !== '' ? intval($_POST['category_id']) : null;
    $status = $_POST['status'] ?? 'draft';
    $slug = createSlug($title);
    
    $image = '';
    if ($action === 'edit') {
        $news_data = getNewsById($id);
        $image = $news_data['image'] ?? '';
    }

    if (empty($title) || empty($content)) {
        $error = 'Başlık ve içerik alanları zorunludur.';
    } else {
        if (!empty($_FILES['image']['name']) && $_FILES['image']['error'] === 0) {
            $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
            if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) {
                $upload_dir = __DIR__ . '/uploads/news/';
                if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);
                
                $fn = 'news_' . time() . '_' . mt_rand(100, 999) . '.' . $ext;
                if (move_uploaded_file($_FILES['image']['tmp_name'], $upload_dir . $fn)) {
                    if ($action === 'edit' && $image && file_exists(__DIR__ . '/../' . $image)) { @unlink(__DIR__ . '/../' . $image); }
                    if ($action === 'edit' && $image && file_exists(__DIR__ . '/' . $image)) { @unlink(__DIR__ . '/' . $image); }
                    $image = 'uploads/news/' . $fn;
                } else {
                    $error = 'Görsel yüklenemedi. Klasör izinlerini kontrol edin.';
                }
            } else {
                $error = 'Sadece JPG, PNG, GIF ve WEBP formatları desteklenir.';
            }
        }

        if (empty($error)) {
            try {
                if ($action === 'add') {
                    $st = $db->prepare("INSERT INTO news (title, slug, summary, content, image, category_id, status, published_at, created_at, updated_at) VALUES(?,?,?,?,?,?,?, NOW(), NOW(), NOW())");
                    $st->execute([$title, $slug, $summary, $content, $image, $cat, $status]);
                    header('Location: news.php?msg=added');
                    exit;
                } else {
                    $st = $db->prepare("UPDATE news SET title=?, slug=?, summary=?, content=?, image=?, category_id=?, status=?, updated_at=NOW() WHERE id=?");
                    $st->execute([$title, $slug, $summary, $content, $image, $cat, $status, $id]);
                    $success = 'Duyuru başarıyla güncellendi!';
                    $action = 'list';
                }
            } catch (PDOException $e) {
                $error = 'Hata: ' . $e->getMessage();
            }
        }
    }
}

try {
    $newsList = $db->query("SELECT n.*, c.name as cat_name FROM news n LEFT JOIN categories c ON n.category_id = c.id ORDER BY n.id DESC")->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) { $newsList = []; }

$edit_news = null;
if ($action === 'edit' && $id > 0) {
    try {
        $edit_news = getNewsById($id);
        if (!$edit_news) $action = 'list';
    } catch (Exception $e) { $action = 'list'; }
}

$categories = getCategories();
$admin_name = e($_SESSION['admin_user']['fullname'] ?? $_SESSION['admin_user']['username'] ?? 'Admin');
$admin_initials = strtoupper(substr($admin_name, 0, 2));
?>
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Duyuru ve Haberler — Admin Panel</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.all.min.js"></script>
  <script src="https://cdn.ckeditor.com/ckeditor5/39.0.1/classic/ckeditor.js"></script>
  <style>
    :root{--sidebar-w:248px;--topbar-h:60px;--bg:#f4f6f9;--surface:#fff;--border:#e8eaf0;--text:#1a1d2e;--text-2:#5a6272;--text-3:#9aa3b2;--accent:#4f6ef7;--accent-2:#6c47ff;--accent-bg:#eef1fe;--green:#22c55e;--green-bg:#dcfce7;--rose:#f43f5e;--rose-bg:#ffe4e6;--warning:#f59e0b;--warning-bg:#fef3c7;--radius:12px;--radius-sm:8px;--shadow:0 1px 3px rgba(0,0,0,.07),0 4px 12px rgba(0,0,0,.04);--shadow-md:0 4px 16px rgba(0,0,0,.10);}
    *,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
    html{font-size:15px;}
    body{font-family:'Plus Jakarta Sans',sans-serif;background:var(--bg);color:var(--text);min-height:100vh;display:flex;}
    .sidebar{width:var(--sidebar-w);background:var(--surface);border-right:1px solid var(--border);display:flex;flex-direction:column;position:fixed;top:0;left:0;bottom:0;z-index:100;transition:transform .28s cubic-bezier(.4,0,.2,1);}
    .sidebar-logo{height:var(--topbar-h);display:flex;align-items:center;padding:0 20px;border-bottom:1px solid var(--border);gap:10px;text-decoration:none;}
    .sidebar-logo-icon{width:32px;height:32px;background:linear-gradient(135deg,var(--accent),var(--accent-2));border-radius:9px;display:flex;align-items:center;justify-content:center;color:#fff;font-size:14px;flex-shrink:0;}
    .sidebar-logo-text{font-size:15px;font-weight:700;color:var(--text);}
    .sidebar-nav{flex:1;padding:16px 12px;overflow-y:auto;}
    .nav-label{font-size:10.5px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--text-3);padding:0 8px;margin:18px 0 6px;}
    .nav-label:first-child{margin-top:0;}
    .nav-item{display:flex;align-items:center;gap:10px;padding:9px 10px;border-radius:var(--radius-sm);text-decoration:none;color:var(--text-2);font-size:13.5px;font-weight:500;transition:background .15s,color .15s;margin-bottom:2px;}
    .nav-item i{width:18px;text-align:center;font-size:13px;flex-shrink:0;}
    .nav-item:hover{background:var(--bg);color:var(--text);}
    .nav-item.active{background:var(--accent-bg);color:var(--accent);font-weight:600;}
    .nav-item.active i{color:var(--accent);}
    .sidebar-footer{padding:14px 12px;border-top:1px solid var(--border);}
    .sidebar-user{display:flex;align-items:center;gap:10px;padding:9px 10px;border-radius:var(--radius-sm);cursor:pointer;transition:background .15s;}
    .sidebar-user:hover{background:var(--bg);}
    .user-avatar{width:32px;height:32px;border-radius:50%;background:linear-gradient(135deg,var(--accent),var(--accent-2));color:#fff;font-size:12px;font-weight:700;display:flex;align-items:center;justify-content:center;flex-shrink:0;}
    .user-info{flex:1;min-width:0;}
    .user-name{font-size:13px;font-weight:600;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
    .user-role{font-size:11px;color:var(--text-3);}
    .logout-icon{color:var(--text-3);font-size:13px;flex-shrink:0;}
    .sidebar-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.4);z-index:99;}
    .topbar{position:fixed;top:0;left:var(--sidebar-w);right:0;height:var(--topbar-h);background:var(--surface);border-bottom:1px solid var(--border);display:flex;align-items:center;padding:0 24px;gap:16px;z-index:90;}
    .topbar-hamburger{display:none;background:none;border:none;cursor:pointer;padding:6px;color:var(--text-2);font-size:18px;}
    .topbar-title{font-size:16px;font-weight:700;color:var(--text);}
    .topbar-right{margin-left:auto;}
    .topbar-date{font-size:12.5px;color:var(--text-3);}
    .main{margin-left:var(--sidebar-w);margin-top:var(--topbar-h);padding:28px 28px 60px;flex:1;min-width:0;}
    .page-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:24px;flex-wrap:wrap;gap:12px;}
    .page-header h1{font-size:22px;font-weight:700;}
    .page-header p{font-size:13px;color:var(--text-3);margin-top:2px;}
    .alert{display:flex;align-items:flex-start;gap:12px;padding:14px 18px;border-radius:var(--radius);margin-bottom:24px;font-size:14px;}
    .alert i{margin-top:1px;flex-shrink:0;}
    .alert-success{background:var(--green-bg);color:#15803d;border:1px solid #bbf7d0;}
    .alert-error{background:var(--rose-bg);color:#9f1239;border:1px solid #fecdd3;}
    .card{background:var(--surface);border-radius:var(--radius);box-shadow:var(--shadow);border:1px solid var(--border);margin-bottom:20px;}
    .card-header{padding:18px 24px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:10px;}
    .card-header-icon{width:34px;height:34px;border-radius:9px;background:var(--accent-bg);color:var(--accent);display:flex;align-items:center;justify-content:center;font-size:14px;flex-shrink:0;}
    .card-header h2{font-size:15px;font-weight:700;}
    .card-header p{font-size:12.5px;color:var(--text-3);margin-top:1px;}
    .card-body{padding:24px;}
    .btn{display:inline-flex;align-items:center;gap:8px;padding:10px 20px;border-radius:var(--radius-sm);font-size:13.5px;font-weight:600;font-family:'Plus Jakarta Sans',sans-serif;cursor:pointer;border:none;transition:all .18s;text-decoration:none;white-space:nowrap;}
    .btn-primary{background:linear-gradient(135deg,var(--accent),var(--accent-2));color:#fff;box-shadow:0 2px 8px rgba(79,110,247,.28);}
    .btn-primary:hover{transform:translateY(-1px);box-shadow:0 6px 16px rgba(79,110,247,.38);}
    .btn-secondary{background:var(--bg);color:var(--text-2);border:1.5px solid var(--border);}
    .btn-secondary:hover{background:var(--border);color:var(--text);}
    .btn-danger{background:var(--rose-bg);color:var(--rose);}
    .btn-danger:hover{background:var(--rose);color:#fff;}
    .btn-sm{padding:7px 13px;font-size:12.5px;}
    .btn-icon{padding:7px;width:34px;height:34px;justify-content:center;}
    .table-wrap{overflow-x:auto;}
    .table{width:100%;border-collapse:collapse;min-width:700px;}
    .table th{background:var(--bg);padding:12px 16px;text-align:left;font-size:11.5px;font-weight:700;color:var(--text-3);text-transform:uppercase;letter-spacing:.06em;border-bottom:1px solid var(--border);}
    .table td{padding:13px 16px;border-bottom:1px solid var(--border);vertical-align:middle;font-size:14px;}
    .table tbody tr:last-child td{border-bottom:none;}
    .table tbody tr:hover{background:#f9fafb;}
    .form-grid{display:grid;grid-template-columns:2fr 1fr;gap:24px;}
    .form-group{margin-bottom:18px;}
    .form-group:last-child{margin-bottom:0;}
    label{display:block;margin-bottom:6px;font-size:13px;font-weight:600;color:var(--text-2);}
    label i{margin-right:4px;color:var(--text-3);font-size:12px;}
    input[type="text"],select{width:100%;padding:10px 14px;border:1.5px solid var(--border);border-radius:var(--radius-sm);font-size:14px;font-family:'Plus Jakarta Sans',sans-serif;color:var(--text);background:#fff;transition:border-color .18s,box-shadow .18s;outline:none;}
    input[type="text"]:focus,select:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(79,110,247,.12);}
    textarea.simple-ta{width:100%;padding:10px 14px;border:1.5px solid var(--border);border-radius:var(--radius-sm);font-size:14px;font-family:'Plus Jakarta Sans',sans-serif;color:var(--text);background:#fff;outline:none;resize:vertical;min-height:90px;transition:border-color .18s;}
    textarea.simple-ta:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(79,110,247,.12);}
    .upload-box{border:1.5px dashed var(--border);padding:24px 20px;text-align:center;border-radius:var(--radius-sm);position:relative;background:var(--bg);transition:all .2s;cursor:pointer;}
    .upload-box:hover{border-color:var(--accent);background:var(--accent-bg);}
    .upload-box i{font-size:28px;color:var(--accent);margin-bottom:10px;}
    .upload-box .file-name{font-size:13px;color:var(--text-2);font-weight:600;}
    .upload-input{position:absolute;top:0;left:0;width:100%;height:100%;opacity:0;cursor:pointer;}
    .ck-editor__editable_inline{min-height:450px!important;padding:24px!important;font-size:15px!important;color:var(--text);border:1.5px solid var(--border)!important;border-top:none!important;border-radius:0 0 var(--radius-sm) var(--radius-sm)!important;box-shadow:none!important;}
    .ck.ck-toolbar{border:1.5px solid var(--border)!important;border-radius:var(--radius-sm) var(--radius-sm) 0 0!important;background:var(--bg)!important;padding:8px!important;}
    .ck.ck-editor__editable.ck-focused:not(.ck-editor__nested-editable){border-color:var(--accent)!important;box-shadow:none!important;}
    .badge{display:inline-flex;align-items:center;padding:4px 10px;border-radius:20px;font-size:11.5px;font-weight:600;}
    .badge-success{background:var(--green-bg);color:#15803d;}
    .badge-warning{background:var(--warning-bg);color:#b45309;}
    .badge-info{background:var(--accent-bg);color:var(--accent);}
    .thumb-img{width:60px;height:45px;border-radius:6px;object-fit:cover;border:1px solid var(--border);}
    .empty-state{text-align:center;padding:48px 20px;}
    .empty-state i{font-size:36px;color:var(--text-3);margin-bottom:12px;display:block;}
    .empty-state p{color:var(--text-3);font-size:14px;}
    @media(max-width:1024px){.form-grid{grid-template-columns:1fr;}}
    @media(max-width:768px){
      .sidebar{transform:translateX(-100%);}
      .sidebar.open{transform:translateX(0);box-shadow:var(--shadow-md);}
      .sidebar-overlay.open{display:block;}
      .topbar{left:0;}
      .topbar-hamburger{display:flex;}
      .main{margin-left:0;padding:20px 16px 60px;}
      .card-body{padding:16px;}
      .card-header{padding:14px 16px;}
    }
  </style>
</head>
<body>

<div class="sidebar-overlay" id="overlay" onclick="closeSidebar()"></div>

<aside class="sidebar" id="sidebar">
  <a href="admin_index.php" class="sidebar-logo">
    <div class="sidebar-logo-icon"><i class="fas fa-shield-halved"></i></div>
    <span class="sidebar-logo-text">KOAK Admin</span>
  </a>
  <nav class="sidebar-nav">
    <div class="nav-label">Genel</div>
    <a href="admin_index.php" class="nav-item"><i class="fas fa-gauge-high"></i> Dashboard</a>
    <div class="nav-label">İçerik</div>
    <a href="pages.php" class="nav-item"><i class="fas fa-file-lines"></i> Sayfalar</a>
    <a href="news.php" class="nav-item active"><i class="fas fa-bullhorn"></i> Duyurular</a>
    <a href="categories.php" class="nav-item"><i class="fas fa-tags"></i> Kategoriler</a>
    <a href="gallery.php" class="nav-item"><i class="fas fa-images"></i> Galeri</a>
    <a href="sliders.php" class="nav-item"><i class="fas fa-layer-group"></i> Sliderlar</a>
    <div class="nav-label">Ayarlar</div>
    <a href="admin_index.php#settings" class="nav-item"><i class="fas fa-gear"></i> Site Ayarları</a>
  </nav>
  <div class="sidebar-footer">
    <div class="sidebar-user" onclick="logout()">
      <div class="user-avatar"><?php echo $admin_initials; ?></div>
      <div class="user-info">
        <div class="user-name"><?php echo $admin_name; ?></div>
        <div class="user-role">Yönetici</div>
      </div>
      <i class="fas fa-arrow-right-from-bracket logout-icon"></i>
    </div>
  </div>
</aside>

<header class="topbar">
  <button class="topbar-hamburger" onclick="openSidebar()"><i class="fas fa-bars"></i></button>
  <div class="topbar-title">
    <?php if ($action==='add') echo 'Yeni Duyuru Ekle';
    elseif ($action==='edit') echo 'Duyuruyu Düzenle';
    else echo 'Duyuru ve Haber Yönetimi'; ?>
  </div>
  <div class="topbar-right"><span class="topbar-date" id="topbar-date"></span></div>
</header>

<main class="main">

<?php if ($success): ?>
<div class="alert alert-success"><i class="fas fa-circle-check"></i><span><?php echo $success; ?></span></div>
<?php endif; ?>
<?php if ($error): ?>
<div class="alert alert-error"><i class="fas fa-circle-exclamation"></i><span><?php echo $error; ?></span></div>
<?php endif; ?>
<?php if (isset($_GET['msg'])): ?>
  <?php if($_GET['msg']==='deleted'): ?>
  <div class="alert alert-success"><i class="fas fa-circle-check"></i><span>İçerik başarıyla silindi.</span></div>
  <?php elseif($_GET['msg']==='added'): ?>
  <div class="alert alert-success"><i class="fas fa-circle-check"></i><span>İçerik başarıyla eklendi.</span></div>
  <?php elseif($_GET['msg']==='status_changed'): ?>
  <div class="alert alert-success"><i class="fas fa-circle-check"></i><span>Yayın durumu değiştirildi.</span></div>
  <?php endif; ?>
<?php endif; ?>

<?php if ($action === 'list'): ?>

  <div class="page-header">
    <div>
      <h1>Duyuru Yönetimi</h1>
      <p><?php echo count($newsList); ?> adet kayıtlı içerik</p>
    </div>
    <a href="?action=add" class="btn btn-primary"><i class="fas fa-plus"></i> Yeni Ekle</a>
  </div>

  <div class="card">
    <div class="card-body" style="padding:0;">
      <div class="table-wrap">
        <table class="table">
          <thead>
            <tr>
              <th>Görsel</th>
              <th>Başlık & Kategori</th>
              <th>Durum</th>
              <th>Tarih</th>
              <th style="text-align:right;">İşlem</th>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($newsList)): ?>
            <tr><td colspan="5">
              <div class="empty-state">
                <i class="fas fa-bullhorn"></i>
                <p>Henüz içerik eklenmemiş. Yeni bir duyuru veya haber ekleyin.</p>
              </div>
            </td></tr>
            <?php else: foreach ($newsList as $n): ?>
            <tr>
              <td>
                <?php if(!empty($n['image'])): ?>
                  <img src="../<?php echo e($n['image']); ?>" class="thumb-img">
                <?php else: ?>
                  <div class="thumb-img" style="background:var(--bg);display:flex;align-items:center;justify-content:center;color:var(--text-3);"><i class="fas fa-image"></i></div>
                <?php endif; ?>
              </td>
              <td>
                <div style="font-weight:600;margin-bottom:3px;"><?php echo e($n['title']); ?></div>
                <div style="font-size:12px;color:var(--text-3);"><i class="fas fa-folder" style="font-size:10px;"></i> <?php echo e($n['cat_name'] ?? 'Kategorisiz'); ?></div>
              </td>
              <td>
                <span class="badge <?php echo $n['status']==='published'?'badge-success':'badge-warning'; ?>">
                  <?php echo $n['status']==='published'?'Yayında':'Taslak'; ?>
                </span>
              </td>
              <td style="color:var(--text-3);font-size:13px;">
                <?php echo date('d.m.Y H:i', strtotime($n['created_at'])); ?>
              </td>
              <td style="text-align:right;">
                <div style="display:flex;gap:6px;justify-content:flex-end;">
                  <a href="?action=toggle&id=<?php echo $n['id']; ?>" class="btn btn-icon" style="background:var(--bg);color:var(--text-2);" title="Durumu Değiştir">
                    <i class="fas fa-exchange-alt"></i>
                  </a>
                  <a href="?action=edit&id=<?php echo $n['id']; ?>" class="btn btn-icon" style="background:var(--accent-bg);color:var(--accent);" title="Düzenle">
                    <i class="fas fa-pen"></i>
                  </a>
                  <button type="button" class="btn btn-icon btn-danger delete-btn" data-id="<?php echo $n['id']; ?>" data-title="<?php echo e($n['title']); ?>" title="Sil">
                    <i class="fas fa-trash"></i>
                  </button>
                </div>
              </td>
            </tr>
            <?php endforeach; endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

<?php elseif ($action === 'add' || ($action === 'edit' && $edit_news)): ?>

  <div class="page-header">
    <div style="display:flex;align-items:center;gap:12px;">
      <a href="news.php" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left"></i> Geri</a>
      <div>
        <h1><?php echo $action==='add' ? 'Yeni Duyuru Ekle' : 'İçeriği Düzenle'; ?></h1>
        <p><?php echo $action==='add' ? 'Sisteme yeni bir bildirim girin.' : 'Mevcut bildirimi güncelliyorsunuz.'; ?></p>
      </div>
    </div>
    <?php if($action==='edit'): ?>
    <button type="button" class="btn btn-danger btn-sm delete-btn" data-id="<?php echo $edit_news['id']; ?>" data-title="<?php echo e($edit_news['title']); ?>">
      <i class="fas fa-trash"></i> İçeriği Sil
    </button>
    <?php endif; ?>
  </div>

  <form id="newsForm" method="POST" enctype="multipart/form-data">
    <input type="hidden" name="action" value="<?php echo $action; ?>">
    <input type="hidden" name="id" value="<?php echo $edit_news['id'] ?? ''; ?>">
    
    <div class="form-grid">
      <div>
        <div class="card">
          <div class="card-header">
            <div class="card-header-icon"><i class="fas fa-pen-to-square"></i></div>
            <div><h2>Metin ve Detaylar</h2><p>İçerik yazılarını buradan girin</p></div>
          </div>
          <div class="card-body">
            <div class="form-group">
              <label>Başlık</label>
              <input type="text" name="title" required value="<?php echo e($edit_news['title'] ?? ''); ?>" placeholder="Dikkat çekici bir başlık girin...">
            </div>
            <div class="form-group">
              <label>Kısa Özet</label>
              <textarea name="summary" class="simple-ta" placeholder="İçeriğin kısa özeti..."><?php echo e($edit_news['summary'] ?? ''); ?></textarea>
            </div>
            <div class="form-group" style="margin-bottom:0;">
              <label>Detaylı İçerik</label>
              <textarea name="content" id="editor"><?php echo $edit_news['content'] ?? ''; ?></textarea>
            </div>
          </div>
        </div>
      </div>
      
      <div>
        <div class="card">
          <div class="card-header">
            <div class="card-header-icon"><i class="fas fa-sliders"></i></div>
            <div><h2>Yayın Ayarları</h2><p>Kategori, görsel ve durum</p></div>
          </div>
          <div class="card-body">
            <div class="form-group">
              <label>Kategori</label>
              <select name="category_id" required>
                <option value="">Seçiniz...</option>
                <?php foreach($categories as $c): ?>
                  <option value="<?php echo $c['id']; ?>" <?php echo ($edit_news['category_id'] ?? '') == $c['id'] ? 'selected' : ''; ?>><?php echo e($c['name']); ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-group">
              <label>Yayın Durumu</label>
              <select name="status">
                <option value="published" <?php echo ($edit_news['status'] ?? '') === 'published' ? 'selected' : ''; ?>>Yayında</option>
                <option value="draft" <?php echo ($edit_news['status'] ?? '') === 'draft' ? 'selected' : ''; ?>>Taslak Olarak Kaydet</option>
              </select>
            </div>
            <div class="form-group" style="margin-top:24px;">
              <label>Kapak Görseli</label>
              <?php if(!empty($edit_news['image'])): ?>
                <img src="../<?php echo $edit_news['image']; ?>" style="width:100%; border-radius:var(--radius-sm); margin-bottom:10px; border:1px solid var(--border);">
              <?php endif; ?>
              <div class="upload-box">
                <i class="fas fa-cloud-arrow-up"></i>
                <div class="file-name" id="fileName">Görsel seçmek için tıklayın</div>
                <input type="file" name="image" id="imageInput" accept="image/*" class="upload-input" <?php echo $action==='add' ? 'required' : ''; ?>>
              </div>
            </div>

            <hr class="divider">
            <button type="submit" class="btn btn-primary" style="width:100%; justify-content:center; padding:12px;">
              <i class="fas fa-floppy-disk"></i> <?php echo $action==='add' ? 'Kaydet ve Yayınla' : 'Değişiklikleri Güncelle'; ?>
            </button>
          </div>
        </div>
      </div>
    </div>
  </form>

  <script>
    let editorInstance = null;
    
    if (document.querySelector('#editor')) {
      ClassicEditor.create(document.querySelector('#editor'), {
        toolbar: ['heading', '|', 'bold', 'italic', 'link', 'bulletedList', 'numberedList', 'blockQuote', '|', 'undo', 'redo']
      })
      .then(editor => {
        editorInstance = editor;
      })
      .catch(error => console.error(error));
    }

    const newsForm = document.getElementById('newsForm');
    if (newsForm) {
      newsForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const action = document.querySelector('input[name="action"]').value;
        const title = document.querySelector('input[name="title"]').value;
        
        if (editorInstance) {
          document.querySelector('#editor').value = editorInstance.getData();
        }
        
        Swal.fire({
          title: action === 'add' ? 'Duyuru eklensin mi?' : 'Duyuru güncellensin mi?',
          html: `<b>${title}</b> ${action === 'add' ? 'eklenecek.' : 'güncellenecek.'}`,
          icon: 'question',
          showCancelButton: true,
          confirmButtonColor: '#4f6ef7',
          cancelButtonColor: '#9aa3b2',
          confirmButtonText: action === 'add' ? 'Evet, ekle!' : 'Evet, güncelle!',
          cancelButtonText: 'İptal',
          reverseButtons: true,
          showLoaderOnConfirm: true,
          preConfirm: () => {
            newsForm.submit();
          }
        });
      });
    }

    const imgInp = document.getElementById('imageInput');
    if(imgInp) {
      imgInp.addEventListener('change', function(e) {
          let name = e.target.files[0] ? e.target.files[0].name : 'Görsel seçmek için tıklayın';
          document.getElementById('fileName').innerHTML = `<span style="color:var(--green);">${name}</span>`;
      });
    }
  </script>

<?php endif; ?>
</main>

<script>
function openSidebar(){document.getElementById('sidebar').classList.add('open');document.getElementById('overlay').classList.add('open');document.body.style.overflow='hidden';}
function closeSidebar(){document.getElementById('sidebar').classList.remove('open');document.getElementById('overlay').classList.remove('open');document.body.style.overflow='';}
function logout(){Swal.fire({title:'Çıkış yapılsın mı?',text:'Oturumunuz kapatılacak.',icon:'question',showCancelButton:true,confirmButtonColor:'#4f6ef7',cancelButtonColor:'#9aa3b2',confirmButtonText:'Evet, çıkış yap',cancelButtonText:'İptal'}).then(function(result){if(result.isConfirmed){window.location.href='logout.php';}});}

function confirmDelete(id, title) {
  Swal.fire({
    title:'Silme Onayı',
    html:'<b>' + title + '</b> kalıcı olarak silinecek.',
    icon:'warning',
    showCancelButton:true,
    confirmButtonColor:'#f43f5e',
    cancelButtonColor:'#9aa3b2',
    confirmButtonText:'Evet, Sil',
    cancelButtonText:'İptal'
  }).then(function(r){
    if(r.isConfirmed){
      Swal.fire({title:'Siliniyor...',showConfirmButton:false,didOpen:function(){Swal.showLoading();}});
      window.location.href='news.php?action=delete&id='+id;
    }
  });
}

document.addEventListener('DOMContentLoaded', function() {
  const deleteButtons = document.querySelectorAll('.delete-btn');
  deleteButtons.forEach(btn => {
    btn.addEventListener('click', function(e) {
      e.preventDefault();
      const id = this.getAttribute('data-id');
      const title = this.getAttribute('data-title');
      confirmDelete(id, title);
    });
  });
});

(function(){
  var el = document.getElementById('topbar-date');
  if(el) el.textContent = new Date().toLocaleDateString('tr-TR',{weekday:'short',day:'numeric',month:'long',year:'numeric'});
  
  if(window.history.replaceState) {
    var url = new URL(window.location);
    url.searchParams.delete('msg');
    window.history.replaceState(null, null, url);
  }
})();
</script>
</body>
</html>