<?php
require_once __DIR__ . '/config.php';
if (!isLoggedIn()) { header('Location: login.php'); exit; }

$success = '';
$error   = '';
$action  = $_GET['action'] ?? 'list';
$id      = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['action'] ?? '';

    if ($act === 'add_page') {
        $slug    = trim($_POST['slug']    ?? '');
        $title   = trim($_POST['title']   ?? '');
        $content = $_POST['content']      ?? '';
        if (empty($slug) || empty($title)) {
            $error = 'Sayfa adı ve başlık zorunludur.';
        } else {
            try {
                $chk = $db->prepare("SELECT COUNT(*) FROM pages WHERE slug = ?");
                $chk->execute([$slug]);
                if ($chk->fetchColumn() > 0) {
                    $error = 'Bu sayfa adı zaten kullanılıyor.';
                } else {
                    $st = $db->prepare("INSERT INTO pages (slug, title, content, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW())");
                    $st->execute([$slug, $title, $content]);
                    $success = 'Sayfa başarıyla eklendi!';
                    $action  = 'list';
                }
            } catch (Exception $e) { $error = 'Hata: ' . $e->getMessage(); }
        }
    }

    if ($act === 'update_page') {
        $pid          = intval($_POST['id']          ?? 0);
        $slug    = trim($_POST['slug']     ?? '');
        $title   = trim($_POST['title']    ?? '');
        $content = $_POST['content']       ?? '';
        if (empty($slug) || empty($title)) {
            $error = 'Sayfa adı ve başlık zorunludur.';
        } else {
            try {
                $st = $db->prepare("UPDATE pages SET slug = ?, title = ?, content = ?, updated_at = NOW() WHERE id = ?");
                $st->execute([$slug, $title, $content, $pid]);
                $success = 'Sayfa güncellendi!';
                $action  = 'list';
            } catch (Exception $e) { $error = 'Hata: ' . $e->getMessage(); }
        }
    }
}

if ($action === 'delete' && $id > 0) {
    try {
        $db->prepare("DELETE FROM pages WHERE id = ?")->execute([$id]);
        header('Location: pages.php?msg=deleted'); exit;
    } catch (Exception $e) { $error = 'Silme hatası: ' . $e->getMessage(); }
}

try {
    $all_pages = $db->query("SELECT * FROM pages ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) { $all_pages = []; }

$edit_page = null;
if ($action === 'edit' && $id > 0) {
    try {
        $st = $db->prepare("SELECT * FROM pages WHERE id = ?");
        $st->execute([$id]);
        $edit_page = $st->fetch(PDO::FETCH_ASSOC);
        if (!$edit_page) $action = 'list';
    } catch (Exception $e) { $action = 'list'; }
}

$admin_name     = e($_SESSION['admin_user']['fullname'] ?? $_SESSION['admin_user']['username'] ?? 'Admin');
$admin_initials = strtoupper(substr($admin_name, 0, 2));
?>
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sayfa Yönetimi — Admin Panel</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.all.min.js"></script>
  <style>
    :root{--sidebar-w:248px;--topbar-h:60px;--bg:#f4f6f9;--surface:#fff;--border:#e8eaf0;--text:#1a1d2e;--text-2:#5a6272;--text-3:#9aa3b2;--accent:#4f6ef7;--accent-2:#6c47ff;--accent-bg:#eef1fe;--green:#22c55e;--green-bg:#dcfce7;--rose:#f43f5e;--rose-bg:#ffe4e6;--radius:12px;--radius-sm:8px;--shadow:0 1px 3px rgba(0,0,0,.07),0 4px 12px rgba(0,0,0,.04);--shadow-md:0 4px 16px rgba(0,0,0,.10);}
    *,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
    html{font-size:15px;}
    body{font-family:'Plus Jakarta Sans',sans-serif;background:var(--bg);color:var(--text);min-height:100vh;display:flex;}
    .sidebar{width:var(--sidebar-w);background:var(--surface);border-right:1px solid var(--border);display:flex;flex-direction:column;position:fixed;top:0;left:0;bottom:0;z-index:100;transition:transform .28s cubic-bezier(.4,0,.2,1);}
    .sidebar-logo{height:var(--topbar-h);display:flex;align-items:center;padding:0 20px;border-bottom:1px solid var(--border);gap:10px;text-decoration:none;}
    .sidebar-logo-icon{width:32px;height:32px;background:linear-gradient(135deg,var(--accent),var(--accent-2));border-radius:9px;display:flex;align-items:center;justify-content:center;color:#fff;font-size:14px;flex-shrink:0;}
    .sidebar-logo-text{font-size:15px;font-weight:700;color:var(--text);}
    .sidebar-nav{flex:1;padding:16px 12px;overflow-y:auto;}
    .nav-label{font-size:10.5px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--text-3);padding:0 8px;margin:18px 0 6px;}
    .nav-label:first-child{margin-top:0;}
    .nav-item{display:flex;align-items:center;gap:10px;padding:9px 10px;border-radius:var(--radius-sm);text-decoration:none;color:var(--text-2);font-size:13.5px;font-weight:500;transition:background .15s,color .15s;margin-bottom:2px;}
    .nav-item i{width:18px;text-align:center;font-size:13px;flex-shrink:0;}
    .nav-item:hover{background:var(--bg);color:var(--text);}
    .nav-item.active{background:var(--accent-bg);color:var(--accent);font-weight:600;}
    .nav-item.active i{color:var(--accent);}
    .sidebar-footer{padding:14px 12px;border-top:1px solid var(--border);}
    .sidebar-user{display:flex;align-items:center;gap:10px;padding:9px 10px;border-radius:var(--radius-sm);cursor:pointer;transition:background .15s;}
    .sidebar-user:hover{background:var(--bg);}
    .user-avatar{width:32px;height:32px;border-radius:50%;background:linear-gradient(135deg,var(--accent),var(--accent-2));color:#fff;font-size:12px;font-weight:700;display:flex;align-items:center;justify-content:center;flex-shrink:0;}
    .user-info{flex:1;min-width:0;}
    .user-name{font-size:13px;font-weight:600;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
    .user-role{font-size:11px;color:var(--text-3);}
    .logout-icon{color:var(--text-3);font-size:13px;flex-shrink:0;}
    .sidebar-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.4);z-index:99;}
    .topbar{position:fixed;top:0;left:var(--sidebar-w);right:0;height:var(--topbar-h);background:var(--surface);border-bottom:1px solid var(--border);display:flex;align-items:center;padding:0 24px;gap:16px;z-index:90;}
    .topbar-hamburger{display:none;background:none;border:none;cursor:pointer;padding:6px;color:var(--text-2);font-size:18px;}
    .topbar-title{font-size:16px;font-weight:700;color:var(--text);}
    .topbar-right{margin-left:auto;}
    .topbar-date{font-size:12.5px;color:var(--text-3);}
    .main{margin-left:var(--sidebar-w);margin-top:var(--topbar-h);padding:28px 28px 60px;flex:1;min-width:0;}
    .page-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:24px;flex-wrap:wrap;gap:12px;}
    .page-header h1{font-size:22px;font-weight:700;}
    .page-header p{font-size:13px;color:var(--text-3);margin-top:2px;}
    .alert{display:flex;align-items:flex-start;gap:12px;padding:14px 18px;border-radius:var(--radius);margin-bottom:24px;font-size:14px;}
    .alert i{margin-top:1px;flex-shrink:0;}
    .alert-success{background:var(--green-bg);color:#15803d;border:1px solid #bbf7d0;}
    .alert-error{background:var(--rose-bg);color:#9f1239;border:1px solid #fecdd3;}
    .card{background:var(--surface);border-radius:var(--radius);box-shadow:var(--shadow);border:1px solid var(--border);margin-bottom:20px;}
    .card-header{padding:18px 24px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:10px;}
    .card-header-icon{width:34px;height:34px;border-radius:9px;background:var(--accent-bg);color:var(--accent);display:flex;align-items:center;justify-content:center;font-size:14px;flex-shrink:0;}
    .card-header h2{font-size:15px;font-weight:700;}
    .card-header p{font-size:12.5px;color:var(--text-3);margin-top:1px;}
    .card-body{padding:24px;}
    .btn{display:inline-flex;align-items:center;gap:8px;padding:10px 20px;border-radius:var(--radius-sm);font-size:13.5px;font-weight:600;font-family:'Plus Jakarta Sans',sans-serif;cursor:pointer;border:none;transition:all .18s;text-decoration:none;white-space:nowrap;}
    .btn-primary{background:linear-gradient(135deg,var(--accent),var(--accent-2));color:#fff;box-shadow:0 2px 8px rgba(79,110,247,.28);}
    .btn-primary:hover{transform:translateY(-1px);box-shadow:0 6px 16px rgba(79,110,247,.38);}
    .btn-secondary{background:var(--bg);color:var(--text-2);border:1.5px solid var(--border);}
    .btn-secondary:hover{background:var(--border);color:var(--text);}
    .btn-danger{background:var(--rose-bg);color:var(--rose);}
    .btn-danger:hover{background:var(--rose);color:#fff;}
    .btn-sm{padding:7px 13px;font-size:12.5px;}
    .btn-icon{padding:7px;width:34px;height:34px;justify-content:center;}
    .table-wrap{overflow-x:auto;}
    .table{width:100%;border-collapse:collapse;min-width:500px;}
    .table th{background:var(--bg);padding:12px 16px;text-align:left;font-size:11.5px;font-weight:700;color:var(--text-3);text-transform:uppercase;letter-spacing:.06em;border-bottom:1px solid var(--border);}
    .table td{padding:13px 16px;border-bottom:1px solid var(--border);vertical-align:middle;font-size:14px;}
    .table tbody tr:last-child td{border-bottom:none;}
    .table tbody tr:hover{background:#f9fafb;}
    .form-group{margin-bottom:16px;}
    .form-group:last-child{margin-bottom:0;}
    label{display:block;margin-bottom:6px;font-size:13px;font-weight:600;color:var(--text-2);}
    label i{margin-right:4px;color:var(--text-3);font-size:12px;}
    input[type="text"]{width:100%;padding:9px 13px;border:1.5px solid var(--border);border-radius:var(--radius-sm);font-size:14px;font-family:'Plus Jakarta Sans',sans-serif;color:var(--text);background:#fff;transition:border-color .18s,box-shadow .18s;outline:none;}
    input[type="text"]:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(79,110,247,.12);}
    textarea{width:100%;padding:10px 13px;border:1.5px solid var(--border);border-radius:0 0 var(--radius-sm) var(--radius-sm);font-size:13px;font-family:'Courier New',monospace;color:var(--text);background:#fff;outline:none;resize:vertical;min-height:400px;line-height:1.6;transition:border-color .18s,box-shadow .18s;}
    textarea:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(79,110,247,.12);}
    .editor-toolbar{display:flex;gap:6px;flex-wrap:wrap;padding:10px 14px;background:var(--bg);border:1.5px solid var(--border);border-bottom:none;border-radius:var(--radius-sm) var(--radius-sm) 0 0;}
    .editor-btn{padding:5px 11px;background:var(--surface);border:1.5px solid var(--border);border-radius:6px;cursor:pointer;font-size:12px;font-family:'Plus Jakarta Sans',sans-serif;color:var(--text-2);transition:all .15s;}
    .editor-btn:hover{background:var(--accent-bg);border-color:var(--accent);color:var(--accent);}
    .char-count{font-size:12px;color:var(--text-3);margin-top:6px;text-align:right;}
    hr.divider{border:none;border-top:1px solid var(--border);margin:20px 0;}
    .badge{display:inline-flex;align-items:center;padding:3px 9px;border-radius:20px;font-size:11.5px;font-weight:600;}
    .badge-info{background:var(--accent-bg);color:var(--accent);}
    .hint{font-size:11.5px;color:var(--text-3);margin-top:5px;}
    .empty-state{text-align:center;padding:48px 20px;}
    .empty-state i{font-size:36px;color:var(--text-3);margin-bottom:12px;display:block;}
    .empty-state p{color:var(--text-3);font-size:14px;}
    .two-col{display:grid;grid-template-columns:1fr 1fr;gap:16px;}
    @media(max-width:768px){
      .sidebar{transform:translateX(-100%);}
      .sidebar.open{transform:translateX(0);box-shadow:var(--shadow-md);}
      .sidebar-overlay.open{display:block;}
      .topbar{left:0;}
      .topbar-hamburger{display:flex;}
      .main{margin-left:0;padding:20px 16px 60px;}
      .card-body{padding:16px;}
      .card-header{padding:14px 16px;}
      .two-col{grid-template-columns:1fr;}
    }
  </style>
</head>
<body>

<div class="sidebar-overlay" id="overlay" onclick="closeSidebar()"></div>

<aside class="sidebar" id="sidebar">
  <a href="admin_index.php" class="sidebar-logo">
    <div class="sidebar-logo-icon"><i class="fas fa-shield-halved"></i></div>
    <span class="sidebar-logo-text">KOAK Admin</span>
  </a>
  <nav class="sidebar-nav">
    <div class="nav-label">Genel</div>
    <a href="admin_index.php" class="nav-item"><i class="fas fa-gauge-high"></i> Dashboard</a>
    <div class="nav-label">İçerik</div>
    <a href="pages.php" class="nav-item active"><i class="fas fa-file-lines"></i> Sayfalar</a>
    <a href="news.php" class="nav-item"><i class="fas fa-bullhorn"></i> Duyurular</a>
    <a href="categories.php" class="nav-item"><i class="fas fa-tags"></i> Kategoriler</a>
    <a href="gallery.php" class="nav-item"><i class="fas fa-images"></i> Galeri</a>
    <a href="sliders.php" class="nav-item"><i class="fas fa-layer-group"></i> Sliderlar</a>
    <div class="nav-label">Ayarlar</div>
    <a href="admin_index.php#settings" class="nav-item"><i class="fas fa-gear"></i> Site Ayarları</a>
  </nav>
  <div class="sidebar-footer">
    <div class="sidebar-user" onclick="logout()">
      <div class="user-avatar"><?php echo $admin_initials; ?></div>
      <div class="user-info">
        <div class="user-name"><?php echo $admin_name; ?></div>
        <div class="user-role">Yönetici</div>
      </div>
      <i class="fas fa-arrow-right-from-bracket logout-icon"></i>
    </div>
  </div>
</aside>

<header class="topbar">
  <button class="topbar-hamburger" onclick="openSidebar()"><i class="fas fa-bars"></i></button>
  <div class="topbar-title">
    <?php if ($action==='add') echo 'Yeni Sayfa';
    elseif ($action==='edit') echo 'Sayfayı Düzenle';
    else echo 'Sayfa Yönetimi'; ?>
  </div>
  <div class="topbar-right"><span class="topbar-date" id="topbar-date"></span></div>
</header>

<main class="main">

<?php if ($success): ?>
<div class="alert alert-success"><i class="fas fa-circle-check"></i><span><?php echo $success; ?></span></div>
<?php endif; ?>
<?php if ($error): ?>
<div class="alert alert-error"><i class="fas fa-circle-exclamation"></i><span><?php echo $error; ?></span></div>
<?php endif; ?>
<?php if (isset($_GET['msg']) && $_GET['msg']==='deleted'): ?>
<div class="alert alert-success"><i class="fas fa-circle-check"></i><span>Sayfa silindi.</span></div>
<?php endif; ?>

<?php if ($action === 'list'): ?>

  <div class="page-header">
    <div>
      <h1>Sayfa Yönetimi</h1>
      <p><?php echo count($all_pages); ?> sayfa kayıtlı</p>
    </div>
    <a href="?action=add" class="btn btn-primary"><i class="fas fa-plus"></i> Yeni Sayfa</a>
  </div>

  <div class="card">
    <div class="card-body" style="padding:0;">
      <div class="table-wrap">
        <table class="table">
          <thead>
            <tr>
              <th>#</th>
              <th>Slug</th>
              <th>Başlık</th>
              <th>Son Güncelleme</th>
              <th style="text-align:right;">İşlem</th>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($all_pages)): ?>
            <tr><td colspan="5">
              <div class="empty-state">
                <i class="fas fa-file-lines"></i>
                <p>Henüz sayfa eklenmemiş. Yeni sayfa eklemek için butona tıklayın.</p>
              </div>
            </td></tr>
            <?php else: foreach ($all_pages as $pg): ?>
            <tr>
              <td style="color:var(--text-3);font-size:13px;"><?php echo $pg['id']; ?></td>
              <td><span class="badge badge-info"><?php echo e($pg['slug']); ?></span></td>
              <td style="font-weight:600;"><?php echo e($pg['title']); ?></td>
              <td style="color:var(--text-3);font-size:13px;">
                <?php echo !empty($pg['updated_at']) ? date('d.m.Y H:i', strtotime($pg['updated_at'])) : '—'; ?>
              </td>
              <td style="text-align:right;">
                <div style="display:flex;gap:6px;justify-content:flex-end;">
                  <a href="?action=edit&id=<?php echo $pg['id']; ?>" class="btn btn-icon" style="background:var(--accent-bg);color:var(--accent);" title="Düzenle">
                    <i class="fas fa-pen"></i>
                  </a>
                  <button onclick="confirmDelete(<?php echo $pg['id']; ?>, '<?php echo addslashes(e($pg['title'])); ?>')" class="btn btn-icon btn-danger" title="Sil">
                    <i class="fas fa-trash"></i>
                  </button>
                </div>
              </td>
            </tr>
            <?php endforeach; endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

<?php elseif ($action === 'add'): ?>

  <div class="page-header">
    <div style="display:flex;align-items:center;gap:12px;">
      <a href="pages.php" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left"></i> Geri</a>
      <div><h1>Yeni Sayfa Ekle</h1></div>
    </div>
  </div>

  <div class="card">
    <div class="card-header">
      <div class="card-header-icon"><i class="fas fa-plus"></i></div>
      <div><h2>Sayfa Bilgileri</h2><p>Yeni sayfa oluşturun</p></div>
    </div>
    <div class="card-body">
      <form method="POST">
        <input type="hidden" name="action" value="add_page">
        <div class="two-col">
          <div class="form-group">
            <label><i class="fas fa-code"></i> Sayfa Adı (Slug)</label>
            <input type="text" name="slug" required placeholder="biz-kimiz">
            <div class="hint">Sadece küçük harf, rakam ve tire. Örn: biz-kimiz, iletisim</div>
          </div>
          <div class="form-group">
            <label><i class="fas fa-heading"></i> Sayfa Başlığı</label>
            <input type="text" name="title" required placeholder="Biz Kimiz?">
          </div>
        </div>
        <div class="form-group">
          <label><i class="fas fa-code"></i> İçerik (HTML)</label>
          <div class="editor-toolbar" id="tb-add">
            <button type="button" class="editor-btn" onclick="ins('add','&lt;h2&gt;','&lt;/h2&gt;')"><b>H2</b></button>
            <button type="button" class="editor-btn" onclick="ins('add','&lt;h3&gt;','&lt;/h3&gt;')"><b>H3</b></button>
            <button type="button" class="editor-btn" onclick="ins('add','&lt;p&gt;','&lt;/p&gt;')">P</button>
            <button type="button" class="editor-btn" onclick="ins('add','&lt;strong&gt;','&lt;/strong&gt;')"><b>B</b></button>
            <button type="button" class="editor-btn" onclick="ins('add','&lt;em&gt;','&lt;/em&gt;')"><em>I</em></button>
            <button type="button" class="editor-btn" onclick="ins('add','&lt;a href=&quot;#&quot;&gt;','&lt;/a&gt;')"><i class="fas fa-link"></i></button>
            <button type="button" class="editor-btn" onclick="ins('add','&lt;ul&gt;\n  &lt;li&gt;','&lt;/li&gt;\n&lt;/ul&gt;')"><i class="fas fa-list-ul"></i></button>
            <button type="button" class="editor-btn" onclick="ins('add','&lt;img src=&quot;&quot; alt=&quot;&quot;&gt;')"><i class="fas fa-image"></i></button>
            <button type="button" class="editor-btn" onclick="ins('add','&lt;br&gt;')">BR</button>
          </div>
          <textarea name="content" id="ta-add" placeholder="HTML içeriğini buraya girin..."></textarea>
          <div class="char-count">Karakter: <span id="cnt-add">0</span></div>
        </div>
        <hr class="divider">
        <div style="display:flex;gap:10px;">
          <button type="submit" class="btn btn-primary"><i class="fas fa-floppy-disk"></i> Kaydet</button>
          <a href="pages.php" class="btn btn-secondary"><i class="fas fa-xmark"></i> İptal</a>
        </div>
      </form>
    </div>
  </div>

<?php elseif ($action === 'edit' && $edit_page): ?>

  <div class="page-header">
    <div style="display:flex;align-items:center;gap:12px;">
      <a href="pages.php" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left"></i> Geri</a>
      <div>
        <h1>Sayfayı Düzenle</h1>
        <p><span class="badge badge-info"><?php echo e($edit_page['slug']); ?></span></p>
      </div>
    </div>
    <button onclick="confirmDelete(<?php echo $edit_page['id']; ?>,'<?php echo addslashes(e($edit_page['title'])); ?>')" class="btn btn-danger btn-sm">
      <i class="fas fa-trash"></i> Sayfayı Sil
    </button>
  </div>

  <div class="card">
    <div class="card-header">
      <div class="card-header-icon"><i class="fas fa-pen-to-square"></i></div>
      <div><h2><?php echo e($edit_page['title']); ?></h2><p>HTML içerik düzenleyici</p></div>
    </div>
    <div class="card-body">
      <form method="POST">
        <input type="hidden" name="action" value="update_page">
        <input type="hidden" name="id" value="<?php echo $edit_page['id']; ?>">
        <div class="two-col">
          <div class="form-group">
            <label><i class="fas fa-code"></i> Sayfa Adı (Slug)</label>
            <input type="text" name="slug" required value="<?php echo e($edit_page['slug']); ?>">
          </div>
          <div class="form-group">
            <label><i class="fas fa-heading"></i> Sayfa Başlığı</label>
            <input type="text" name="title" required value="<?php echo e($edit_page['title']); ?>">
          </div>
        </div>
        <div class="form-group">
          <label><i class="fas fa-code"></i> İçerik (HTML)</label>
          <div class="editor-toolbar">
            <button type="button" class="editor-btn" onclick="ins('edit','&lt;h2&gt;','&lt;/h2&gt;')"><b>H2</b></button>
            <button type="button" class="editor-btn" onclick="ins('edit','&lt;h3&gt;','&lt;/h3&gt;')"><b>H3</b></button>
            <button type="button" class="editor-btn" onclick="ins('edit','&lt;p&gt;','&lt;/p&gt;')">P</button>
            <button type="button" class="editor-btn" onclick="ins('edit','&lt;strong&gt;','&lt;/strong&gt;')"><b>B</b></button>
            <button type="button" class="editor-btn" onclick="ins('edit','&lt;em&gt;','&lt;/em&gt;')"><em>I</em></button>
            <button type="button" class="editor-btn" onclick="ins('edit','&lt;a href=&quot;#&quot;&gt;','&lt;/a&gt;')"><i class="fas fa-link"></i></button>
            <button type="button" class="editor-btn" onclick="ins('edit','&lt;ul&gt;\n  &lt;li&gt;','&lt;/li&gt;\n&lt;/ul&gt;')"><i class="fas fa-list-ul"></i></button>
            <button type="button" class="editor-btn" onclick="ins('edit','&lt;img src=&quot;&quot; alt=&quot;&quot;&gt;')"><i class="fas fa-image"></i></button>
            <button type="button" class="editor-btn" onclick="ins('edit','&lt;br&gt;')">BR</button>
          </div>
          <textarea name="content" id="ta-edit"><?php echo e($edit_page['content']); ?></textarea>
          <div class="char-count">Karakter: <span id="cnt-edit">0</span></div>
        </div>
        <hr class="divider">
        <div style="display:flex;gap:10px;">
          <button type="submit" class="btn btn-primary"><i class="fas fa-floppy-disk"></i> Güncelle</button>
          <a href="pages.php" class="btn btn-secondary"><i class="fas fa-xmark"></i> İptal</a>
        </div>
      </form>
    </div>
  </div>

<?php endif; ?>
</main>

<script>
function openSidebar(){document.getElementById('sidebar').classList.add('open');document.getElementById('overlay').classList.add('open');document.body.style.overflow='hidden';}
function closeSidebar(){document.getElementById('sidebar').classList.remove('open');document.getElementById('overlay').classList.remove('open');document.body.style.overflow='';}
function logout(){Swal.fire({title:'Çıkış yapılsın mı?',text:'Oturumunuz kapatılacak.',icon:'question',showCancelButton:true,confirmButtonColor:'#4f6ef7',cancelButtonColor:'#9aa3b2',confirmButtonText:'Evet, çıkış yap',cancelButtonText:'İptal'}).then(function(result){if(result.isConfirmed){window.location.href='logout.php';}});}

function ins(which, open, close) {
  var taId = which === 'add' ? 'ta-add' : 'ta-edit';
  var cntId = which === 'add' ? 'cnt-add' : 'cnt-edit';
  var ta = document.getElementById(taId);
  if (!ta) return;
  var s = ta.selectionStart, e = ta.selectionEnd;
  var decoded_open  = open.replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"');
  var decoded_close = close ? close.replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"') : '';
  ta.value = ta.value.substring(0,s) + decoded_open + ta.value.substring(s,e) + decoded_close + ta.value.substring(e);
  ta.focus();
  var cnt = document.getElementById(cntId);
  if (cnt) cnt.textContent = ta.value.length;
}

['ta-add','ta-edit'].forEach(function(id){
  var ta = document.getElementById(id);
  if (!ta) return;
  var cntId = id === 'ta-add' ? 'cnt-add' : 'cnt-edit';
  ta.addEventListener('input', function(){ document.getElementById(cntId).textContent = ta.value.length; });
  document.getElementById(cntId).textContent = ta.value.length;
});

function confirmDelete(id, title) {
  Swal.fire({
    title:'Sayfayı Sil',
    html:'<b>' + title + '</b> kalıcı olarak silinecek.',
    icon:'warning',
    showCancelButton:true,
    confirmButtonColor:'#f43f5e',
    cancelButtonColor:'#9aa3b2',
    confirmButtonText:'Evet, Sil',
    cancelButtonText:'İptal'
  }).then(function(r){
    if(r.isConfirmed){
      Swal.fire({title:'Siliniyor...',showConfirmButton:false,didOpen:function(){Swal.showLoading();}});
      window.location.href='pages.php?action=delete&id='+id;
    }
  });
}

(function(){
  var el = document.getElementById('topbar-date');
  if(el) el.textContent = new Date().toLocaleDateString('tr-TR',{weekday:'short',day:'numeric',month:'long',year:'numeric'});
})();
</script>
</body>
</html>