<?php
$config_path = __DIR__ . '/admin/config.php';

if (!file_exists($config_path)) {
    die("<div style='font-family:sans-serif; text-align:center; margin-top:100px; padding:20px; border:1px solid #e5e7eb; border-radius:8px; color:#4b5563;'><b>Sistem Hatası:</b> admin/config.php bulunamadı.</div>");
}

require_once $config_path;

$settings = [
    'site_title' => 'KOAK | Arama Kurtarma Derneği',
    'logo' => '',
    'phone' => '+90 537 608 85 01',
    'email' => 'bilgi@koak.org.tr',
    'address' => 'Örnek Mah. Kurtuluş Cad. No:123 Merkez/Türkiye',
    'facebook' => '#', 'twitter' => '#', 'instagram' => '#', 'youtube' => '#'
];

try {
    $st = $db->query("SELECT setting_key, setting_value FROM settings");
    if($st) {
        while($row = $st->fetch()) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }
    }
} catch(Exception $e) {}

$slug = 'biz-kimiz';
try {
    $st = $db->prepare("SELECT * FROM pages WHERE slug = ?");
    $st->execute([$slug]);
    $pageData = $st->fetch();
} catch(Exception $e) {
    $pageData = false;
}

if(!$pageData) {
    $pageData = [
        'title' => 'Biz Kimiz?',
        'content' => '<div style="text-align:center; color:#64748b; padding:40px 0;">Bu sayfanın içeriği henüz admin panelinden eklenmemiştir.</div>'
    ];
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo e($pageData['title']); ?> | <?php echo e($settings['site_title']); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        :root {
            --primary: #c21e1e;
            --primary-dark: #9b1818;
            --dark: #0f172a;
            --darker: #020617;
            --light: #f8fafc;
            --gray: #64748b;
            --border: #e2e8f0;
            --shadow-sm: 0 2px 4px -1px rgb(0 0 0 / 0.05);
            --shadow-md: 0 10px 25px -5px rgb(0 0 0 / 0.1);
            --transition: all 0.3s ease;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; -webkit-tap-highlight-color: transparent; }
        body { background-color: var(--light); color: var(--dark); line-height: 1.6; overflow-x: hidden; font-size: 15px; }
        a { text-decoration: none; color: inherit; }
        ul { list-style: none; }
        img { max-width: 100%; height: auto; display: block; border-radius: 12px; }
        
        .container { width: 100%; max-width: 1200px; margin: 0 auto; padding: 0 20px; }
        
        .top-bar { background-color: var(--darker); color: #cbd5e1; font-size: 12px; padding: 6px 0; font-weight: 500; z-index: 1001; position: relative; }
        .top-bar .container { display: flex; justify-content: flex-end; align-items: center; }
        .top-bar-links { display: flex; gap: 14px; }
        .top-bar-links a { transition: var(--transition); }
        .top-bar-links a:hover { color: var(--primary); transform: translateY(-2px); }

        .navbar { position: sticky; top: 0; z-index: 1000; transition: var(--transition); background: rgba(255, 255, 255, 0.98); border-bottom: 1px solid rgba(226, 232, 240, 0.8); padding: 15px 0; box-shadow: var(--shadow-sm); }
        .navbar .container { display: flex; justify-content: space-between; align-items: center; }
        
        .logo { display: flex; align-items: center; font-size: 22px; font-weight: 800; color: var(--darker); letter-spacing: -0.5px; border-radius: 0; }
        .logo img { height: 60px; width: auto; object-fit: contain; border-radius: 0; }
        .logo i { color: var(--primary); font-size: 28px; margin-right: 8px; }
        
        .nav-links { display: flex; gap: 30px; align-items: center; font-weight: 600; font-size: 15px; }
        .nav-links > a, .dropdown-trigger { position: relative; color: #1e293b; transition: var(--transition); padding: 10px 0; cursor: pointer; display: flex; align-items: center; gap: 5px; }
        .nav-links > a:hover, .dropdown-trigger:hover { color: var(--primary); }
        
        .dropdown { position: relative; }
        .dropdown-menu { position: absolute; top: 100%; left: 0; min-width: 220px; background: #fff; box-shadow: var(--shadow-md); border-radius: 8px; padding: 10px 0; opacity: 0; visibility: hidden; transform: translateY(15px); transition: all 0.3s ease; border: 1px solid var(--border); }
        .dropdown:hover .dropdown-menu { opacity: 1; visibility: visible; transform: translateY(0); }
        .dropdown-menu a { display: block; padding: 10px 24px; font-size: 14px; font-weight: 600; color: var(--dark); transition: var(--transition); }
        .dropdown-menu a i { width: 20px; color: var(--primary); opacity: 0.7; transition: var(--transition); }
        .dropdown-menu a:hover { background: var(--light); color: var(--primary); padding-left: 30px; }
        .dropdown-menu a:hover i { opacity: 1; transform: translateX(2px); }

        .header-contact { display: flex; align-items: center; gap: 15px; border-left: 1px solid var(--border); padding-left: 30px; margin-left: 10px; }
        .header-contact .icon-box { background: var(--primary); color: #fff; width: 48px; height: 48px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 22px; transition: var(--transition); }
        .header-contact:hover .icon-box { background: var(--primary-dark); transform: scale(1.05); }
        .header-contact .text-box { display: flex; flex-direction: column; }
        .header-contact .title { font-size: 13px; color: var(--dark); font-weight: 500; line-height: 1.2; margin-bottom: 4px; }
        .header-contact .phone { font-size: 20px; font-weight: 900; color: #0f172a; line-height: 1; letter-spacing: -0.5px; }

        .mobile-btn { display: none; font-size: 20px; color: var(--dark); cursor: pointer; z-index: 1002; width: 24px; height: 18px; position: relative; }
        .mobile-btn span { display: block; position: absolute; height: 2px; width: 100%; background: var(--dark); border-radius: 2px; opacity: 1; left: 0; transform: rotate(0deg); transition: .25s ease-in-out; }
        .mobile-btn span:nth-child(1) { top: 0px; }
        .mobile-btn span:nth-child(2) { top: 8px; }
        .mobile-btn span:nth-child(3) { top: 16px; }
        .mobile-btn.active span:nth-child(1) { top: 8px; transform: rotate(135deg); }
        .mobile-btn.active span:nth-child(2) { opacity: 0; left: -60px; }
        .mobile-btn.active span:nth-child(3) { top: 8px; transform: rotate(-135deg); }

        .mobile-menu { position: fixed; top: 0; left: 0; width: 100%; height: 100vh; background: rgba(255, 255, 255, 0.98); backdrop-filter: blur(20px); z-index: 999; display: flex; flex-direction: column; justify-content: center; padding: 0 10%; opacity: 0; visibility: hidden; transition: var(--transition); transform: translateY(-10px); overflow-y: auto; }
        .mobile-menu.active { opacity: 1; visibility: visible; transform: translateY(0); }
        .mobile-link { font-size: 20px; font-weight: 700; color: var(--dark); padding: 15px 0; border-bottom: 1px solid var(--border); transition: var(--transition); display: block; }
        .mobile-link:hover { color: var(--primary); }
        .mobile-dropdown-btn { display: flex; justify-content: space-between; align-items: center; width: 100%; font-size: 20px; font-weight: 700; color: var(--dark); padding: 15px 0; border-bottom: 1px solid var(--border); cursor: pointer; }
        .mobile-dropdown-content { display: none; flex-direction: column; padding: 10px 0 10px 20px; background: var(--light); border-bottom: 1px solid var(--border); }
        .mobile-dropdown-content.active { display: flex; }
        .mobile-dropdown-content a { padding: 12px 0; font-size: 15px; font-weight: 600; color: var(--gray); transition: var(--transition); display: flex; align-items: center; gap: 10px; }
        .mobile-dropdown-content a i { color: var(--primary); font-size: 14px; }
        .mobile-dropdown-content a:hover { color: var(--primary); padding-left: 10px; }

        .page-banner { background: linear-gradient(rgba(2,6,23,0.85), rgba(2,6,23,0.95)), url('https://images.unsplash.com/photo-1531206715517-5c0ba140b2b8?auto=format&fit=crop&q=80&w=1920') center/cover; padding: 100px 0 80px; text-align: center; color: #fff; }
        .page-banner h1 { font-size: clamp(32px, 4vw, 48px); font-weight: 900; margin-bottom: 15px; letter-spacing: -1px; }
        .page-breadcrumb { font-size: 14px; color: #cbd5e1; font-weight: 500; display: flex; justify-content: center; align-items: center; gap: 10px; }
        .page-breadcrumb a { color: var(--primary); transition: var(--transition); }
        .page-breadcrumb a:hover { color: #fff; }

        .page-content-wrap { padding: 80px 0; background: var(--light); }
        .page-card { background: #fff; border-radius: 24px; padding: 60px; box-shadow: var(--shadow-sm); border: 1px solid rgba(226, 232, 240, 0.8); line-height: 1.8; color: var(--gray); }
        .page-card h2, .page-card h3, .page-card h4 { color: var(--dark); margin: 40px 0 20px; font-weight: 800; letter-spacing: -0.5px; }
        .page-card h2:first-child { margin-top: 0; }
        .page-card p { margin-bottom: 24px; }
        .page-card ul, .page-card ol { margin-bottom: 24px; padding-left: 20px; }
        .page-card li { margin-bottom: 10px; }

        .footer { background-color: var(--darker); color: #94a3b8; padding: 60px 0 20px; border-top: 1px solid rgba(255,255,255,0.05); }
        .footer-grid { display: grid; grid-template-columns: 2fr 1fr 1fr 1.5fr; gap: 40px; margin-bottom: 40px; }
        .footer-about .logo { color: #fff; margin-bottom: 16px; font-size: 24px; display:flex; align-items:center; gap:10px; }
        .footer-about .logo img { height: 40px; border-radius: 0; }
        .social-links { display: flex; gap: 12px; margin-top: 20px; }
        .social-links a { width: 36px; height: 36px; border-radius: 50%; background: rgba(255,255,255,0.05); display: flex; align-items: center; justify-content: center; color: #fff; transition: var(--transition); font-size: 14px; }
        .social-links a:hover { background: var(--primary); transform: translateY(-2px); }
        .footer-title { color: #fff; font-size: 14px; font-weight: 600; margin-bottom: 20px; position: relative; padding-bottom: 8px; display: inline-block; letter-spacing: 0.5px; text-transform: uppercase; }
        .footer-title::after { content: ''; position: absolute; bottom: 0; left: 0; width: 24px; height: 2px; background: var(--primary); }
        .footer-links li { margin-bottom: 10px; }
        .footer-links a { font-size: 13px; transition: var(--transition); }
        .footer-links a:hover { color: #fff; transform: translateX(4px); display: inline-block; }
        .footer-contact li { display: flex; align-items: flex-start; gap: 12px; margin-bottom: 16px; font-size: 13px; }
        .footer-contact i { color: var(--primary); font-size: 15px; margin-top: 2px; }
        .footer-bottom { text-align: center; padding-top: 20px; border-top: 1px solid rgba(255,255,255,0.05); font-size: 12px; }

        @media (max-width: 1024px) {
            .footer-grid { grid-template-columns: repeat(2, 1fr); }
            .page-card { padding: 40px 30px; }
            .header-contact { display: none; }
        }
        @media (max-width: 768px) {
            .top-bar { display: none; }
            .nav-links, .header-contact { display: none; }
            .mobile-btn { display: block; }
            .footer-grid { grid-template-columns: 1fr; }
            .page-card { padding: 30px 20px; }
            .page-banner { padding: 80px 0 50px; }
            .logo img { height: 45px; }
        }
    </style>
</head>
<body>

    <div class="top-bar">
        <div class="container">
            <div class="top-bar-links">
                <a href="<?php echo e($settings['facebook']); ?>"><i class="fab fa-facebook-f"></i></a>
                <a href="<?php echo e($settings['twitter']); ?>"><i class="fab fa-twitter"></i></a>
                <a href="<?php echo e($settings['instagram']); ?>"><i class="fab fa-instagram"></i></a>
                <a href="<?php echo e($settings['youtube']); ?>"><i class="fab fa-youtube"></i></a>
            </div>
        </div>
    </div>

    <nav class="navbar" id="navbar">
        <div class="container">
            <a href="index.php" class="logo">
                <?php if(!empty($settings['logo'])): ?>
                    <img src="admin/<?php echo e($settings['logo']); ?>" alt="KOAK Logo">
                <?php else: ?>
                    <i class="fas fa-hands-helping"></i> KOAK
                <?php endif; ?>
            </a>
            
            <div class="nav-links">
                <a href="index.php">Anasayfa</a>
                
                <div class="dropdown">
                    <div class="dropdown-trigger" style="color: var(--primary);">
                        Hakkımızda <i class="fas fa-chevron-down" style="font-size: 10px; margin-left: 2px;"></i>
                    </div>
                    <div class="dropdown-menu">
                        <a href="biz-kimiz.php" style="color: var(--primary);"><i class="fas fa-info-circle"></i> Biz Kimiz?</a>
                        <a href="yonetim.php"><i class="fas fa-users"></i> Yönetim Kurulu</a>
                        <a href="galeri.php"><i class="fas fa-images"></i> Galerimiz</a>
                        <a href="belgeler.php"><i class="fas fa-file-alt"></i> Belgelerimiz</a>
                    </div>
                </div>
                
                <a href="faaliyetler.php">Eğitimlerimiz</a>
                <a href="iletisim.php">İletişim</a>
                <a href="destek.php">Bize Katıl !</a>
            </div>
            
            <div class="header-contact desktop">
                <div class="icon-box"><i class="fas fa-phone-volume"></i></div>
                <div class="text-box">
                    <span class="title">Bizi Arayın 7/24</span>
                    <span class="phone"><?php echo e($settings['phone']); ?></span>
                </div>
            </div>
            
            <div class="mobile-btn" id="mobileBtn">
                <span></span><span></span><span></span>
            </div>
        </div>
    </nav>

    <div class="mobile-menu" id="mobileMenu">
        <div style="margin-top: 60px; width: 100%;">
            <a href="index.php" class="mobile-link">Anasayfa</a>
            
            <div class="mobile-dropdown-btn" onclick="document.getElementById('mobDropdown').classList.toggle('active')" style="color: var(--primary);">
                Hakkımızda <i class="fas fa-chevron-down"></i>
            </div>
            <div class="mobile-dropdown-content" id="mobDropdown" style="display: flex;">
                <a href="biz-kimiz.php" style="color: var(--primary);"><i class="fas fa-info-circle"></i> Biz Kimiz?</a>
                <a href="yonetim.php"><i class="fas fa-users"></i> Yönetim Kurulu</a>
                <a href="galeri.php"><i class="fas fa-images"></i> Galerimiz</a>
                <a href="belgeler.php"><i class="fas fa-file-alt"></i> Belgelerimiz</a>
            </div>
            
            <a href="faaliyetler.php" class="mobile-link">Eğitimlerimiz</a>
            <a href="iletisim.php" class="mobile-link">İletişim</a>
            <a href="destek.php" class="mobile-link">Bize Katıl !</a>
            
            <div style="margin-top: 30px; text-align: center;">
                <span style="font-size: 14px; color: var(--gray); display: block;">Bizi Arayın 7/24</span>
                <span style="font-size: 24px; font-weight: 900; color: var(--primary);"><?php echo e($settings['phone']); ?></span>
            </div>
        </div>
    </div>

    <div class="page-banner">
        <div class="container">
            <h1><?php echo e($pageData['title']); ?></h1>
            <div class="page-breadcrumb">
                <a href="index.php">Anasayfa</a> <i class="fas fa-chevron-right" style="font-size: 10px; opacity: 0.5;"></i> Hakkımızda <i class="fas fa-chevron-right" style="font-size: 10px; opacity: 0.5;"></i> <?php echo e($pageData['title']); ?>
            </div>
        </div>
    </div>

    <section class="page-content-wrap">
        <div class="container">
            <div class="page-card">
                <?php echo $pageData['content']; ?>
            </div>
        </div>
    </section>

    <footer class="footer">
        <div class="container">
            <div class="footer-grid">
                <div class="footer-about">
                    <div class="logo" style="color:#fff;">
                        <?php if(!empty($settings['logo'])): ?>
                            <img src="admin/<?php echo e($settings['logo']); ?>" alt="Logo" style="height:40px; margin-right:10px;">
                        <?php else: ?>
                            <i class="fas fa-hands-helping" style="color:var(--primary); margin-right:10px;"></i> 
                        <?php endif; ?>
                        KOAK
                    </div>
                    <p style="font-size: 13px; line-height: 1.7; margin-top:15px;">Gönüllü arama kurtarma ekibimizle afet durumlarında 7/24 hizmet veriyoruz.</p>
                    <div class="social-links">
                        <a href="<?php echo e($settings['facebook']); ?>"><i class="fab fa-facebook-f"></i></a>
                        <a href="<?php echo e($settings['twitter']); ?>"><i class="fab fa-twitter"></i></a>
                        <a href="<?php echo e($settings['instagram']); ?>"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
                <div>
                    <h4 class="footer-title">Kurumsal</h4>
                    <ul class="footer-links">
                        <li><a href="biz-kimiz.php">Biz Kimiz?</a></li>
                        <li><a href="yonetim.php">Yönetim Kurulu</a></li>
                        <li><a href="galeri.php">Galerimiz</a></li>
                        <li><a href="belgeler.php">Belgelerimiz</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="footer-title">Bağlantılar</h4>
                    <ul class="footer-links">
                        <li><a href="faaliyetler.php">Eğitimlerimiz</a></li>
                        <li><a href="destek.php">Bize Katıl !</a></li>
                        <li><a href="iletisim.php">İletişim</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="footer-title">İletişim Bilgileri</h4>
                    <ul class="footer-contact">
                        <li><i class="fas fa-map-marker-alt"></i> <span><?php echo e($settings['address']); ?></span></li>
                        <li><i class="fas fa-phone-alt"></i> <span><?php echo e($settings['phone']); ?></span></li>
                        <li><i class="fas fa-envelope"></i> <span><?php echo e($settings['email']); ?></span></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                &copy; <?php echo date('Y'); ?> <?php echo e($settings['site_title']); ?>. Tüm hakları saklıdır.
            </div>
        </div>
    </footer>

    <script>
        const navbar = document.getElementById('navbar');
        const mobileBtn = document.getElementById('mobileBtn');
        const mobileMenu = document.getElementById('mobileMenu');

        window.addEventListener('scroll', () => {
            if (window.scrollY > 20) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });

        mobileBtn.addEventListener('click', () => {
            mobileBtn.classList.toggle('active');
            mobileMenu.classList.toggle('active');
            document.body.style.overflow = mobileMenu.classList.contains('active') ? 'hidden' : 'auto';
        });
    </script>
</body>
</html>