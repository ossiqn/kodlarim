<?php
$config_path = __DIR__ . '/admin/config.php';

if (!file_exists($config_path)) {
    die("<div style='font-family:sans-serif; text-align:center; margin-top:100px; padding:20px; border:1px solid #e5e7eb; border-radius:8px; color:#4b5563;'><b>Sistem Hatası:</b> admin/config.php bulunamadı.</div>");
}

require_once $config_path;

$settings = [
    'site_title' => 'KOAK | Arama Kurtarma Derneği',
    'logo' => '',
    'phone' => '+90 537 608 85 01',
    'email' => 'bilgi@koak.org.tr',
    'address' => 'Örnek Mah. Kurtuluş Cad. No:123 Merkez/Türkiye',
    'facebook' => '#', 'twitter' => '#', 'instagram' => '#', 'youtube' => '#'
];

try {
    $st = $db->query("SELECT setting_key, setting_value FROM settings");
    if($st) {
        while($row = $st->fetch()) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }
    }
} catch(Exception $e) {}

$alert = '';
$alertType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = $_POST['csrf_token'] ?? '';
    if (!isset($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $csrf)) {
        $alert = 'Güvenlik doğrulaması başarısız. Lütfen sayfayı yenileyip tekrar deneyin.';
        $alertType = 'error';
    } else {
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $subject = trim($_POST['subject'] ?? '');
        $message = trim($_POST['message'] ?? '');

        if (empty($name) || empty($email) || empty($message)) {
            $alert = 'Lütfen ad, e-posta ve mesaj alanlarını doldurun.';
            $alertType = 'error';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $alert = 'Lütfen geçerli bir e-posta adresi girin.';
            $alertType = 'error';
        } else {
            try {
                $st = $db->prepare("INSERT INTO messages (name, email, phone, subject, message) VALUES (?, ?, ?, ?, ?)");
                $st->execute([$name, $email, $phone, $subject, $message]);
                $alert = 'Mesajınız başarıyla gönderildi. En kısa sürede size dönüş yapacağız.';
                $alertType = 'success';
            } catch (Exception $e) {
                $alert = 'Sistemsel bir hata oluştu, mesajınız gönderilemedi.';
                $alertType = 'error';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>İletişim | <?php echo e($settings['site_title']); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        :root {
            --primary: #c21e1e;
            --primary-dark: #9b1818;
            --dark: #0f172a;
            --darker: #020617;
            --light: #f8fafc;
            --gray: #64748b;
            --border: #e2e8f0;
            --shadow-sm: 0 2px 4px -1px rgb(0 0 0 / 0.05);
            --shadow-md: 0 10px 25px -5px rgb(0 0 0 / 0.1);
            --transition: all 0.3s ease;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; -webkit-tap-highlight-color: transparent; }
        body { background-color: var(--light); color: var(--dark); line-height: 1.6; overflow-x: hidden; font-size: 15px; }
        a { text-decoration: none; color: inherit; }
        ul { list-style: none; }
        img { max-width: 100%; height: auto; display: block; }
        
        .container { width: 100%; max-width: 1200px; margin: 0 auto; padding: 0 20px; }
        
        .top-bar { background-color: var(--darker); color: #cbd5e1; font-size: 12px; padding: 6px 0; font-weight: 500; z-index: 1001; position: relative; }
        .top-bar .container { display: flex; justify-content: flex-end; align-items: center; }
        .top-bar-links { display: flex; gap: 14px; }
        .top-bar-links a { transition: var(--transition); }
        .top-bar-links a:hover { color: var(--primary); transform: translateY(-2px); }

        .navbar { position: sticky; top: 0; z-index: 1000; transition: var(--transition); background: rgba(255, 255, 255, 0.98); border-bottom: 1px solid rgba(226, 232, 240, 0.8); padding: 15px 0; box-shadow: var(--shadow-sm); }
        .navbar .container { display: flex; justify-content: space-between; align-items: center; }
        
        .logo { display: flex; align-items: center; font-size: 22px; font-weight: 800; color: var(--darker); letter-spacing: -0.5px; border-radius: 0; }
        .logo img { height: 60px; width: auto; object-fit: contain; border-radius: 0; }
        .logo i { color: var(--primary); font-size: 28px; margin-right: 8px; }
        
        .nav-links { display: flex; gap: 30px; align-items: center; font-weight: 600; font-size: 15px; }
        .nav-links > a, .dropdown-trigger { position: relative; color: #1e293b; transition: var(--transition); padding: 10px 0; cursor: pointer; display: flex; align-items: center; gap: 5px; }
        .nav-links > a:hover, .dropdown-trigger:hover { color: var(--primary); }
        
        .dropdown { position: relative; }
        .dropdown-menu { position: absolute; top: 100%; left: 0; min-width: 220px; background: #fff; box-shadow: var(--shadow-md); border-radius: 8px; padding: 10px 0; opacity: 0; visibility: hidden; transform: translateY(15px); transition: all 0.3s ease; border: 1px solid var(--border); }
        .dropdown:hover .dropdown-menu { opacity: 1; visibility: visible; transform: translateY(0); }
        .dropdown-menu a { display: block; padding: 10px 24px; font-size: 14px; font-weight: 600; color: var(--dark); transition: var(--transition); }
        .dropdown-menu a i { width: 20px; color: var(--primary); opacity: 0.7; transition: var(--transition); }
        .dropdown-menu a:hover { background: var(--light); color: var(--primary); padding-left: 30px; }
        .dropdown-menu a:hover i { opacity: 1; transform: translateX(2px); }

        .header-contact { display: flex; align-items: center; gap: 15px; border-left: 1px solid var(--border); padding-left: 30px; margin-left: 10px; }
        .header-contact .icon-box { background: var(--primary); color: #fff; width: 48px; height: 48px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 22px; transition: var(--transition); }
        .header-contact:hover .icon-box { background: var(--primary-dark); transform: scale(1.05); }
        .header-contact .text-box { display: flex; flex-direction: column; }
        .header-contact .title { font-size: 13px; color: var(--dark); font-weight: 500; line-height: 1.2; margin-bottom: 4px; }
        .header-contact .phone { font-size: 20px; font-weight: 900; color: #0f172a; line-height: 1; letter-spacing: -0.5px; }

        .mobile-btn { display: none; font-size: 20px; color: var(--dark); cursor: pointer; z-index: 1002; width: 24px; height: 18px; position: relative; }
        .mobile-btn span { display: block; position: absolute; height: 2px; width: 100%; background: var(--dark); border-radius: 2px; opacity: 1; left: 0; transform: rotate(0deg); transition: .25s ease-in-out; }
        .mobile-btn span:nth-child(1) { top: 0px; }
        .mobile-btn span:nth-child(2) { top: 8px; }
        .mobile-btn span:nth-child(3) { top: 16px; }
        .mobile-btn.active span:nth-child(1) { top: 8px; transform: rotate(135deg); }
        .mobile-btn.active span:nth-child(2) { opacity: 0; left: -60px; }
        .mobile-btn.active span:nth-child(3) { top: 8px; transform: rotate(-135deg); }

        .mobile-menu { position: fixed; top: 0; left: 0; width: 100%; height: 100vh; background: rgba(255, 255, 255, 0.98); backdrop-filter: blur(20px); z-index: 999; display: flex; flex-direction: column; justify-content: center; padding: 0 10%; opacity: 0; visibility: hidden; transition: var(--transition); transform: translateY(-10px); overflow-y: auto; }
        .mobile-menu.active { opacity: 1; visibility: visible; transform: translateY(0); }
        .mobile-link { font-size: 20px; font-weight: 700; color: var(--dark); padding: 15px 0; border-bottom: 1px solid var(--border); transition: var(--transition); display: block; }
        .mobile-link:hover { color: var(--primary); }
        .mobile-dropdown-btn { display: flex; justify-content: space-between; align-items: center; width: 100%; font-size: 20px; font-weight: 700; color: var(--dark); padding: 15px 0; border-bottom: 1px solid var(--border); cursor: pointer; }
        .mobile-dropdown-content { display: none; flex-direction: column; padding: 10px 0 10px 20px; background: var(--light); border-bottom: 1px solid var(--border); }
        .mobile-dropdown-content.active { display: flex; }
        .mobile-dropdown-content a { padding: 12px 0; font-size: 15px; font-weight: 600; color: var(--gray); transition: var(--transition); display: flex; align-items: center; gap: 10px; }
        .mobile-dropdown-content a i { color: var(--primary); font-size: 14px; }
        .mobile-dropdown-content a:hover { color: var(--primary); padding-left: 10px; }

        .page-banner { background: linear-gradient(rgba(2,6,23,0.85), rgba(2,6,23,0.95)), url('https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&q=80&w=1920') center/cover; padding: 100px 0 80px; text-align: center; color: #fff; }
        .page-banner h1 { font-size: clamp(32px, 4vw, 48px); font-weight: 900; margin-bottom: 15px; letter-spacing: -1px; }
        .page-breadcrumb { font-size: 14px; color: #cbd5e1; font-weight: 500; display: flex; justify-content: center; align-items: center; gap: 10px; }
        .page-breadcrumb a { color: var(--primary); transition: var(--transition); }
        .page-breadcrumb a:hover { color: #fff; }

        .page-content-wrap { padding: 80px 0; background: var(--light); }
        
        .contact-grid { display: grid; grid-template-columns: 1fr 1.5fr; gap: 40px; }
        
        .contact-info-cards { display: grid; gap: 20px; }
        .info-card { background: #fff; padding: 30px; border-radius: 16px; box-shadow: var(--shadow-sm); border: 1px solid rgba(226, 232, 240, 0.8); display: flex; align-items: flex-start; gap: 20px; transition: var(--transition); }
        .info-card:hover { transform: translateY(-5px); box-shadow: var(--shadow-md); border-color: rgba(194, 30, 30, 0.3); }
        .info-icon { width: 50px; height: 50px; background: rgba(194, 30, 30, 0.1); color: var(--primary); border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 20px; flex-shrink: 0; }
        .info-text h3 { font-size: 16px; font-weight: 700; color: var(--dark); margin-bottom: 5px; }
        .info-text p { font-size: 14px; color: var(--gray); line-height: 1.5; }
        
        .map-container { margin-top: 20px; border-radius: 16px; overflow: hidden; box-shadow: var(--shadow-sm); border: 1px solid rgba(226, 232, 240, 0.8); height: 250px; }
        .map-container iframe { width: 100%; height: 100%; border: none; }

        .contact-form-box { background: #fff; padding: 40px; border-radius: 16px; box-shadow: var(--shadow-sm); border: 1px solid rgba(226, 232, 240, 0.8); }
        .contact-form-box h2 { font-size: 24px; font-weight: 800; color: var(--dark); margin-bottom: 10px; }
        .contact-form-box > p { color: var(--gray); font-size: 14px; margin-bottom: 30px; }
        
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px; }
        .form-group { margin-bottom: 20px; }
        .form-label { display: block; font-size: 13px; font-weight: 600; color: var(--dark); margin-bottom: 8px; }
        .form-control { width: 100%; padding: 14px 16px; border: 1px solid var(--border); border-radius: 8px; font-family: inherit; font-size: 14px; color: var(--dark); transition: var(--transition); background: var(--light); outline: none; }
        .form-control:focus { background: #fff; border-color: var(--primary); box-shadow: 0 0 0 3px rgba(194, 30, 30, 0.1); }
        textarea.form-control { min-height: 150px; resize: vertical; }
        
        .btn-submit { background: var(--primary); color: #fff; padding: 16px 30px; border-radius: 8px; font-weight: 700; font-size: 15px; border: none; cursor: pointer; transition: var(--transition); width: 100%; display: flex; justify-content: center; align-items: center; gap: 10px; }
        .btn-submit:hover { background: var(--primary-dark); transform: translateY(-2px); box-shadow: 0 8px 15px rgba(194, 30, 30, 0.2); }

        .alert { padding: 15px 20px; border-radius: 8px; font-size: 14px; font-weight: 600; margin-bottom: 30px; display: flex; align-items: center; gap: 10px; }
        .alert-success { background: #dcfce7; color: #166534; border: 1px solid #bbf7d0; }
        .alert-error { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }

        .footer { background-color: var(--darker); color: #94a3b8; padding: 60px 0 20px; border-top: 1px solid rgba(255,255,255,0.05); }
        .footer-grid { display: grid; grid-template-columns: 2fr 1fr 1fr 1.5fr; gap: 40px; margin-bottom: 40px; }
        .footer-about .logo { color: #fff; margin-bottom: 16px; font-size: 24px; display:flex; align-items:center; gap:10px; border-radius: 0; }
        .footer-about .logo img { height: 40px; border-radius: 0; }
        .social-links { display: flex; gap: 12px; margin-top: 20px; }
        .social-links a { width: 36px; height: 36px; border-radius: 50%; background: rgba(255,255,255,0.05); display: flex; align-items: center; justify-content: center; color: #fff; transition: var(--transition); font-size: 14px; }
        .social-links a:hover { background: var(--primary); transform: translateY(-2px); }
        .footer-title { color: #fff; font-size: 14px; font-weight: 600; margin-bottom: 20px; position: relative; padding-bottom: 8px; display: inline-block; letter-spacing: 0.5px; text-transform: uppercase; }
        .footer-title::after { content: ''; position: absolute; bottom: 0; left: 0; width: 24px; height: 2px; background: var(--primary); }
        .footer-links li { margin-bottom: 10px; }
        .footer-links a { font-size: 13px; transition: var(--transition); text-decoration: none; }
        .footer-links a:hover { color: #fff; transform: translateX(4px); display: inline-block; }
        .footer-contact li { display: flex; align-items: flex-start; gap: 12px; margin-bottom: 16px; font-size: 13px; }
        .footer-contact i { color: var(--primary); font-size: 15px; margin-top: 2px; }
        .footer-bottom { text-align: center; padding-top: 20px; border-top: 1px solid rgba(255,255,255,0.05); font-size: 12px; }

        @media (max-width: 1024px) {
            .contact-grid { grid-template-columns: 1fr; }
            .footer-grid { grid-template-columns: repeat(2, 1fr); }
            .header-contact { display: none; }
        }
        @media (max-width: 768px) {
            .top-bar { display: none; }
            .nav-links, .header-contact { display: none; }
            .mobile-btn { display: block; }
            .footer-grid { grid-template-columns: 1fr; }
            .page-banner { padding: 80px 0 50px; }
            .form-row { grid-template-columns: 1fr; gap: 0; }
            .contact-form-box { padding: 25px 20px; }
            .logo img { height: 45px; }
        }
    </style>
</head>
<body>

    <div class="top-bar">
        <div class="container">
            <div class="top-bar-links">
                <a href="<?php echo e($settings['facebook']); ?>"><i class="fab fa-facebook-f"></i></a>
                <a href="<?php echo e($settings['twitter']); ?>"><i class="fab fa-twitter"></i></a>
                <a href="<?php echo e($settings['instagram']); ?>"><i class="fab fa-instagram"></i></a>
                <a href="<?php echo e($settings['youtube']); ?>"><i class="fab fa-youtube"></i></a>
            </div>
        </div>
    </div>

    <nav class="navbar" id="navbar">
        <div class="container">
            <a href="index.php" class="logo">
                <?php if(!empty($settings['logo'])): ?>
                    <img src="admin/<?php echo e($settings['logo']); ?>" alt="KOAK Logo">
                <?php else: ?>
                    <i class="fas fa-hands-helping"></i> KOAK
                <?php endif; ?>
            </a>
            
            <div class="nav-links">
                <a href="index.php">Anasayfa</a>
                
                <div class="dropdown">
                    <div class="dropdown-trigger">
                        Hakkımızda <i class="fas fa-chevron-down" style="font-size: 10px; margin-left: 2px;"></i>
                    </div>
                    <div class="dropdown-menu">
                        <a href="biz-kimiz.php"><i class="fas fa-info-circle"></i> Biz Kimiz?</a>
                        <a href="yonetim.php"><i class="fas fa-users"></i> Yönetim Kurulu</a>
                        <a href="galeri.php"><i class="fas fa-images"></i> Galerimiz</a>
                        <a href="belgeler.php"><i class="fas fa-file-alt"></i> Belgelerimiz</a>
                    </div>
                </div>
                
                <a href="faaliyetler.php">Eğitimlerimiz</a>
                <a href="iletisim.php" style="color: var(--primary);">İletişim</a>
                <a href="destek.php">Bize Katıl !</a>
            </div>
            
            <div class="header-contact desktop">
                <div class="icon-box"><i class="fas fa-phone-volume"></i></div>
                <div class="text-box">
                    <span class="title">Bizi Arayın 7/24</span>
                    <span class="phone"><?php echo e($settings['phone']); ?></span>
                </div>
            </div>
            
            <div class="mobile-btn" id="mobileBtn">
                <span></span><span></span><span></span>
            </div>
        </div>
    </nav>

    <div class="mobile-menu" id="mobileMenu">
        <div style="margin-top: 60px; width: 100%;">
            <a href="index.php" class="mobile-link">Anasayfa</a>
            
            <div class="mobile-dropdown-btn" onclick="document.getElementById('mobDropdown').classList.toggle('active')">
                Hakkımızda <i class="fas fa-chevron-down"></i>
            </div>
            <div class="mobile-dropdown-content" id="mobDropdown">
                <a href="biz-kimiz.php"><i class="fas fa-info-circle"></i> Biz Kimiz?</a>
                <a href="yonetim.php"><i class="fas fa-users"></i> Yönetim Kurulu</a>
                <a href="galeri.php"><i class="fas fa-images"></i> Galerimiz</a>
                <a href="belgeler.php"><i class="fas fa-file-alt"></i> Belgelerimiz</a>
            </div>
            
            <a href="faaliyetler.php" class="mobile-link">Eğitimlerimiz</a>
            <a href="iletisim.php" class="mobile-link" style="color: var(--primary);">İletişim</a>
            <a href="destek.php" class="mobile-link">Bize Katıl !</a>
            
            <div style="margin-top: 30px; text-align: center;">
                <span style="font-size: 14px; color: var(--gray); display: block;">Bizi Arayın 7/24</span>
                <span style="font-size: 24px; font-weight: 900; color: var(--primary);"><?php echo e($settings['phone']); ?></span>
            </div>
        </div>
    </div>

    <div class="page-banner">
        <div class="container">
            <h1>İletişim</h1>
            <div class="page-breadcrumb">
                <a href="index.php">Anasayfa</a> <i class="fas fa-chevron-right" style="font-size: 10px; opacity: 0.5;"></i> İletişim
            </div>
        </div>
    </div>

    <section class="page-content-wrap">
        <div class="container">
            
            <div class="contact-grid">
                <div>
                    <div class="contact-info-cards">
                        <div class="info-card">
                            <div class="info-icon"><i class="fas fa-map-marker-alt"></i></div>
                            <div class="info-text">
                                <h3>Genel Merkez Adresi</h3>
                                <p><?php echo e($settings['address']); ?></p>
                            </div>
                        </div>
                        <div class="info-card">
                            <div class="info-icon"><i class="fas fa-phone-alt"></i></div>
                            <div class="info-text">
                                <h3>Acil Çağrı & İletişim</h3>
                                <p><?php echo e($settings['phone']); ?></p>
                            </div>
                        </div>
                        <div class="info-card">
                            <div class="info-icon"><i class="fas fa-envelope"></i></div>
                            <div class="info-text">
                                <h3>E-Posta Adresi</h3>
                                <p><?php echo e($settings['email']); ?></p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="map-container">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3010.87158971253!2d28.97746141541398!3d41.00645007930058!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14cab9910d540543%3A0x88981df5a18a56f2!2sSultanahmet%20Meydan%C4%B1!5e0!3m2!1str!2str!4v1645000000000!5m2!1str!2str" allowfullscreen="" loading="lazy"></iframe>
                    </div>
                </div>

                <div class="contact-form-box">
                    <h2>Bize Mesaj Gönderin</h2>
                    <p>Öneri, şikayet, ihbar veya bilgi almak istediğiniz tüm konularda aşağıdaki formu kullanarak bize ulaşabilirsiniz. Ekiplerimiz en kısa sürede dönüş yapacaktır.</p>

                    <?php if(!empty($alert)): ?>
                        <div class="alert alert-<?php echo $alertType; ?>">
                            <i class="fas <?php echo $alertType === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?>"></i>
                            <?php echo $alert; ?>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="iletisim.php">
                        <input type="hidden" name="csrf_token" value="<?php echo e($_SESSION['csrf_token']); ?>">
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Adınız Soyadınız *</label>
                                <input type="text" name="name" class="form-control" required placeholder="Örn: Ali Yılmaz">
                            </div>
                            <div class="form-group">
                                <label class="form-label">E-Posta Adresiniz *</label>
                                <input type="email" name="email" class="form-control" required placeholder="Örn: mail@adres.com">
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Telefon Numaranız</label>
                                <input type="text" name="phone" class="form-control" placeholder="Örn: 05XX XXX XX XX">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Konu</label>
                                <input type="text" name="subject" class="form-control" placeholder="Mesajınızın konusu">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Mesajınız *</label>
                            <textarea name="message" class="form-control" required placeholder="Lütfen mesajınızı detaylı bir şekilde yazın..."></textarea>
                        </div>

                        <button type="submit" class="btn-submit">
                            <i class="fas fa-paper-plane"></i> Mesajı Gönder
                        </button>
                    </form>
                </div>
            </div>

        </div>
    </section>

    <footer class="footer">
        <div class="container">
            <div class="footer-grid">
                <div class="footer-about">
                    <div class="logo" style="color:#fff;">
                        <?php if(!empty($settings['logo'])): ?>
                            <img src="admin/<?php echo e($settings['logo']); ?>" alt="Logo" style="height:40px; margin-right:10px;">
                        <?php else: ?>
                            <i class="fas fa-hands-helping" style="color:var(--primary); margin-right:10px;"></i> 
                        <?php endif; ?>
                        KOAK
                    </div>
                    <p style="font-size: 13px; line-height: 1.7; margin-top:15px;">Gönüllü arama kurtarma ekibimizle afet durumlarında 7/24 hizmet veriyoruz.</p>
                    <div class="social-links">
                        <a href="<?php echo e($settings['facebook']); ?>"><i class="fab fa-facebook-f"></i></a>
                        <a href="<?php echo e($settings['twitter']); ?>"><i class="fab fa-twitter"></i></a>
                        <a href="<?php echo e($settings['instagram']); ?>"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
                <div>
                    <h4 class="footer-title">Kurumsal</h4>
                    <ul class="footer-links">
                        <li><a href="biz-kimiz.php">Biz Kimiz?</a></li>
                        <li><a href="yonetim.php">Yönetim Kurulu</a></li>
                        <li><a href="galeri.php">Galerimiz</a></li>
                        <li><a href="belgeler.php">Belgelerimiz</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="footer-title">Bağlantılar</h4>
                    <ul class="footer-links">
                        <li><a href="faaliyetler.php">Eğitimlerimiz</a></li>
                        <li><a href="destek.php">Bize Katıl !</a></li>
                        <li><a href="iletisim.php">İletişim</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="footer-title">İletişim Bilgileri</h4>
                    <ul class="footer-contact">
                        <li><i class="fas fa-map-marker-alt"></i> <span><?php echo e($settings['address']); ?></span></li>
                        <li><i class="fas fa-phone-alt"></i> <span><?php echo e($settings['phone']); ?></span></li>
                        <li><i class="fas fa-envelope"></i> <span><?php echo e($settings['email']); ?></span></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                &copy; <?php echo date('Y'); ?> <?php echo e($settings['site_title']); ?>. Tüm hakları saklıdır.
            </div>
        </div>
    </footer>

    <script>
        const navbar = document.getElementById('navbar');
        const mobileBtn = document.getElementById('mobileBtn');
        const mobileMenu = document.getElementById('mobileMenu');

        window.addEventListener('scroll', () => {
            if (window.scrollY > 20) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });

        mobileBtn.addEventListener('click', () => {
            mobileBtn.classList.toggle('active');
            mobileMenu.classList.toggle('active');
            document.body.style.overflow = mobileMenu.classList.contains('active') ? 'hidden' : 'auto';
        });
    </script>
</body>
</html>