<?php
$config_path = __DIR__ . '/admin/config.php';

if (!file_exists($config_path)) {
    die("<div style='font-family:sans-serif; text-align:center; margin-top:100px; padding:20px; border:1px solid #e5e7eb; border-radius:8px; color:#4b5563;'><b>Sistem Hatası:</b> admin/config.php bulunamadı.</div>");
}

require_once $config_path;

$settings = [
    'site_title' => 'KOAK | Arama Kurtarma Derneği',
    'logo' => '',
    'phone' => '+90 537 608 85 01',
    'email' => 'bilgi@koak.org.tr',
    'address' => 'Örnek Mah. Kurtuluş Cad. No:123 Merkez/Türkiye',
    'facebook' => '#', 'twitter' => '#', 'instagram' => '#', 'youtube' => '#',
    'hero_title' => 'HAYAT KURTARMAK İÇİN BURADAYIZ',
    'hero_desc' => 'Gönüllü ekibimizle afetlerde ve acil durumlarda din, dil, ırk ayrımı gözetmeksizin profesyonel arama kurtarma hizmeti veriyoruz.',
    'about_title' => 'Biz Kimiz?',
    'about_desc' => 'Doğal afetlerde ve acil durumlarda yardıma ihtiyacı olan her canlının yanında olmak için kurulmuş, tamamen gönüllülük esasına dayalı bir arama kurtarma derneğiyiz. Düzenli eğitimlerimiz ve donanımlı ekibimizle her an göreve hazırız.',
    'stat1_num' => '450', 'stat1_text' => 'Aktif Gönüllü',
    'stat2_num' => '120', 'stat2_text' => 'Operasyon',
    'stat3_num' => '3000', 'stat3_text' => 'Kurtarılan Can',
    'stat4_num' => '85', 'stat4_text' => 'Eğitim Semineri',
];

try {
    $st = $db->query("SELECT setting_key, setting_value FROM settings");
    if($st) {
        while($row = $st->fetch()) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }
    }
} catch(Exception $e) {}

try {
    $sliders = $db->query("SELECT * FROM sliders ORDER BY sort_order ASC")->fetchAll();
} catch(Exception $e) { $sliders = []; }

$latestActivities = getNews(['limit' => 3]);
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo e($settings['site_title']); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        :root {
            --primary: #c21e1e;
            --primary-dark: #9b1818;
            --dark: #0f172a;
            --darker: #020617;
            --light: #f8fafc;
            --gray: #64748b;
            --border: #e2e8f0;
            --shadow-sm: 0 2px 4px -1px rgb(0 0 0 / 0.05);
            --shadow-md: 0 10px 25px -5px rgb(0 0 0 / 0.1);
            --transition: all 0.3s ease;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; -webkit-tap-highlight-color: transparent; }
        body { background-color: var(--light); color: var(--dark); line-height: 1.6; overflow-x: hidden; font-size: 15px; }
        a { text-decoration: none; color: inherit; }
        ul { list-style: none; }
        img { max-width: 100%; height: auto; display: block; }
        
        .container { width: 100%; max-width: 1200px; margin: 0 auto; padding: 0 20px; }
        
        .top-bar { background-color: var(--darker); color: #cbd5e1; font-size: 12px; padding: 6px 0; font-weight: 500; z-index: 1001; position: relative; }
        .top-bar .container { display: flex; justify-content: flex-end; align-items: center; }
        .top-bar-links { display: flex; gap: 14px; }
        .top-bar-links a { transition: var(--transition); }
        .top-bar-links a:hover { color: var(--primary); transform: translateY(-2px); }

        .navbar { position: sticky; top: 0; z-index: 1000; transition: var(--transition); background: rgba(255, 255, 255, 0.98); border-bottom: 1px solid rgba(226, 232, 240, 0.8); padding: 15px 0; box-shadow: var(--shadow-sm); }
        .navbar .container { display: flex; justify-content: space-between; align-items: center; }
        
        .logo { display: flex; align-items: center; font-size: 22px; font-weight: 800; color: var(--darker); letter-spacing: -0.5px; }
        .logo img { height: 60px; width: auto; object-fit: contain; }
        .logo i { color: var(--primary); font-size: 28px; margin-right: 8px; }
        
        .nav-links { display: flex; gap: 30px; align-items: center; font-weight: 600; font-size: 15px; }
        .nav-links > a, .dropdown-trigger { position: relative; color: #1e293b; transition: var(--transition); padding: 10px 0; cursor: pointer; display: flex; align-items: center; gap: 5px; }
        .nav-links > a:hover, .dropdown-trigger:hover { color: var(--primary); }
        
        .dropdown { position: relative; }
        .dropdown-menu { position: absolute; top: 100%; left: 0; min-width: 220px; background: #fff; box-shadow: var(--shadow-md); border-radius: 8px; padding: 10px 0; opacity: 0; visibility: hidden; transform: translateY(15px); transition: all 0.3s ease; border: 1px solid var(--border); }
        .dropdown:hover .dropdown-menu { opacity: 1; visibility: visible; transform: translateY(0); }
        .dropdown-menu a { display: block; padding: 10px 24px; font-size: 14px; font-weight: 600; color: var(--dark); transition: var(--transition); }
        .dropdown-menu a i { width: 20px; color: var(--primary); opacity: 0.7; transition: var(--transition); }
        .dropdown-menu a:hover { background: var(--light); color: var(--primary); padding-left: 30px; }
        .dropdown-menu a:hover i { opacity: 1; transform: translateX(2px); }

        .header-contact { display: flex; align-items: center; gap: 15px; border-left: 1px solid var(--border); padding-left: 30px; margin-left: 10px; }
        .header-contact .icon-box { background: var(--primary); color: #fff; width: 48px; height: 48px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 22px; transition: var(--transition); }
        .header-contact:hover .icon-box { background: var(--primary-dark); transform: scale(1.05); }
        .header-contact .text-box { display: flex; flex-direction: column; }
        .header-contact .title { font-size: 13px; color: var(--dark); font-weight: 500; line-height: 1.2; margin-bottom: 4px; }
        .header-contact .phone { font-size: 20px; font-weight: 900; color: #0f172a; line-height: 1; letter-spacing: -0.5px; }

        .mobile-btn { display: none; font-size: 20px; color: var(--dark); cursor: pointer; z-index: 1002; width: 24px; height: 18px; position: relative; }
        .mobile-btn span { display: block; position: absolute; height: 2px; width: 100%; background: var(--dark); border-radius: 2px; opacity: 1; left: 0; transform: rotate(0deg); transition: .25s ease-in-out; }
        .mobile-btn span:nth-child(1) { top: 0px; }
        .mobile-btn span:nth-child(2) { top: 8px; }
        .mobile-btn span:nth-child(3) { top: 16px; }
        .mobile-btn.active span:nth-child(1) { top: 8px; transform: rotate(135deg); }
        .mobile-btn.active span:nth-child(2) { opacity: 0; left: -60px; }
        .mobile-btn.active span:nth-child(3) { top: 8px; transform: rotate(-135deg); }

        .mobile-menu { position: fixed; top: 0; left: 0; width: 100%; height: 100vh; background: rgba(255, 255, 255, 0.98); backdrop-filter: blur(20px); z-index: 999; display: flex; flex-direction: column; justify-content: center; padding: 0 10%; opacity: 0; visibility: hidden; transition: var(--transition); transform: translateY(-10px); overflow-y: auto; }
        .mobile-menu.active { opacity: 1; visibility: visible; transform: translateY(0); }
        .mobile-link { font-size: 20px; font-weight: 700; color: var(--dark); padding: 15px 0; border-bottom: 1px solid var(--border); transition: var(--transition); display: block; }
        .mobile-link:hover { color: var(--primary); }
        .mobile-dropdown-btn { display: flex; justify-content: space-between; align-items: center; width: 100%; font-size: 20px; font-weight: 700; color: var(--dark); padding: 15px 0; border-bottom: 1px solid var(--border); cursor: pointer; }
        .mobile-dropdown-content { display: none; flex-direction: column; padding: 10px 0 10px 20px; background: var(--light); border-bottom: 1px solid var(--border); }
        .mobile-dropdown-content.active { display: flex; }
        .mobile-dropdown-content a { padding: 12px 0; font-size: 15px; font-weight: 600; color: var(--gray); transition: var(--transition); display: flex; align-items: center; gap: 10px; }
        .mobile-dropdown-content a i { color: var(--primary); font-size: 14px; }
        .mobile-dropdown-content a:hover { color: var(--primary); padding-left: 10px; }

        .hero { position: relative; height: 75vh; min-height: 500px; max-height: 800px; display: flex; align-items: center; overflow: hidden; }
        .hero-slider { position: absolute; inset: 0; z-index: 1; }
        .slide { position: absolute; inset: 0; background-size: cover; background-position: center; opacity: 0; transition: opacity 1.5s ease-in-out, transform 10s ease-out; transform: scale(1.05); }
        .slide.active { opacity: 1; transform: scale(1); }
        .hero-overlay { position: absolute; inset: 0; background: linear-gradient(90deg, rgba(2,6,23,0.9) 0%, rgba(2,6,23,0.6) 50%, rgba(2,6,23,0.3) 100%); z-index: 2; }
        .hero .container { position: relative; z-index: 3; color: #fff; }
        
        .hero h1 { font-size: clamp(28px, 4vw, 46px); font-weight: 800; line-height: 1.15; margin-bottom: 16px; letter-spacing: -0.5px; }
        .hero h1 span { color: var(--primary); }
        .hero p { font-size: clamp(14px, 2vw, 16px); max-width: 550px; margin-bottom: 30px; color: #cbd5e1; font-weight: 300; }
        
        .hero-btns { display: flex; gap: 16px; flex-wrap: wrap; }
        .btn-main { padding: 12px 28px; border-radius: 50px; font-weight: 600; font-size: 14px; transition: var(--transition); display: inline-flex; align-items: center; gap: 8px; }
        .btn-main.primary { background: var(--primary); color: #fff; box-shadow: 0 8px 16px rgba(194, 30, 30, 0.2); border: 1px solid var(--primary); }
        .btn-main.primary:hover { background: transparent; color: var(--primary); box-shadow: none; }
        .btn-main.outline { border: 1px solid rgba(255,255,255,0.6); color: #fff; backdrop-filter: blur(4px); }
        .btn-main.outline:hover { background: #fff; color: var(--dark); }

        .about-section { padding: 80px 0; background: #fff; text-align: center; }
        .badge-text { display: inline-block; padding: 6px 12px; background: rgba(194, 30, 30, 0.08); color: var(--primary); font-weight: 600; border-radius: 50px; font-size: 11px; margin-bottom: 16px; text-transform: uppercase; letter-spacing: 1px; }
        .section-title { font-size: clamp(24px, 3vw, 32px); font-weight: 800; color: var(--dark); margin-bottom: 16px; letter-spacing: -0.5px; }
        .about-section p { font-size: 15px; color: var(--gray); max-width: 700px; margin: 0 auto 50px; line-height: 1.7; }

        .stats-wrap { display: grid; grid-template-columns: repeat(4, 1fr); gap: 24px; }
        .stat-card { background: #fff; padding: 30px 15px; border-radius: 16px; box-shadow: var(--shadow-md); position: relative; overflow: hidden; transition: var(--transition); z-index: 1; border: 1px solid var(--border); }
        .stat-card::before { content: ''; position: absolute; inset: 0; background: linear-gradient(135deg, rgba(194, 30, 30, 0.03), transparent); z-index: -1; opacity: 0; transition: var(--transition); }
        .stat-card:hover { transform: translateY(-5px); border-color: rgba(194, 30, 30, 0.2); }
        .stat-card:hover::before { opacity: 1; }
        .stat-icon { width: 50px; height: 50px; background: var(--primary); color: #fff; border-radius: 14px; display: flex; align-items: center; justify-content: center; font-size: 20px; margin: 0 auto 16px; transform: rotate(-3deg); transition: var(--transition); }
        .stat-card:hover .stat-icon { transform: rotate(0) scale(1.05); }
        .stat-num { font-size: 32px; font-weight: 800; color: var(--dark); line-height: 1; margin-bottom: 8px; display: flex; justify-content: center; align-items: center; }
        .stat-text { font-size: 12px; font-weight: 600; color: var(--gray); text-transform: uppercase; letter-spacing: 0.5px; }

        .activities-section { padding: 80px 0; background: var(--light); }
        .activities-header { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 40px; }
        .activities-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 24px; }
        .act-card { background: #fff; border-radius: 16px; overflow: hidden; box-shadow: var(--shadow-sm); transition: var(--transition); border: 1px solid rgba(226, 232, 240, 0.8); display: flex; flex-direction: column; }
        .act-card:hover { transform: translateY(-6px); box-shadow: var(--shadow-md); }
        .act-img-wrap { width: 100%; height: 200px; overflow: hidden; position: relative; }
        .act-img-wrap img, .act-img-wrap .placeholder-img { width: 100%; height: 100%; object-fit: cover; transition: transform 0.6s cubic-bezier(0.4, 0, 0.2, 1); }
        .act-card:hover .act-img-wrap img { transform: scale(1.05); }
        .act-overlay { position: absolute; inset: 0; background: linear-gradient(to top, rgba(15, 23, 42, 0.7), transparent); opacity: 0; transition: var(--transition); display: flex; align-items: flex-end; padding: 20px; }
        .act-card:hover .act-overlay { opacity: 1; }
        .act-cat-badge { position: absolute; top: 16px; left: 16px; background: rgba(255, 255, 255, 0.95); backdrop-filter: blur(4px); color: var(--primary); padding: 6px 12px; border-radius: 50px; font-size: 11px; font-weight: 600; box-shadow: var(--shadow-sm); z-index: 2; display: flex; align-items: center; gap: 4px; }
        .act-content { padding: 24px; flex: 1; display: flex; flex-direction: column; }
        .act-meta { display: flex; gap: 12px; font-size: 12px; font-weight: 500; color: var(--gray); margin-bottom: 12px; }
        .act-meta i { color: var(--primary); }
        .act-title { font-size: 16px; font-weight: 700; color: var(--dark); margin-bottom: 10px; line-height: 1.4; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
        .act-summary { font-size: 14px; color: var(--gray); margin-bottom: 20px; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; flex: 1; }
        .act-btn { margin-top: auto; display: inline-flex; align-items: center; gap: 6px; font-weight: 600; color: var(--dark); font-size: 13px; transition: var(--transition); }
        .act-card:hover .act-btn { color: var(--primary); }
        .act-card:hover .act-btn i { transform: translateX(4px); }

        .cta-section { position: relative; padding: 70px 0; background: linear-gradient(135deg, var(--darker), var(--dark)); color: #fff; overflow: hidden; text-align: center; }
        .cta-shape { position: absolute; width: 300px; height: 300px; background: var(--primary); border-radius: 50%; filter: blur(70px); opacity: 0.15; top: -80px; left: -80px; animation: pulse 6s ease-in-out infinite alternate; }
        .cta-shape.two { right: -80px; left: auto; top: auto; bottom: -80px; animation-delay: -3s; }
        .cta-content { position: relative; z-index: 2; max-width: 600px; margin: 0 auto; }
        .cta-content h2 { font-size: clamp(24px, 4vw, 36px); font-weight: 800; margin-bottom: 16px; letter-spacing: -0.5px; }
        .cta-content p { font-size: 15px; color: #cbd5e1; margin-bottom: 30px; font-weight: 300; }

        .footer { background-color: var(--darker); color: #94a3b8; padding: 60px 0 20px; border-top: 1px solid rgba(255,255,255,0.05); }
        .footer-grid { display: grid; grid-template-columns: 2fr 1fr 1fr 1.5fr; gap: 40px; margin-bottom: 40px; }
        .footer-about .logo { color: #fff; margin-bottom: 16px; font-size: 24px; display:flex; align-items:center; gap:10px; }
        .footer-about .logo img { height: 40px; }
        .social-links { display: flex; gap: 12px; margin-top: 20px; }
        .social-links a { width: 36px; height: 36px; border-radius: 50%; background: rgba(255,255,255,0.05); display: flex; align-items: center; justify-content: center; color: #fff; transition: var(--transition); font-size: 14px; }
        .social-links a:hover { background: var(--primary); transform: translateY(-2px); }
        .footer-title { color: #fff; font-size: 14px; font-weight: 600; margin-bottom: 20px; position: relative; padding-bottom: 8px; display: inline-block; letter-spacing: 0.5px; text-transform: uppercase; }
        .footer-title::after { content: ''; position: absolute; bottom: 0; left: 0; width: 24px; height: 2px; background: var(--primary); }
        .footer-links li { margin-bottom: 10px; }
        .footer-links a { font-size: 13px; transition: var(--transition); }
        .footer-links a:hover { color: #fff; transform: translateX(4px); display: inline-block; }
        .footer-contact li { display: flex; align-items: flex-start; gap: 12px; margin-bottom: 16px; font-size: 13px; }
        .footer-contact i { color: var(--primary); font-size: 15px; margin-top: 2px; }
        .footer-bottom { text-align: center; padding-top: 20px; border-top: 1px solid rgba(255,255,255,0.05); font-size: 12px; }

        .reveal { opacity: 0; transform: translateY(20px); transition: 0.8s cubic-bezier(0.5, 0, 0, 1); }
        .reveal.active { opacity: 1; transform: translateY(0); }
        .delay-1 { transition-delay: 0.1s; }
        .delay-2 { transition-delay: 0.2s; }
        .delay-3 { transition-delay: 0.3s; }
        .delay-4 { transition-delay: 0.4s; }

        @keyframes pulse { 0% { transform: scale(1); } 100% { transform: scale(1.1); } }

        @media (max-width: 1024px) {
            .stats-wrap { grid-template-columns: repeat(2, 1fr); }
            .activities-grid { grid-template-columns: repeat(2, 1fr); }
            .footer-grid { grid-template-columns: repeat(2, 1fr); }
            .header-contact { display: none; }
        }
        @media (max-width: 768px) {
            .top-bar { display: none; }
            .nav-links, .header-contact { display: none; }
            .mobile-btn { display: block; }
            .activities-header { flex-direction: column; align-items: flex-start; gap: 16px; margin-bottom: 30px; }
            .activities-grid { grid-template-columns: 1fr; }
            .stats-wrap { grid-template-columns: 1fr; }
            .footer-grid { grid-template-columns: 1fr; }
            .logo img { height: 45px; }
        }
    </style>
</head>
<body>

    <div class="top-bar">
        <div class="container">
            <div class="top-bar-links">
                <a href="<?php echo e($settings['facebook']); ?>"><i class="fab fa-facebook-f"></i></a>
                <a href="<?php echo e($settings['twitter']); ?>"><i class="fab fa-twitter"></i></a>
                <a href="<?php echo e($settings['instagram']); ?>"><i class="fab fa-instagram"></i></a>
                <a href="<?php echo e($settings['youtube']); ?>"><i class="fab fa-youtube"></i></a>
            </div>
        </div>
    </div>

    <nav class="navbar" id="navbar">
        <div class="container">
            
            <a href="index.php" class="logo">
                <?php if(!empty($settings['logo'])): ?>
                    <img src="admin/<?php echo e($settings['logo']); ?>" alt="KOAK Logo">
                <?php else: ?>
                    <i class="fas fa-hands-helping"></i> KOAK
                <?php endif; ?>
            </a>
            
            <div class="nav-links">
                <a href="index.php" style="color: var(--primary);">Anasayfa</a>
                
                <div class="dropdown">
                    <div class="dropdown-trigger">
                        Hakkımızda <i class="fas fa-chevron-down" style="font-size: 10px; margin-left: 2px;"></i>
                    </div>
                    <div class="dropdown-menu">
                        <a href="biz-kimiz.php"><i class="fas fa-info-circle"></i> Biz Kimiz?</a>
                        <a href="yonetim.php"><i class="fas fa-users"></i> Yönetim Kurulu</a>
                        <a href="galeri.php"><i class="fas fa-images"></i> Galerimiz</a>
                        <a href="belgeler.php"><i class="fas fa-file-alt"></i> Belgelerimiz</a>
                    </div>
                </div>
                
                <a href="faaliyetler.php">Eğitimlerimiz</a>
                <a href="iletisim.php">İletişim</a>
                <a href="destek.php">Bize Katıl !</a>
            </div>
            
            <div class="header-contact desktop">
                <div class="icon-box"><i class="fas fa-phone-volume"></i></div>
                <div class="text-box">
                    <span class="title">Bizi Arayın 7/24</span>
                    <span class="phone"><?php echo e($settings['phone']); ?></span>
                </div>
            </div>
            
            <div class="mobile-btn" id="mobileBtn">
                <span></span><span></span><span></span>
            </div>
        </div>
    </nav>

    <div class="mobile-menu" id="mobileMenu">
        <div style="margin-top: 60px; width: 100%;">
            <a href="index.php" class="mobile-link" style="color: var(--primary);">Anasayfa</a>
            
            <div class="mobile-dropdown-btn" onclick="document.getElementById('mobDropdown').classList.toggle('active')">
                Hakkımızda <i class="fas fa-chevron-down"></i>
            </div>
            <div class="mobile-dropdown-content" id="mobDropdown">
                <a href="biz-kimiz.php"><i class="fas fa-info-circle"></i> Biz Kimiz?</a>
                <a href="yonetim.php"><i class="fas fa-users"></i> Yönetim Kurulu</a>
                <a href="galeri.php"><i class="fas fa-images"></i> Galerimiz</a>
                <a href="belgeler.php"><i class="fas fa-file-alt"></i> Belgelerimiz</a>
            </div>
            
            <a href="faaliyetler.php" class="mobile-link">Eğitimlerimiz</a>
            <a href="iletisim.php" class="mobile-link">İletişim</a>
            <a href="destek.php" class="mobile-link">Bize Katıl !</a>
            
            <div style="margin-top: 30px; text-align: center;">
                <span style="font-size: 14px; color: var(--gray); display: block;">Bizi Arayın 7/24</span>
                <span style="font-size: 24px; font-weight: 900; color: var(--primary);"><?php echo e($settings['phone']); ?></span>
            </div>
        </div>
    </div>

    <header class="hero">
        <div class="hero-slider">
            <?php if(empty($sliders)): ?>
                <div class="slide active" style="background-image: url('https://images.unsplash.com/photo-1518398046578-8cca57782e17?auto=format&fit=crop&q=80&w=1920');"></div>
            <?php else: foreach($sliders as $index => $slide): ?>
                <div class="slide <?php echo $index === 0 ? 'active' : ''; ?>" style="background-image: url('admin/<?php echo e($slide['image_path']); ?>');"></div>
            <?php endforeach; endif; ?>
        </div>
        <div class="hero-overlay"></div>
        <div class="container">
            <div class="reveal">
                <span class="badge-text" style="background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.15); color: #fff;">Önce İnsan</span>
                <h1><?php echo $settings['hero_title']; ?></h1>
                <p><?php echo e($settings['hero_desc']); ?></p>
                <div class="hero-btns">
                    <a href="destek.php" class="btn-main primary">Bize Katılın <i class="fas fa-arrow-right"></i></a>
                    <a href="faaliyetler.php" class="btn-main outline"><i class="fas fa-play-circle"></i> Çalışmalarımız</a>
                </div>
            </div>
        </div>
    </header>

    <section class="about-section">
        <div class="container">
            <div class="reveal">
                <span class="badge-text">Misyonumuz</span>
                <h2 class="section-title"><?php echo e($settings['about_title']); ?></h2>
                <p><?php echo e($settings['about_desc']); ?></p>
            </div>
            
            <div class="stats-wrap" id="stats">
                <div class="stat-card reveal delay-1">
                    <div class="stat-icon"><i class="fas fa-users"></i></div>
                    <div class="stat-num" data-target="<?php echo intval($settings['stat1_num']); ?>">0</div>
                    <div class="stat-text"><?php echo e($settings['stat1_text']); ?></div>
                </div>
                <div class="stat-card reveal delay-2">
                    <div class="stat-icon"><i class="fas fa-truck-medical"></i></div>
                    <div class="stat-num" data-target="<?php echo intval($settings['stat2_num']); ?>">0</div>
                    <div class="stat-text"><?php echo e($settings['stat2_text']); ?></div>
                </div>
                <div class="stat-card reveal delay-3">
                    <div class="stat-icon"><i class="fas fa-hand-holding-heart"></i></div>
                    <div class="stat-num" data-target="<?php echo intval($settings['stat3_num']); ?>">0</div>
                    <div class="stat-text"><?php echo e($settings['stat3_text']); ?></div>
                </div>
                <div class="stat-card reveal delay-4">
                    <div class="stat-icon"><i class="fas fa-certificate"></i></div>
                    <div class="stat-num" data-target="<?php echo intval($settings['stat4_num']); ?>">0</div>
                    <div class="stat-text"><?php echo e($settings['stat4_text']); ?></div>
                </div>
            </div>
        </div>
    </section>

    <section class="activities-section">
        <div class="container">
            <div class="activities-header reveal">
                <div>
                    <span class="badge-text">GÜNCEL</span>
                    <h2 class="section-title" style="margin-bottom:0;">Son Faaliyetlerimiz</h2>
                </div>
                <a href="faaliyetler.php" class="btn-main primary" style="padding: 10px 22px;">Tümünü Gör</a>
            </div>

            <div class="activities-grid">
                <?php if(empty($latestActivities)): ?>
                    <div style="grid-column: 1 / -1; text-align: center; padding: 50px; background:#fff; border-radius:16px; color: var(--gray); font-size: 14px;">Henüz bir faaliyet eklenmemiş.</div>
                <?php else: $delay = 1; foreach($latestActivities as $n): ?>
                    <div class="act-card reveal delay-<?php echo $delay; ?>">
                        <div class="act-img-wrap">
                            <div class="act-cat-badge">
                                <i class="fas <?php echo e($n['cat_icon'] ?? 'fa-folder'); ?>"></i> <?php echo e($n['cat_name'] ?? 'Genel'); ?>
                            </div>
                            <?php echo newsImage($n, ''); ?>
                            <div class="act-overlay">
                                <a href="detay.php?id=<?php echo $n['id']; ?>" style="color:#fff; font-weight:600; font-size:13px;"><i class="fas fa-expand-arrows-alt"></i> İncele</a>
                            </div>
                        </div>
                        <div class="act-content">
                            <div class="act-meta">
                                <span><i class="far fa-calendar"></i> <?php echo date('d.m.Y', strtotime($n['published_at'])); ?></span>
                                <span><i class="far fa-eye"></i> <?php echo formatViews($n['views']); ?></span>
                            </div>
                            <h3 class="act-title"><a href="detay.php?id=<?php echo $n['id']; ?>"><?php echo e($n['title']); ?></a></h3>
                            <p class="act-summary"><?php echo e($n['summary']); ?></p>
                            <a href="detay.php?id=<?php echo $n['id']; ?>" class="act-btn">Devamını Oku <i class="fas fa-arrow-right"></i></a>
                        </div>
                    </div>
                <?php $delay++; endforeach; endif; ?>
            </div>
        </div>
    </section>

    <section class="cta-section">
        <div class="cta-shape"></div>
        <div class="cta-shape two"></div>
        <div class="container cta-content reveal">
            <h2>Bizimle Hayat Kurtarmak İster Misiniz?</h2>
            <p>Ekiplerimize katılıp eğitim alarak veya derneğimize bağış yaparak kurtarılacak yeni canlara umut olabilirsiniz. Birlikte daha güçlüyüz.</p>
            <div class="hero-btns" style="justify-content: center;">
                <a href="destek.php" class="btn-main" style="background:#fff; color:var(--dark);"><i class="fas fa-hands-helping" style="color:var(--primary);"></i> Bize Katıl!</a>
                <a href="iletisim.php" class="btn-main outline"><i class="fas fa-envelope"></i> İletişime Geç</a>
            </div>
        </div>
    </section>

    <footer class="footer">
        <div class="container">
            <div class="footer-grid">
                <div class="footer-about">
                    <div class="logo" style="color:#fff;">
                        <?php if(!empty($settings['logo'])): ?>
                            <img src="admin/<?php echo e($settings['logo']); ?>" alt="Logo" style="height:40px; margin-right:10px;">
                        <?php else: ?>
                            <i class="fas fa-hands-helping" style="color:var(--primary); margin-right:10px;"></i> 
                        <?php endif; ?>
                        KOAK
                    </div>
                    <p style="font-size: 13px; line-height: 1.7; margin-top:15px;">Gönüllü arama kurtarma ekibimizle afet durumlarında 7/24 hizmet veriyoruz.</p>
                    <div class="social-links">
                        <a href="<?php echo e($settings['facebook']); ?>"><i class="fab fa-facebook-f"></i></a>
                        <a href="<?php echo e($settings['twitter']); ?>"><i class="fab fa-twitter"></i></a>
                        <a href="<?php echo e($settings['instagram']); ?>"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
                <div>
                    <h4 class="footer-title">Kurumsal</h4>
                    <ul class="footer-links">
                        <li><a href="biz-kimiz.php">Biz Kimiz?</a></li>
                        <li><a href="yonetim.php">Yönetim Kurulu</a></li>
                        <li><a href="galeri.php">Galerimiz</a></li>
                        <li><a href="belgeler.php">Belgelerimiz</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="footer-title">Bağlantılar</h4>
                    <ul class="footer-links">
                        <li><a href="faaliyetler.php">Eğitimlerimiz</a></li>
                        <li><a href="destek.php">Bize Katıl !</a></li>
                        <li><a href="iletisim.php">İletişim</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="footer-title">İletişim Bilgileri</h4>
                    <ul class="footer-contact">
                        <li><i class="fas fa-map-marker-alt"></i> <span><?php echo e($settings['address']); ?></span></li>
                        <li><i class="fas fa-phone-alt"></i> <span><?php echo e($settings['phone']); ?></span></li>
                        <li><i class="fas fa-envelope"></i> <span><?php echo e($settings['email']); ?></span></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                &copy; <?php echo date('Y'); ?> <?php echo e($settings['site_title']); ?>. Tüm hakları saklıdır.
            </div>
        </div>
    </footer>

    <script>
        const navbar = document.getElementById('navbar');
        const mobileBtn = document.getElementById('mobileBtn');
        const mobileMenu = document.getElementById('mobileMenu');

        window.addEventListener('scroll', () => {
            if (window.scrollY > 20) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });

        mobileBtn.addEventListener('click', () => {
            mobileBtn.classList.toggle('active');
            mobileMenu.classList.toggle('active');
            document.body.style.overflow = mobileMenu.classList.contains('active') ? 'hidden' : 'auto';
        });

        const revealOptions = { threshold: 0.1, rootMargin: "0px 0px -30px 0px" };
        const revealObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('active');
                    observer.unobserve(entry.target);
                }
            });
        }, revealOptions);
        document.querySelectorAll('.reveal').forEach(el => revealObserver.observe(el));

        const slides = document.querySelectorAll('.slide');
        if (slides.length > 1) {
            let currentSlide = 0;
            setInterval(() => {
                slides[currentSlide].classList.remove('active');
                currentSlide = (currentSlide + 1) % slides.length;
                slides[currentSlide].classList.add('active');
            }, 5000);
        }

        const counters = document.querySelectorAll('.stat-num');
        let counted = false;
        const countUp = () => {
            counters.forEach(counter => {
                const target = +counter.getAttribute('data-target');
                const duration = 2000; 
                const increment = target / (duration / 16); 
                let current = 0;
                const updateCounter = () => {
                    current += increment;
                    if (current < target) {
                        counter.innerText = Math.ceil(current) + '+';
                        requestAnimationFrame(updateCounter);
                    } else {
                        counter.innerText = target + '+';
                    }
                };
                updateCounter();
            });
        };

        const statsSection = document.getElementById('stats');
        if (statsSection) {
            const statsObserver = new IntersectionObserver((entries) => {
                if (entries[0].isIntersecting && !counted) {
                    counted = true;
                    countUp();
                }
            }, { threshold: 0.5 });
            statsObserver.observe(statsSection);
        }
    </script>
</body>
</html>