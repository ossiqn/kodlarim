<?php
$message = '';
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? 'update';
    
    if($action == 'update') {
        $stmt = $pdo->prepare("UPDATE about SET tag_text = ?, title = ?, content = ?, badge_number = ?, badge_text = ? WHERE id = 1");
        $stmt->execute([$_POST['tag_text'], $_POST['title'], $_POST['content'], $_POST['badge_number'], $_POST['badge_text']]);
        $message = 'Hakkımızda güncellendi!';
    }
    
    if($action == 'add_feature') {
        $stmt = $pdo->prepare("INSERT INTO about_features (icon, title, sort_order, is_active) VALUES (?, ?, ?, 1)");
        $stmt->execute([$_POST['icon'], $_POST['feature_title'], $_POST['sort_order'] ?? 0]);
        $message = 'Özellik eklendi!';
    }
    
    if($action == 'delete_feature') {
        $stmt = $pdo->prepare("DELETE FROM about_features WHERE id = ?");
        $stmt->execute([$_POST['id']]);
        $message = 'Özellik silindi!';
    }
}

$about = $pdo->query("SELECT * FROM about LIMIT 1")->fetch();
$features = $pdo->query("SELECT * FROM about_features ORDER BY sort_order")->fetchAll();
?>

<?php if($message): ?>
<div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $message; ?></div>
<?php endif; ?>

<div class="card">
    <div class="card-header"><h3><i class="fas fa-info-circle"></i> Hakkımızda Bölümü</h3></div>
    <form method="POST">
        <input type="hidden" name="action" value="update">
        <div class="form-row">
            <div class="form-group">
                <label>Etiket</label>
                <input type="text" name="tag_text" value="<?php echo htmlspecialchars($about['tag_text'] ?? ''); ?>">
            </div>
            <div class="form-group">
                <label>Başlık</label>
                <input type="text" name="title" value="<?php echo htmlspecialchars($about['title'] ?? ''); ?>" required>
            </div>
        </div>
        <div class="form-group">
            <label>İçerik</label>
            <textarea name="content" rows="5"><?php echo htmlspecialchars($about['content'] ?? ''); ?></textarea>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>Rozet Sayısı (150+)</label>
                <input type="text" name="badge_number" value="<?php echo htmlspecialchars($about['badge_number'] ?? ''); ?>">
            </div>
            <div class="form-group">
                <label>Rozet Metni</label>
                <input type="text" name="badge_text" value="<?php echo htmlspecialchars($about['badge_text'] ?? ''); ?>">
            </div>
        </div>
        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Kaydet</button>
    </form>
</div>

<div class="card">
    <div class="card-header"><h3><i class="fas fa-star"></i> Özellikler</h3></div>
    <form method="POST" style="display:flex;gap:10px;margin-bottom:15px;flex-wrap:wrap;">
        <input type="hidden" name="action" value="add_feature">
        <input type="text" name="icon" placeholder="fa-users" required style="padding:10px;border:2px solid #ddd;border-radius:5px;width:120px;">
        <input type="text" name="feature_title" placeholder="Özellik adı" required style="flex:1;padding:10px;border:2px solid #ddd;border-radius:5px;">
        <input type="number" name="sort_order" value="0" style="width:60px;padding:10px;border:2px solid #ddd;border-radius:5px;">
        <button type="submit" class="btn btn-success"><i class="fas fa-plus"></i></button>
    </form>
    <table>
        <thead><tr><th>İkon</th><th>Başlık</th><th>Sıra</th><th>İşlem</th></tr></thead>
        <tbody>
            <?php foreach($features as $f): ?>
            <tr>
                <td><i class="fas <?php echo htmlspecialchars($f['icon']); ?>"></i> <?php echo htmlspecialchars($f['icon']); ?></td>
                <td><?php echo htmlspecialchars($f['title']); ?></td>
                <td><?php echo $f['sort_order']; ?></td>
                <td>
                    <form method="POST" style="display:inline" onsubmit="return confirmDelete()">
                        <input type="hidden" name="action" value="delete_feature">
                        <input type="hidden" name="id" value="<?php echo $f['id']; ?>">
                        <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>