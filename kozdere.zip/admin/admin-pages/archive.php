<?php
$message = '';
$error = '';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    
    if($action == 'add') {
        $image = '';
        
        if(isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
            $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
            
            if(in_array($ext, $allowed)) {
                $newname = 'archive_' . time() . '.' . $ext;
                if(move_uploaded_file($_FILES['image']['tmp_name'], '../uploads/' . $newname)) {
                    $image = $newname;
                }
            }
        }
        
        $stmt = $pdo->prepare("INSERT INTO archive (title, description, image, year, sort_order, is_active) VALUES (?, ?, ?, ?, ?, 1)");
        $stmt->execute([
            $_POST['title'],
            $_POST['description'],
            $image,
            $_POST['year'],
            $_POST['sort_order'] ?? 0
        ]);
        $message = 'Arşiv fotoğrafı eklendi!';
    }
    
    if($action == 'delete') {
        $stmt = $pdo->prepare("SELECT image FROM archive WHERE id = ?");
        $stmt->execute([$_POST['id']]);
        $img = $stmt->fetchColumn();
        
        if($img && file_exists('../uploads/' . $img)) {
            unlink('../uploads/' . $img);
        }
        
        $stmt = $pdo->prepare("DELETE FROM archive WHERE id = ?");
        $stmt->execute([$_POST['id']]);
        $message = 'Arşiv fotoğrafı silindi!';
    }
}

$archive = $pdo->query("SELECT * FROM archive ORDER BY year DESC, sort_order")->fetchAll();
?>

<?php if($message): ?>
<div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $message; ?></div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <h3><i class="fas fa-plus"></i> Yeni Eski Fotoğraf Ekle</h3>
    </div>
    <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="action" value="add">
        
        <div class="form-row">
            <div class="form-group">
                <label>Başlık</label>
                <input type="text" name="title" required placeholder="Örn: Eski Köy Meydanı">
            </div>
            <div class="form-group">
                <label>Yıl</label>
                <input type="text" name="year" placeholder="Örn: 1975" required>
            </div>
        </div>
        
        <div class="form-group">
            <label>Açıklama</label>
            <textarea name="description" placeholder="Fotoğraf hakkında bilgi..."></textarea>
        </div>
        
        <div class="form-row">
            <div class="form-group">
                <label>Fotoğraf</label>
                <input type="file" name="image" accept="image/*" required>
            </div>
            <div class="form-group">
                <label>Sıra No</label>
                <input type="number" name="sort_order" value="0">
            </div>
        </div>
        
        <button type="submit" class="btn btn-primary"><i class="fas fa-upload"></i> Arşive Ekle</button>
    </form>
</div>

<div class="card">
    <div class="card-header">
        <h3><i class="fas fa-archive"></i> Arşiv Fotoğrafları (<?php echo count($archive); ?>)</h3>
    </div>
    <div class="gallery-grid">
        <?php foreach($archive as $item): ?>
        <div class="gallery-item">
            <?php if($item['image'] && file_exists('../uploads/' . $item['image'])): ?>
                <img src="../uploads/<?php echo htmlspecialchars($item['image']); ?>" alt="">
            <?php else: ?>
                <div style="display:flex;align-items:center;justify-content:center;height:100%;background:#ddd;"><i class="fas fa-image" style="font-size:30px;color:#999;"></i></div>
            <?php endif; ?>
            <div class="overlay">
                <span><?php echo htmlspecialchars($item['title']); ?> (<?php echo $item['year']; ?>)</span>
                <form method="POST" style="display:inline" onsubmit="return confirmDelete()">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" value="<?php echo $item['id']; ?>">
                    <button type="submit" style="background:none;border:none;color:white;cursor:pointer;"><i class="fas fa-trash"></i></button>
                </form>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>