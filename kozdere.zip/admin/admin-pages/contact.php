<?php
$message = '';
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $stmt = $pdo->prepare("UPDATE contact SET title = ?, description = ?, address = ?, phone = ?, email = ?, working_hours = ?, map_embed = ? WHERE id = 1");
    $stmt->execute([$_POST['title'], $_POST['description'], $_POST['address'], $_POST['phone'], $_POST['email'], $_POST['working_hours'], $_POST['map_embed']]);
    $message = 'İletişim bilgileri güncellendi!';
}
$contact = $pdo->query("SELECT * FROM contact LIMIT 1")->fetch();
?>

<?php if($message): ?>
<div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $message; ?></div>
<?php endif; ?>

<div class="card">
    <div class="card-header"><h3><i class="fas fa-phone"></i> İletişim Bilgileri</h3></div>
    <form method="POST">
        <div class="form-row">
            <div class="form-group">
                <label>Başlık</label>
                <input type="text" name="title" value="<?php echo htmlspecialchars($contact['title'] ?? ''); ?>">
            </div>
            <div class="form-group">
                <label>Açıklama</label>
                <input type="text" name="description" value="<?php echo htmlspecialchars($contact['description'] ?? ''); ?>">
            </div>
        </div>
        <div class="form-group">
            <label>Adres</label>
            <textarea name="address"><?php echo htmlspecialchars($contact['address'] ?? ''); ?></textarea>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>Telefon</label>
                <input type="text" name="phone" value="<?php echo htmlspecialchars($contact['phone'] ?? ''); ?>">
            </div>
            <div class="form-group">
                <label>E-posta</label>
                <input type="email" name="email" value="<?php echo htmlspecialchars($contact['email'] ?? ''); ?>">
            </div>
        </div>
        <div class="form-group">
            <label>Çalışma Saatleri</label>
            <input type="text" name="working_hours" value="<?php echo htmlspecialchars($contact['working_hours'] ?? ''); ?>">
        </div>
        <div class="form-group">
            <label>Harita Embed Kodu (iframe)</label>
            <textarea name="map_embed" rows="3"><?php echo htmlspecialchars($contact['map_embed'] ?? ''); ?></textarea>
        </div>
        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Kaydet</button>
    </form>
</div>contact.php