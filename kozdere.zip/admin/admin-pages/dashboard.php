<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon blue"><i class="fas fa-newspaper"></i></div>
        <div>
            <div class="stat-number"><?php echo $stats['news']; ?></div>
            <div class="stat-label">Haber</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon green"><i class="fas fa-images"></i></div>
        <div>
            <div class="stat-number"><?php echo $stats['gallery']; ?></div>
            <div class="stat-label">Fotoğraf</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon orange"><i class="fas fa-video"></i></div>
        <div>
            <div class="stat-number"><?php echo $stats['videos']; ?></div>
            <div class="stat-label">Video</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon purple"><i class="fas fa-calendar"></i></div>
        <div>
            <div class="stat-number"><?php echo $stats['events']; ?></div>
            <div class="stat-label">Etkinlik</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon yellow"><i class="fas fa-archive"></i></div>
        <div>
            <div class="stat-number"><?php echo $stats['archive']; ?></div>
            <div class="stat-label">Arşiv</div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h3>Son Haberler</h3>
        <a href="admin.php?page=news" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Yeni Haber</a>
    </div>
    <table>
        <thead><tr><th>Başlık</th><th>Tarih</th><th>Durum</th></tr></thead>
        <tbody>
            <?php
            $recentNews = $pdo->query("SELECT * FROM news ORDER BY created_at DESC LIMIT 5")->fetchAll();
            foreach($recentNews as $item):
            ?>
            <tr>
                <td><?php echo htmlspecialchars($item['title']); ?></td>
                <td><?php echo date('d.m.Y', strtotime($item['news_date'])); ?></td>
                <td><span class="badge <?php echo $item['is_active'] ? 'badge-success' : 'badge-danger'; ?>"><?php echo $item['is_active'] ? 'Aktif' : 'Pasif'; ?></span></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<div class="card">
    <div class="card-header">
        <h3>Yaklaşan Etkinlikler</h3>
        <a href="admin.php?page=events" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Yeni Etkinlik</a>
    </div>
    <table>
        <thead><tr><th>Etkinlik</th><th>Tarih</th><th>Durum</th></tr></thead>
        <tbody>
            <?php
            $events = $pdo->query("SELECT * FROM events ORDER BY event_date DESC LIMIT 5")->fetchAll();
            foreach($events as $item):
            ?>
            <tr>
                <td><?php echo htmlspecialchars($item['title']); ?></td>
                <td><?php echo formatDate($item['event_date'], 'full'); ?></td>
                <td><span class="badge <?php echo $item['is_active'] ? 'badge-success' : 'badge-danger'; ?>"><?php echo $item['is_active'] ? 'Aktif' : 'Pasif'; ?></span></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>