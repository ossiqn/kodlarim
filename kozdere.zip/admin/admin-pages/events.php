<?php
$message = '';
$error = '';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    
    if($action == 'add') {
        $stmt = $pdo->prepare("INSERT INTO events (title, description, event_date, location, sort_order, is_active) VALUES (?, ?, ?, ?, ?, 1)");
        $stmt->execute([
            $_POST['title'],
            $_POST['description'],
            $_POST['event_date'],
            $_POST['location'],
            $_POST['sort_order'] ?? 0
        ]);
        $message = 'Etkinlik başarıyla eklendi!';
    }
    
    if($action == 'edit') {
        $stmt = $pdo->prepare("UPDATE events SET title = ?, description = ?, event_date = ?, location = ?, sort_order = ?, is_active = ? WHERE id = ?");
        $stmt->execute([
            $_POST['title'],
            $_POST['description'],
            $_POST['event_date'],
            $_POST['location'],
            $_POST['sort_order'],
            isset($_POST['is_active']) ? 1 : 0,
            $_POST['id']
        ]);
        $message = 'Etkinlik güncellendi!';
    }
    
    if($action == 'delete') {
        $stmt = $pdo->prepare("DELETE FROM events WHERE id = ?");
        $stmt->execute([$_POST['id']]);
        $message = 'Etkinlik silindi!';
    }
}

$events = $pdo->query("SELECT * FROM events ORDER BY event_date DESC")->fetchAll();
$editItem = null;
if(isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM events WHERE id = ?");
    $stmt->execute([$_GET['edit']]);
    $editItem = $stmt->fetch();
}
?>

<?php if($message): ?>
<div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $message; ?></div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <h3><i class="fas fa-<?php echo $editItem ? 'edit' : 'plus'; ?>"></i> <?php echo $editItem ? 'Etkinlik Düzenle' : 'Yeni Etkinlik Ekle'; ?></h3>
    </div>
    <form method="POST">
        <input type="hidden" name="action" value="<?php echo $editItem ? 'edit' : 'add'; ?>">
        <?php if($editItem): ?>
        <input type="hidden" name="id" value="<?php echo $editItem['id']; ?>">
        <?php endif; ?>
        
        <div class="form-row">
            <div class="form-group">
                <label>Etkinlik Adı</label>
                <input type="text" name="title" value="<?php echo htmlspecialchars($editItem['title'] ?? ''); ?>" required placeholder="Örn: Köy Şenliği">
            </div>
            <div class="form-group">
                <label>Tarih</label>
                <input type="date" name="event_date" value="<?php echo $editItem['event_date'] ?? date('Y-m-d'); ?>" required>
            </div>
        </div>
        
        <div class="form-group">
            <label>Açıklama</label>
            <textarea name="description" placeholder="Etkinlik hakkında detaylar..."><?php echo htmlspecialchars($editItem['description'] ?? ''); ?></textarea>
        </div>
        
        <div class="form-row">
            <div class="form-group">
                <label>Konum</label>
                <input type="text" name="location" value="<?php echo htmlspecialchars($editItem['location'] ?? ''); ?>" placeholder="Örn: Köy Meydanı">
            </div>
            <div class="form-group">
                <label>Sıra No</label>
                <input type="number" name="sort_order" value="<?php echo $editItem['sort_order'] ?? 0; ?>">
            </div>
        </div>
        
        <?php if($editItem): ?>
        <div class="form-group">
            <label class="checkbox-label">
                <input type="checkbox" name="is_active" <?php echo ($editItem['is_active'] ?? 1) ? 'checked' : ''; ?>>
                Aktif
            </label>
        </div>
        <?php endif; ?>
        
        <button type="submit" class="btn btn-primary">
            <i class="fas fa-<?php echo $editItem ? 'save' : 'plus'; ?>"></i> 
            <?php echo $editItem ? 'Güncelle' : 'Etkinlik Ekle'; ?>
        </button>
        <?php if($editItem): ?>
        <a href="admin.php?page=events" class="btn btn-secondary"><i class="fas fa-times"></i> İptal</a>
        <?php endif; ?>
    </form>
</div>

<div class="card">
    <div class="card-header">
        <h3><i class="fas fa-calendar"></i> Tüm Etkinlikler (<?php echo count($events); ?>)</h3>
    </div>
    <table>
        <thead>
            <tr>
                <th>Etkinlik</th>
                <th>Tarih</th>
                <th>Konum</th>
                <th>Durum</th>
                <th>İşlemler</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($events as $item): ?>
            <tr>
                <td><strong><?php echo htmlspecialchars($item['title']); ?></strong></td>
                <td><?php echo formatDate($item['event_date'], 'full'); ?></td>
                <td><?php echo htmlspecialchars($item['location']); ?></td>
                <td><span class="badge <?php echo $item['is_active'] ? 'badge-success' : 'badge-danger'; ?>"><?php echo $item['is_active'] ? 'Aktif' : 'Pasif'; ?></span></td>
                <td class="actions">
                    <a href="admin.php?page=events&edit=<?php echo $item['id']; ?>" class="btn btn-warning btn-sm"><i class="fas fa-edit"></i></a>
                    <form method="POST" style="display:inline" onsubmit="return confirmDelete('Bu etkinliği silmek istediğinize emin misiniz?')">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id" value="<?php echo $item['id']; ?>">
                        <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>