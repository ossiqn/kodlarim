<?php
$message = '';
$error = '';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    
    if($action == 'add') {
        if(isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
            $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            $filename = $_FILES['image']['name'];
            $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
            
            if(in_array($ext, $allowed)) {
                $newname = 'gallery_' . time() . '_' . rand(1000,9999) . '.' . $ext;
                $upload_path = '../uploads/' . $newname;
                
                if(move_uploaded_file($_FILES['image']['tmp_name'], $upload_path)) {
                    $stmt = $pdo->prepare("INSERT INTO gallery (category_id, title, image, sort_order, is_large, is_active) VALUES (?, ?, ?, ?, ?, 1)");
                    $stmt->execute([
                        $_POST['category_id'],
                        $_POST['title'],
                        $newname,
                        $_POST['sort_order'] ?? 0,
                        isset($_POST['is_large']) ? 1 : 0
                    ]);
                    $message = 'Fotoğraf başarıyla eklendi!';
                } else {
                    $error = 'Dosya yüklenemedi!';
                }
            } else {
                $error = 'Geçersiz dosya formatı! (jpg, png, gif, webp)';
            }
        } else {
            $error = 'Lütfen bir fotoğraf seçin!';
        }
    }
    
    if($action == 'delete') {
        $stmt = $pdo->prepare("SELECT image FROM gallery WHERE id = ?");
        $stmt->execute([$_POST['id']]);
        $img = $stmt->fetchColumn();
        
        if($img && file_exists('../uploads/' . $img)) {
            unlink('../uploads/' . $img);
        }
        
        $stmt = $pdo->prepare("DELETE FROM gallery WHERE id = ?");
        $stmt->execute([$_POST['id']]);
        $message = 'Fotoğraf silindi!';
    }
    
    if($action == 'add_category') {
        $stmt = $pdo->prepare("INSERT INTO gallery_categories (name, sort_order) VALUES (?, ?)");
        $stmt->execute([$_POST['cat_name'], $_POST['cat_order'] ?? 0]);
        $message = 'Kategori eklendi!';
    }
    
    if($action == 'delete_category') {
        $stmt = $pdo->prepare("DELETE FROM gallery_categories WHERE id = ?");
        $stmt->execute([$_POST['id']]);
        $message = 'Kategori silindi!';
    }
}

$categories = $pdo->query("SELECT * FROM gallery_categories ORDER BY sort_order")->fetchAll();
$gallery = $pdo->query("SELECT g.*, c.name as category_name FROM gallery g LEFT JOIN gallery_categories c ON g.category_id = c.id ORDER BY g.sort_order")->fetchAll();
?>

<?php if($message): ?>
<div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $message; ?></div>
<?php endif; ?>

<?php if($error): ?>
<div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <h3><i class="fas fa-plus"></i> Yeni Fotoğraf Ekle</h3>
    </div>
    <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="action" value="add">
        <div class="form-row">
            <div class="form-group">
                <label>Fotoğraf Başlığı</label>
                <input type="text" name="title" required placeholder="Örn: Köy Manzarası">
            </div>
            <div class="form-group">
                <label>Kategori</label>
                <select name="category_id">
                    <?php foreach($categories as $cat): ?>
                    <option value="<?php echo $cat['id']; ?>"><?php echo htmlspecialchars($cat['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>Fotoğraf Seç</label>
                <input type="file" name="image" accept="image/*" required>
            </div>
            <div class="form-group">
                <label>Sıra No</label>
                <input type="number" name="sort_order" value="0">
            </div>
        </div>
        <div class="form-group">
            <label class="checkbox-label">
                <input type="checkbox" name="is_large">
                Büyük göster (Ana galeride 2x2 boyutunda)
            </label>
        </div>
        <button type="submit" class="btn btn-primary"><i class="fas fa-upload"></i> Fotoğraf Yükle</button>
    </form>
</div>

<div class="card">
    <div class="card-header">
        <h3><i class="fas fa-folder"></i> Kategoriler</h3>
    </div>
    <form method="POST" style="display: flex; gap: 10px; margin-bottom: 15px;">
        <input type="hidden" name="action" value="add_category">
        <input type="text" name="cat_name" placeholder="Kategori adı" required style="flex:1; padding: 10px; border: 2px solid #ddd; border-radius: 5px;">
        <input type="number" name="cat_order" placeholder="Sıra" value="0" style="width: 80px; padding: 10px; border: 2px solid #ddd; border-radius: 5px;">
        <button type="submit" class="btn btn-success"><i class="fas fa-plus"></i></button>
    </form>
    <table>
        <thead><tr><th>Kategori</th><th>Sıra</th><th>İşlem</th></tr></thead>
        <tbody>
            <?php foreach($categories as $cat): ?>
            <tr>
                <td><?php echo htmlspecialchars($cat['name']); ?></td>
                <td><?php echo $cat['sort_order']; ?></td>
                <td>
                    <form method="POST" style="display:inline" onsubmit="return confirmDelete('Bu kategoriyi silmek istediğinize emin misiniz?')">
                        <input type="hidden" name="action" value="delete_category">
                        <input type="hidden" name="id" value="<?php echo $cat['id']; ?>">
                        <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<div class="card">
    <div class="card-header">
        <h3><i class="fas fa-images"></i> Tüm Fotoğraflar (<?php echo count($gallery); ?>)</h3>
    </div>
    <div class="gallery-grid">
        <?php foreach($gallery as $item): ?>
        <div class="gallery-item">
            <?php if($item['image'] && file_exists('../uploads/' . $item['image'])): ?>
                <img src="../uploads/<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['title']); ?>">
            <?php else: ?>
                <div style="display:flex;align-items:center;justify-content:center;height:100%;background:#ddd;"><i class="fas fa-image" style="font-size:30px;color:#999;"></i></div>
            <?php endif; ?>
            <div class="overlay">
                <span><?php echo htmlspecialchars($item['title']); ?></span>
                <form method="POST" style="display:inline" onsubmit="return confirmDelete()">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" value="<?php echo $item['id']; ?>">
                    <button type="submit" style="background:none;border:none;color:white;cursor:pointer;"><i class="fas fa-trash"></i></button>
                </form>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>