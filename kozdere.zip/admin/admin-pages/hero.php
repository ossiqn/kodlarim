<?php
$message = '';
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $stmt = $pdo->prepare("UPDATE hero SET badge_text = ?, title = ?, description = ?, button1_text = ?, button1_link = ?, button2_text = ?, button2_link = ? WHERE id = 1");
    $stmt->execute([$_POST['badge_text'], $_POST['title'], $_POST['description'], $_POST['button1_text'], $_POST['button1_link'], $_POST['button2_text'], $_POST['button2_link']]);
    $message = 'Hero alanı güncellendi!';
}
$hero = $pdo->query("SELECT * FROM hero LIMIT 1")->fetch();
?>

<?php if($message): ?>
<div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $message; ?></div>
<?php endif; ?>

<div class="card">
    <div class="card-header"><h3><i class="fas fa-image"></i> Ana Sayfa Hero Alanı</h3></div>
    <form method="POST">
        <div class="form-row">
            <div class="form-group">
                <label>Rozet (Üst Yazı)</label>
                <input type="text" name="badge_text" value="<?php echo htmlspecialchars($hero['badge_text'] ?? ''); ?>">
            </div>
            <div class="form-group">
                <label>Ana Başlık</label>
                <input type="text" name="title" value="<?php echo htmlspecialchars($hero['title'] ?? ''); ?>" required>
            </div>
        </div>
        <div class="form-group">
            <label>Açıklama</label>
            <textarea name="description"><?php echo htmlspecialchars($hero['description'] ?? ''); ?></textarea>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>1. Buton Metni</label>
                <input type="text" name="button1_text" value="<?php echo htmlspecialchars($hero['button1_text'] ?? ''); ?>">
            </div>
            <div class="form-group">
                <label>1. Buton Linki</label>
                <input type="text" name="button1_link" value="<?php echo htmlspecialchars($hero['button1_link'] ?? ''); ?>">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>2. Buton Metni</label>
                <input type="text" name="button2_text" value="<?php echo htmlspecialchars($hero['button2_text'] ?? ''); ?>">
            </div>
            <div class="form-group">
                <label>2. Buton Linki</label>
                <input type="text" name="button2_link" value="<?php echo htmlspecialchars($hero['button2_link'] ?? ''); ?>">
            </div>
        </div>
        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Kaydet</button>
    </form>
</div>