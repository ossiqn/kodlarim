<?php
$message = '';
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    
    if($action == 'add') {
        $stmt = $pdo->prepare("INSERT INTO menu (title, link, sort_order, is_active) VALUES (?, ?, ?, 1)");
        $stmt->execute([$_POST['title'], $_POST['link'], $_POST['sort_order'] ?? 0]);
        $message = 'Menü eklendi!';
    }
    
    if($action == 'delete') {
        $stmt = $pdo->prepare("DELETE FROM menu WHERE id = ?");
        $stmt->execute([$_POST['id']]);
        $message = 'Menü silindi!';
    }
}
$menu = $pdo->query("SELECT * FROM menu ORDER BY sort_order")->fetchAll();
?>

<?php if($message): ?>
<div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $message; ?></div>
<?php endif; ?>

<div class="card">
    <div class="card-header"><h3><i class="fas fa-plus"></i> Yeni Menü Ekle</h3></div>
    <form method="POST" style="display:flex;gap:10px;flex-wrap:wrap;">
        <input type="hidden" name="action" value="add">
        <input type="text" name="title" placeholder="Menü adı" required style="flex:1;padding:10px;border:2px solid #ddd;border-radius:5px;">
        <input type="text" name="link" placeholder="#link veya URL" required style="flex:1;padding:10px;border:2px solid #ddd;border-radius:5px;">
        <input type="number" name="sort_order" value="0" style="width:80px;padding:10px;border:2px solid #ddd;border-radius:5px;">
        <button type="submit" class="btn btn-primary"><i class="fas fa-plus"></i> Ekle</button>
    </form>
</div>

<div class="card">
    <div class="card-header"><h3><i class="fas fa-bars"></i> Menü Listesi</h3></div>
    <table>
        <thead><tr><th>Sıra</th><th>Başlık</th><th>Link</th><th>Durum</th><th>İşlem</th></tr></thead>
        <tbody>
            <?php foreach($menu as $m): ?>
            <tr>
                <td><?php echo $m['sort_order']; ?></td>
                <td><?php echo htmlspecialchars($m['title']); ?></td>
                <td><?php echo htmlspecialchars($m['link']); ?></td>
                <td><span class="badge <?php echo $m['is_active'] ? 'badge-success' : 'badge-danger'; ?>"><?php echo $m['is_active'] ? 'Aktif' : 'Pasif'; ?></span></td>
                <td>
                    <form method="POST" style="display:inline" onsubmit="return confirmDelete()">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id" value="<?php echo $m['id']; ?>">
                        <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>