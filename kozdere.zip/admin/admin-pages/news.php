<?php
$message = '';
$error = '';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    
    if($action == 'add' || $action == 'edit') {
        $image = $_POST['current_image'] ?? '';
        
        if(isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
            $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
            
            if(in_array($ext, $allowed)) {
                $newname = 'news_' . time() . '.' . $ext;
                if(move_uploaded_file($_FILES['image']['tmp_name'], '../uploads/' . $newname)) {
                    $image = $newname;
                }
            }
        }
        
        if($action == 'add') {
            $stmt = $pdo->prepare("INSERT INTO news (category, title, content, short_content, image, news_date, is_featured, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, 1)");
            $stmt->execute([
                $_POST['category'],
                $_POST['title'],
                $_POST['content'],
                $_POST['short_content'],
                $image,
                $_POST['news_date'],
                isset($_POST['is_featured']) ? 1 : 0
            ]);
            $message = 'Haber eklendi!';
        } else {
            $stmt = $pdo->prepare("UPDATE news SET category = ?, title = ?, content = ?, short_content = ?, image = ?, news_date = ?, is_featured = ?, is_active = ? WHERE id = ?");
            $stmt->execute([
                $_POST['category'],
                $_POST['title'],
                $_POST['content'],
                $_POST['short_content'],
                $image,
                $_POST['news_date'],
                isset($_POST['is_featured']) ? 1 : 0,
                isset($_POST['is_active']) ? 1 : 0,
                $_POST['id']
            ]);
            $message = 'Haber güncellendi!';
        }
    }
    
    if($action == 'delete') {
        $stmt = $pdo->prepare("DELETE FROM news WHERE id = ?");
        $stmt->execute([$_POST['id']]);
        $message = 'Haber silindi!';
    }
}

$news = $pdo->query("SELECT * FROM news ORDER BY news_date DESC")->fetchAll();
$editItem = null;
if(isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM news WHERE id = ?");
    $stmt->execute([$_GET['edit']]);
    $editItem = $stmt->fetch();
}
?>

<?php if($message): ?>
<div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $message; ?></div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <h3><i class="fas fa-<?php echo $editItem ? 'edit' : 'plus'; ?>"></i> <?php echo $editItem ? 'Haber Düzenle' : 'Yeni Haber Ekle'; ?></h3>
    </div>
    <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="action" value="<?php echo $editItem ? 'edit' : 'add'; ?>">
        <?php if($editItem): ?>
        <input type="hidden" name="id" value="<?php echo $editItem['id']; ?>">
        <input type="hidden" name="current_image" value="<?php echo htmlspecialchars($editItem['image'] ?? ''); ?>">
        <?php endif; ?>
        
        <div class="form-row">
            <div class="form-group">
                <label>Haber Başlığı</label>
                <input type="text" name="title" value="<?php echo htmlspecialchars($editItem['title'] ?? ''); ?>" required>
            </div>
            <div class="form-group">
                <label>Kategori</label>
                <input type="text" name="category" value="<?php echo htmlspecialchars($editItem['category'] ?? ''); ?>" placeholder="Duyuru, Etkinlik, vb.">
            </div>
        </div>
        
        <div class="form-group">
            <label>Kısa Açıklama</label>
            <textarea name="short_content" rows="2"><?php echo htmlspecialchars($editItem['short_content'] ?? ''); ?></textarea>
        </div>
        
        <div class="form-group">
            <label>İçerik</label>
            <textarea name="content" rows="5"><?php echo htmlspecialchars($editItem['content'] ?? ''); ?></textarea>
        </div>
        
        <div class="form-row">
            <div class="form-group">
                <label>Tarih</label>
                <input type="date" name="news_date" value="<?php echo $editItem['news_date'] ?? date('Y-m-d'); ?>" required>
            </div>
            <div class="form-group">
                <label>Görsel</label>
                <input type="file" name="image" accept="image/*">
                <?php if($editItem && $editItem['image']): ?>
                <img src="../uploads/<?php echo htmlspecialchars($editItem['image']); ?>" class="image-preview" style="margin-top:10px;">
                <?php endif; ?>
            </div>
        </div>
        
        <div class="form-row">
            <div class="form-group">
                <label class="checkbox-label">
                    <input type="checkbox" name="is_featured" <?php echo ($editItem['is_featured'] ?? 0) ? 'checked' : ''; ?>>
                    Öne Çıkan Haber
                </label>
            </div>
            <?php if($editItem): ?>
            <div class="form-group">
                <label class="checkbox-label">
                    <input type="checkbox" name="is_active" <?php echo ($editItem['is_active'] ?? 1) ? 'checked' : ''; ?>>
                    Aktif
                </label>
            </div>
            <?php endif; ?>
        </div>
        
        <button type="submit" class="btn btn-primary">
            <i class="fas fa-<?php echo $editItem ? 'save' : 'plus'; ?>"></i> 
            <?php echo $editItem ? 'Güncelle' : 'Haber Ekle'; ?>
        </button>
        <?php if($editItem): ?>
        <a href="admin.php?page=news" class="btn btn-secondary"><i class="fas fa-times"></i> İptal</a>
        <?php endif; ?>
    </form>
</div>

<div class="card">
    <div class="card-header">
        <h3><i class="fas fa-newspaper"></i> Tüm Haberler (<?php echo count($news); ?>)</h3>
    </div>
    <table>
        <thead>
            <tr><th>Başlık</th><th>Kategori</th><th>Tarih</th><th>Öne Çıkan</th><th>Durum</th><th>İşlem</th></tr>
        </thead>
        <tbody>
            <?php foreach($news as $item): ?>
            <tr>
                <td><?php echo htmlspecialchars($item['title']); ?></td>
                <td><?php echo htmlspecialchars($item['category']); ?></td>
                <td><?php echo date('d.m.Y', strtotime($item['news_date'])); ?></td>
                <td><span class="badge <?php echo $item['is_featured'] ? 'badge-success' : 'badge-danger'; ?>"><?php echo $item['is_featured'] ? 'Evet' : 'Hayır'; ?></span></td>
                <td><span class="badge <?php echo $item['is_active'] ? 'badge-success' : 'badge-danger'; ?>"><?php echo $item['is_active'] ? 'Aktif' : 'Pasif'; ?></span></td>
                <td class="actions">
                    <a href="admin.php?page=news&edit=<?php echo $item['id']; ?>" class="btn btn-warning btn-sm"><i class="fas fa-edit"></i></a>
                    <form method="POST" style="display:inline" onsubmit="return confirmDelete()">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id" value="<?php echo $item['id']; ?>">
                        <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>