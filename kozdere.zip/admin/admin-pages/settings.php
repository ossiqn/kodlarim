<?php
$message = '';
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $stmt = $pdo->prepare("UPDATE settings SET site_title = ?, site_description = ?, logo_text = ?, logo_subtitle = ?, footer_text = ? WHERE id = 1");
    $stmt->execute([$_POST['site_title'], $_POST['site_description'], $_POST['logo_text'], $_POST['logo_subtitle'], $_POST['footer_text']]);
    $message = 'Ayarlar kaydedildi!';
}
$settings = $pdo->query("SELECT * FROM settings LIMIT 1")->fetch();
?>

<?php if($message): ?>
<div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $message; ?></div>
<?php endif; ?>

<div class="card">
    <div class="card-header"><h3><i class="fas fa-cog"></i> Site Ayarları</h3></div>
    <form method="POST">
        <div class="form-row">
            <div class="form-group">
                <label>Site Başlığı</label>
                <input type="text" name="site_title" value="<?php echo htmlspecialchars($settings['site_title'] ?? ''); ?>" required>
            </div>
            <div class="form-group">
                <label>Site Açıklaması</label>
                <input type="text" name="site_description" value="<?php echo htmlspecialchars($settings['site_description'] ?? ''); ?>">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>Logo Metni</label>
                <input type="text" name="logo_text" value="<?php echo htmlspecialchars($settings['logo_text'] ?? ''); ?>">
            </div>
            <div class="form-group">
                <label>Logo Alt Metni</label>
                <input type="text" name="logo_subtitle" value="<?php echo htmlspecialchars($settings['logo_subtitle'] ?? ''); ?>">
            </div>
        </div>
        <div class="form-group">
            <label>Footer Metni</label>
            <textarea name="footer_text"><?php echo htmlspecialchars($settings['footer_text'] ?? ''); ?></textarea>
        </div>
        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Kaydet</button>
    </form>
</div>