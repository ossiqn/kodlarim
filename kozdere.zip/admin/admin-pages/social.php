<?php
$message = '';
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    
    if($action == 'add') {
        $stmt = $pdo->prepare("INSERT INTO social_links (platform, icon, url, sort_order, is_active) VALUES (?, ?, ?, ?, 1)");
        $stmt->execute([$_POST['platform'], $_POST['icon'], $_POST['url'], $_POST['sort_order'] ?? 0]);
        $message = 'Sosyal medya eklendi!';
    }
    
    if($action == 'delete') {
        $stmt = $pdo->prepare("DELETE FROM social_links WHERE id = ?");
        $stmt->execute([$_POST['id']]);
        $message = 'Sosyal medya silindi!';
    }
}
$social = $pdo->query("SELECT * FROM social_links ORDER BY sort_order")->fetchAll();
?>

<?php if($message): ?>
<div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $message; ?></div>
<?php endif; ?>

<div class="card">
    <div class="card-header"><h3><i class="fas fa-plus"></i> Yeni Sosyal Medya Ekle</h3></div>
    <form method="POST" style="display:flex;gap:10px;flex-wrap:wrap;">
        <input type="hidden" name="action" value="add">
        <input type="text" name="platform" placeholder="Platform (Facebook)" required style="padding:10px;border:2px solid #ddd;border-radius:5px;width:150px;">
        <input type="text" name="icon" placeholder="fab fa-facebook-f" required style="padding:10px;border:2px solid #ddd;border-radius:5px;width:180px;">
        <input type="url" name="url" placeholder="https://..." required style="flex:1;padding:10px;border:2px solid #ddd;border-radius:5px;">
        <input type="number" name="sort_order" value="0" style="width:60px;padding:10px;border:2px solid #ddd;border-radius:5px;">
        <button type="submit" class="btn btn-primary"><i class="fas fa-plus"></i></button>
    </form>
</div>

<div class="card">
    <div class="card-header"><h3><i class="fas fa-share-alt"></i> Sosyal Medya Linkleri</h3></div>
    <table>
        <thead><tr><th>İkon</th><th>Platform</th><th>URL</th><th>Sıra</th><th>İşlem</th></tr></thead>
        <tbody>
            <?php foreach($social as $s): ?>
            <tr>
                <td><i class="<?php echo htmlspecialchars($s['icon']); ?>"></i></td>
                <td><?php echo htmlspecialchars($s['platform']); ?></td>
                <td><a href="<?php echo htmlspecialchars($s['url']); ?>" target="_blank"><?php echo htmlspecialchars($s['url']); ?></a></td>
                <td><?php echo $s['sort_order']; ?></td>
                <td>
                    <form method="POST" style="display:inline" onsubmit="return confirmDelete()">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id" value="<?php echo $s['id']; ?>">
                        <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>