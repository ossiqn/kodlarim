<?php
$message = '';
$error = '';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    
    if($action == 'add') {
        $thumbnail = '';
        
        if(isset($_FILES['thumbnail']) && $_FILES['thumbnail']['error'] == 0) {
            $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            $ext = strtolower(pathinfo($_FILES['thumbnail']['name'], PATHINFO_EXTENSION));
            
            if(in_array($ext, $allowed)) {
                $newname = 'video_thumb_' . time() . '.' . $ext;
                if(move_uploaded_file($_FILES['thumbnail']['tmp_name'], '../uploads/' . $newname)) {
                    $thumbnail = $newname;
                }
            }
        }
        
        $stmt = $pdo->prepare("INSERT INTO videos (title, description, video_url, thumbnail, duration, sort_order, is_active) VALUES (?, ?, ?, ?, ?, ?, 1)");
        $stmt->execute([
            $_POST['title'],
            $_POST['description'],
            $_POST['video_url'],
            $thumbnail,
            $_POST['duration'],
            $_POST['sort_order'] ?? 0
        ]);
        $message = 'Video başarıyla eklendi!';
    }
    
    if($action == 'delete') {
        $stmt = $pdo->prepare("SELECT thumbnail FROM videos WHERE id = ?");
        $stmt->execute([$_POST['id']]);
        $thumb = $stmt->fetchColumn();
        
        if($thumb && file_exists('../uploads/' . $thumb)) {
            unlink('../uploads/' . $thumb);
        }
        
        $stmt = $pdo->prepare("DELETE FROM videos WHERE id = ?");
        $stmt->execute([$_POST['id']]);
        $message = 'Video silindi!';
    }
    
    if($action == 'edit') {
        $thumbnail = $_POST['current_thumb'];
        
        if(isset($_FILES['thumbnail']) && $_FILES['thumbnail']['error'] == 0) {
            $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            $ext = strtolower(pathinfo($_FILES['thumbnail']['name'], PATHINFO_EXTENSION));
            
            if(in_array($ext, $allowed)) {
                $newname = 'video_thumb_' . time() . '.' . $ext;
                if(move_uploaded_file($_FILES['thumbnail']['tmp_name'], '../uploads/' . $newname)) {
                    if($thumbnail && file_exists('../uploads/' . $thumbnail)) {
                        unlink('../uploads/' . $thumbnail);
                    }
                    $thumbnail = $newname;
                }
            }
        }
        
        $stmt = $pdo->prepare("UPDATE videos SET title = ?, description = ?, video_url = ?, thumbnail = ?, duration = ?, sort_order = ?, is_active = ? WHERE id = ?");
        $stmt->execute([
            $_POST['title'],
            $_POST['description'],
            $_POST['video_url'],
            $thumbnail,
            $_POST['duration'],
            $_POST['sort_order'],
            isset($_POST['is_active']) ? 1 : 0,
            $_POST['id']
        ]);
        $message = 'Video güncellendi!';
    }
}

$videos = $pdo->query("SELECT * FROM videos ORDER BY sort_order")->fetchAll();
$editItem = null;
if(isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM videos WHERE id = ?");
    $stmt->execute([$_GET['edit']]);
    $editItem = $stmt->fetch();
}
?>

<?php if($message): ?>
<div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $message; ?></div>
<?php endif; ?>

<?php if($error): ?>
<div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <h3><i class="fas fa-<?php echo $editItem ? 'edit' : 'plus'; ?>"></i> <?php echo $editItem ? 'Video Düzenle' : 'Yeni Video Ekle'; ?></h3>
    </div>
    <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="action" value="<?php echo $editItem ? 'edit' : 'add'; ?>">
        <?php if($editItem): ?>
        <input type="hidden" name="id" value="<?php echo $editItem['id']; ?>">
        <input type="hidden" name="current_thumb" value="<?php echo htmlspecialchars($editItem['thumbnail']); ?>">
        <?php endif; ?>
        
        <div class="form-row">
            <div class="form-group">
                <label>Video Başlığı</label>
                <input type="text" name="title" value="<?php echo htmlspecialchars($editItem['title'] ?? ''); ?>" required placeholder="Örn: Köy Tanıtım Filmi">
            </div>
            <div class="form-group">
                <label>Video URL (YouTube/Vimeo)</label>
                <input type="url" name="video_url" value="<?php echo htmlspecialchars($editItem['video_url'] ?? ''); ?>" placeholder="https://www.youtube.com/watch?v=...">
            </div>
        </div>
        
        <div class="form-group">
            <label>Açıklama</label>
            <textarea name="description" placeholder="Video hakkında kısa açıklama..."><?php echo htmlspecialchars($editItem['description'] ?? ''); ?></textarea>
        </div>
        
        <div class="form-row">
            <div class="form-group">
                <label>Kapak Görseli</label>
                <input type="file" name="thumbnail" accept="image/*">
                <?php if($editItem && $editItem['thumbnail']): ?>
                <img src="../uploads/<?php echo htmlspecialchars($editItem['thumbnail']); ?>" style="max-width:150px;margin-top:10px;border-radius:8px;">
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label>Süre</label>
                <input type="text" name="duration" value="<?php echo htmlspecialchars($editItem['duration'] ?? ''); ?>" placeholder="Örn: 5:32">
            </div>
        </div>
        
        <div class="form-row">
            <div class="form-group">
                <label>Sıra No</label>
                <input type="number" name="sort_order" value="<?php echo $editItem['sort_order'] ?? 0; ?>">
            </div>
            <?php if($editItem): ?>
            <div class="form-group">
                <label class="checkbox-label">
                    <input type="checkbox" name="is_active" <?php echo ($editItem['is_active'] ?? 1) ? 'checked' : ''; ?>>
                    Aktif
                </label>
            </div>
            <?php endif; ?>
        </div>
        
        <button type="submit" class="btn btn-primary">
            <i class="fas fa-<?php echo $editItem ? 'save' : 'plus'; ?>"></i> 
            <?php echo $editItem ? 'Güncelle' : 'Video Ekle'; ?>
        </button>
        <?php if($editItem): ?>
        <a href="admin.php?page=videos" class="btn btn-secondary"><i class="fas fa-times"></i> İptal</a>
        <?php endif; ?>
    </form>
</div>

<div class="card">
    <div class="card-header">
        <h3><i class="fas fa-video"></i> Tüm Videolar (<?php echo count($videos); ?>)</h3>
    </div>
    <div class="video-grid">
        <?php foreach($videos as $item): ?>
        <div class="video-item">
            <div class="video-thumb">
                <?php if($item['thumbnail'] && file_exists('../uploads/' . $item['thumbnail'])): ?>
                    <img src="../uploads/<?php echo htmlspecialchars($item['thumbnail']); ?>" alt="">
                <?php else: ?>
                    <i class="fas fa-play-circle"></i>
                <?php endif; ?>
            </div>
            <div class="video-info">
                <h4><?php echo htmlspecialchars($item['title']); ?></h4>
                <p><i class="fas fa-clock"></i> <?php echo htmlspecialchars($item['duration']); ?></p>
                <div class="actions" style="margin-top:10px;">
                    <a href="admin.php?page=videos&edit=<?php echo $item['id']; ?>" class="btn btn-warning btn-sm"><i class="fas fa-edit"></i></a>
                    <form method="POST" style="display:inline" onsubmit="return confirmDelete('Bu videoyu silmek istediğinize emin misiniz?')">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id" value="<?php echo $item['id']; ?>">
                        <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
                    </form>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>