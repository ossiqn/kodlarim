<?php
session_start();

$config_path = dirname(__DIR__) . '/config.php';
if(!file_exists($config_path)) {
    die("config.php bulunamadı!");
}
require_once $config_path;

if(!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit;
}

$page = $_GET['page'] ?? 'dashboard';

$stats = [
    'news' => $pdo->query("SELECT COUNT(*) FROM news")->fetchColumn(),
    'gallery' => $pdo->query("SELECT COUNT(*) FROM gallery")->fetchColumn(),
    'videos' => $pdo->query("SELECT COUNT(*) FROM videos")->fetchColumn(),
    'events' => $pdo->query("SELECT COUNT(*) FROM events")->fetchColumn(),
    'archive' => $pdo->query("SELECT COUNT(*) FROM archive")->fetchColumn(),
];
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Kozdere</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f6fa; }
        
        .admin-wrapper { display: flex; min-height: 100vh; }
        
        .sidebar {
            width: 250px;
            background: linear-gradient(180deg, #2d5a27, #1a3a1a);
            color: white;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }
        
        .sidebar-header {
            padding: 25px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar-header h3 { font-size: 20px; }
        
        .menu-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 15px 25px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            border-left: 3px solid transparent;
            transition: all 0.3s;
        }
        
        .menu-item:hover, .menu-item.active {
            background: rgba(255,255,255,0.1);
            color: white;
            border-left-color: #8fbc8f;
        }
        
        .menu-item i { width: 20px; }
        
        .main-content { flex: 1; margin-left: 250px; }
        
        .topbar {
            background: white;
            padding: 20px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            position: sticky;
            top: 0;
            z-index: 100;
        }
        
        .topbar h2 { color: #2d5a27; }
        
        .topbar-right { display: flex; align-items: center; gap: 15px; }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }
        
        .btn-primary { background: linear-gradient(135deg, #2d5a27, #4a7c43); color: white; }
        .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(45,90,39,0.3); }
        .btn-secondary { background: #6c757d; color: white; }
        .btn-danger { background: #dc3545; color: white; }
        .btn-warning { background: #ffc107; color: #333; }
        .btn-success { background: #28a745; color: white; }
        .btn-sm { padding: 6px 12px; font-size: 12px; }
        
        .content-area { padding: 30px; }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: white;
        }
        
        .stat-icon.blue { background: linear-gradient(135deg, #667eea, #764ba2); }
        .stat-icon.green { background: linear-gradient(135deg, #2d5a27, #4a7c43); }
        .stat-icon.orange { background: linear-gradient(135deg, #f093fb, #f5576c); }
        .stat-icon.purple { background: linear-gradient(135deg, #4facfe, #00f2fe); }
        .stat-icon.yellow { background: linear-gradient(135deg, #f5af19, #f12711); }
        
        .stat-number { font-size: 28px; font-weight: 700; color: #333; }
        .stat-label { color: #999; font-size: 14px; }
        
        .card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 25px;
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f0f0f0;
        }
        
        .card-header h3 { color: #333; font-size: 18px; }
        
        table { width: 100%; border-collapse: collapse; }
        table th { background: #f8f9fa; padding: 12px; text-align: left; font-weight: 600; color: #333; }
        table td { padding: 12px; border-bottom: 1px solid #f0f0f0; }
        table tbody tr:hover { background: #f8f9fa; }
        
        .badge {
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
        }
        
        .badge-success { background: #d4edda; color: #155724; }
        .badge-danger { background: #f8d7da; color: #721c24; }
        
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; margin-bottom: 8px; font-weight: 500; color: #333; }
        .form-group input, .form-group textarea, .form-group select {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        .form-group input:focus, .form-group textarea:focus, .form-group select:focus {
            outline: none;
            border-color: #2d5a27;
        }
        .form-group textarea { min-height: 100px; resize: vertical; }
        
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        
        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .alert-success { background: #d4edda; color: #155724; border-left: 4px solid #28a745; }
        .alert-danger { background: #f8d7da; color: #721c24; border-left: 4px solid #dc3545; }
        
        .actions { display: flex; gap: 8px; }
        
        .image-preview {
            max-width: 100px;
            max-height: 60px;
            border-radius: 5px;
            object-fit: cover;
        }
        
        .gallery-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            gap: 15px;
            margin-top: 20px;
        }
        
        .gallery-item {
            position: relative;
            aspect-ratio: 1;
            border-radius: 10px;
            overflow: hidden;
            background: #f0f0f0;
        }
        
        .gallery-item img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .gallery-item .overlay {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgba(0,0,0,0.7);
            color: white;
            padding: 8px;
            font-size: 12px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .video-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        
        .video-item {
            background: #f8f9fa;
            border-radius: 10px;
            overflow: hidden;
        }
        
        .video-thumb {
            height: 140px;
            background: linear-gradient(135deg, #1a3a1a, #2d5a27);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 40px;
            position: relative;
        }
        
        .video-thumb img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .video-info { padding: 15px; }
        .video-info h4 { margin-bottom: 5px; font-size: 14px; }
        .video-info p { color: #666; font-size: 12px; }
        
        .checkbox-label {
            display: flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
        }
        
        .checkbox-label input { width: auto; }
        
        @media (max-width: 768px) {
            .sidebar { transform: translateX(-100%); }
            .main-content { margin-left: 0; }
            .form-row { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <div class="admin-wrapper">
        <aside class="sidebar">
            <div class="sidebar-header">
                <h3>🍃 Kozdere Admin</h3>
            </div>
            <nav>
                <a href="admin.php?page=dashboard" class="menu-item <?php echo $page == 'dashboard' ? 'active' : ''; ?>">
                    <i class="fas fa-home"></i> Dashboard
                </a>
                <a href="admin.php?page=settings" class="menu-item <?php echo $page == 'settings' ? 'active' : ''; ?>">
                    <i class="fas fa-cog"></i> Site Ayarları
                </a>
                <a href="admin.php?page=hero" class="menu-item <?php echo $page == 'hero' ? 'active' : ''; ?>">
                    <i class="fas fa-image"></i> Hero Alanı
                </a>
                <a href="admin.php?page=about" class="menu-item <?php echo $page == 'about' ? 'active' : ''; ?>">
                    <i class="fas fa-info-circle"></i> Hakkımızda
                </a>
                <a href="admin.php?page=news" class="menu-item <?php echo $page == 'news' ? 'active' : ''; ?>">
                    <i class="fas fa-newspaper"></i> Haberler
                </a>
                <a href="admin.php?page=gallery" class="menu-item <?php echo $page == 'gallery' ? 'active' : ''; ?>">
                    <i class="fas fa-images"></i> Galeri
                </a>
                <a href="admin.php?page=videos" class="menu-item <?php echo $page == 'videos' ? 'active' : ''; ?>">
                    <i class="fas fa-video"></i> Videolar
                </a>
                <a href="admin.php?page=archive" class="menu-item <?php echo $page == 'archive' ? 'active' : ''; ?>">
                    <i class="fas fa-archive"></i> Arşiv
                </a>
                <a href="admin.php?page=events" class="menu-item <?php echo $page == 'events' ? 'active' : ''; ?>">
                    <i class="fas fa-calendar"></i> Etkinlikler
                </a>
                <a href="admin.php?page=contact" class="menu-item <?php echo $page == 'contact' ? 'active' : ''; ?>">
                    <i class="fas fa-phone"></i> İletişim
                </a>
                <a href="admin.php?page=menu" class="menu-item <?php echo $page == 'menu' ? 'active' : ''; ?>">
                    <i class="fas fa-bars"></i> Menü
                </a>
                <a href="admin.php?page=social" class="menu-item <?php echo $page == 'social' ? 'active' : ''; ?>">
                    <i class="fas fa-share-alt"></i> Sosyal Medya
                </a>
            </nav>
        </aside>

        <main class="main-content">
            <div class="topbar">
                <h2>
                    <?php
                    $titles = [
                        'dashboard' => 'Dashboard',
                        'settings' => 'Site Ayarları',
                        'hero' => 'Hero Alanı',
                        'about' => 'Hakkımızda',
                        'news' => 'Haberler',
                        'gallery' => 'Fotoğraf Galerisi',
                        'videos' => 'Video Galerisi',
                        'archive' => 'Eski Fotoğraflar / Arşiv',
                        'events' => 'Etkinlikler',
                        'contact' => 'İletişim Bilgileri',
                        'menu' => 'Menü Yönetimi',
                        'social' => 'Sosyal Medya',
                    ];
                    echo $titles[$page] ?? 'Dashboard';
                    ?>
                </h2>
                <div class="topbar-right">
                    <a href="../index.php" target="_blank" class="btn btn-secondary btn-sm">
                        <i class="fas fa-external-link-alt"></i> Siteyi Gör
                    </a>
                    <a href="logout.php" class="btn btn-danger btn-sm">
                        <i class="fas fa-sign-out-alt"></i> Çıkış
                    </a>
                </div>
            </div>

            <div class="content-area">
                <?php
                $allowed = ['dashboard','settings','hero','about','news','gallery','videos','archive','events','contact','menu','social'];
                $file = "admin-pages/{$page}.php";
                
                if(in_array($page, $allowed) && file_exists($file)) {
                    include $file;
                } else {
                    include 'admin-pages/dashboard.php';
                }
                ?>
            </div>
        </main>
    </div>

    <script>
        function confirmDelete(msg) {
            return confirm(msg || 'Silmek istediğinizden emin misiniz?');
        }
    </script>
</body>
</html>