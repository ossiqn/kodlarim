<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon blue">
            <i class="fas fa-newspaper"></i>
        </div>
        <div class="stat-info">
            <h4>Toplam Haber</h4>
            <div class="stat-number"><?php echo $stats['news']; ?></div>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon green">
            <i class="fas fa-images"></i>
        </div>
        <div class="stat-info">
            <h4>Galeri Fotoğrafları</h4>
            <div class="stat-number"><?php echo $stats['gallery']; ?></div>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon orange">
            <i class="fas fa-video"></i>
        </div>
        <div class="stat-info">
            <h4>Toplam Video</h4>
            <div class="stat-number"><?php echo $stats['videos']; ?></div>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon purple">
            <i class="fas fa-calendar"></i>
        </div>
        <div class="stat-info">
            <h4>Etkinlikler</h4>
            <div class="stat-number"><?php echo $stats['events']; ?></div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h3>Son Haberler</h3>
        <a href="admin.php?page=news" class="btn btn-primary btn-sm">
            <i class="fas fa-plus"></i> Yeni Haber
        </a>
    </div>
    <table>
        <thead>
            <tr>
                <th>Başlık</th>
                <th>Kategori</th>
                <th>Tarih</th>
                <th>Durum</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $recentNews = $pdo->query("SELECT * FROM news ORDER BY created_at DESC LIMIT 5")->fetchAll();
            foreach($recentNews as $news):
            ?>
            <tr>
                <td><?php echo htmlspecialchars($news['title']); ?></td>
                <td><?php echo htmlspecialchars($news['category']); ?></td>
                <td><?php echo date('d.m.Y', strtotime($news['news_date'])); ?></td>
                <td>
                    <?php if($news['is_active']): ?>
                        <span class="badge badge-success">Aktif</span>
                    <?php else: ?>
                        <span class="badge badge-danger">Pasif</span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<div class="card">
    <div class="card-header">
        <h3>Yaklaşan Etkinlikler</h3>
        <a href="admin.php?page=events" class="btn btn-primary btn-sm">
            <i class="fas fa-plus"></i> Yeni Etkinlik
        </a>
    </div>
    <table>
        <thead>
            <tr>
                <th>Etkinlik Adı</th>
                <th>Tarih</th>
                <th>Durum</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $upcomingEvents = $pdo->query("SELECT * FROM events WHERE event_date >= CURDATE() ORDER BY event_date ASC LIMIT 5")->fetchAll();
            foreach($upcomingEvents as $event):
            ?>
            <tr>
                <td><?php echo htmlspecialchars($event['title']); ?></td>
                <td><?php echo formatDate($event['event_date'], 'full'); ?></td>
                <td>
                    <?php if($event['is_active']): ?>
                        <span class="badge badge-success">Aktif</span>
                    <?php else: ?>
                        <span class="badge badge-danger">Pasif</span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>