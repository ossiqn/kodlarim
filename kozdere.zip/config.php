<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'kozdere');
define('DB_USER', 'root');
define('DB_PASS', '');

try {
    $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4", DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("Veritabanı bağlantı hatası: " . $e->getMessage());
}

function getSettings($pdo) {
    $stmt = $pdo->query("SELECT * FROM settings LIMIT 1");
    return $stmt->fetch();
}

function getHero($pdo) {
    $stmt = $pdo->query("SELECT * FROM hero WHERE is_active = 1 LIMIT 1");
    return $stmt->fetch();
}

function getAbout($pdo) {
    $stmt = $pdo->query("SELECT * FROM about WHERE is_active = 1 LIMIT 1");
    return $stmt->fetch();
}

function getAboutFeatures($pdo) {
    $stmt = $pdo->query("SELECT * FROM about_features WHERE is_active = 1 ORDER BY sort_order");
    return $stmt->fetchAll();
}

function getMenu($pdo) {
    $stmt = $pdo->query("SELECT * FROM menu WHERE is_active = 1 ORDER BY sort_order");
    return $stmt->fetchAll();
}

function getNews($pdo, $limit = 10) {
    $limit = (int)$limit;
    $stmt = $pdo->query("SELECT * FROM news WHERE is_active = 1 ORDER BY is_featured DESC, news_date DESC LIMIT $limit");
    return $stmt->fetchAll();
}

function getGalleryCategories($pdo) {
    $stmt = $pdo->query("SELECT * FROM gallery_categories WHERE is_active = 1 ORDER BY sort_order");
    return $stmt->fetchAll();
}

function getGallery($pdo) {
    $stmt = $pdo->query("SELECT * FROM gallery WHERE is_active = 1 ORDER BY sort_order");
    return $stmt->fetchAll();
}

function getVideos($pdo) {
    $stmt = $pdo->query("SELECT * FROM videos WHERE is_active = 1 ORDER BY sort_order");
    return $stmt->fetchAll();
}

function getArchive($pdo) {
    $stmt = $pdo->query("SELECT * FROM archive WHERE is_active = 1 ORDER BY sort_order");
    return $stmt->fetchAll();
}

function getEvents($pdo) {
    $stmt = $pdo->query("SELECT * FROM events WHERE is_active = 1 ORDER BY event_date DESC");
    return $stmt->fetchAll();
}

function getContact($pdo) {
    $stmt = $pdo->query("SELECT * FROM contact LIMIT 1");
    return $stmt->fetch();
}

function getSocialLinks($pdo) {
    $stmt = $pdo->query("SELECT * FROM social_links WHERE is_active = 1 ORDER BY sort_order");
    return $stmt->fetchAll();
}

function formatDate($date, $format = 'd') {
    if(!$date) return '';
    $months = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];
    $d = new DateTime($date);
    if ($format == 'd') {
        return $d->format('d');
    } elseif ($format == 'm') {
        return $months[$d->format('n') - 1];
    } elseif ($format == 'full') {
        return $d->format('d') . ' ' . $months[$d->format('n') - 1] . ' ' . $d->format('Y');
    }
    return $date;
}
?>