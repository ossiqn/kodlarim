<?php
require_once 'config.php';

$settings = getSettings($pdo);
$hero = getHero($pdo);
$about = getAbout($pdo);
$aboutFeatures = getAboutFeatures($pdo);
$menu = getMenu($pdo);
$news = getNews($pdo, 4);
$galleryCategories = getGalleryCategories($pdo);
$gallery = getGallery($pdo);
$videos = getVideos($pdo);
$archive = getArchive($pdo);
$events = getEvents($pdo);
$contact = getContact($pdo);
$socialLinks = getSocialLinks($pdo);
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($settings['site_title']); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=Open+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary-green: #2d5a27;
            --secondary-green: #4a7c43;
            --light-green: #8fbc8f;
            --cream: #f5f5dc;
            --earth-brown: #8b7355;
            --dark-text: #2c3e2c;
            --light-bg: #fafaf5;
        }

        body {
            font-family: 'Open Sans', sans-serif;
            color: var(--dark-text);
            line-height: 1.6;
            background-color: var(--light-bg);
        }

        .navbar {
            position: fixed;
            top: 0;
            width: 100%;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            z-index: 1000;
            padding: 15px 0;
            box-shadow: 0 2px 20px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
        }

        .navbar.scrolled {
            padding: 10px 0;
        }

        .nav-container {
            max-width: 1400px;
            margin: 0 auto;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 0 30px;
            position: relative;
        }

        .logo {
            position: absolute;
            left: 30px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .logo-icon {
            width: 45px;
            height: 45px;
            background: linear-gradient(135deg, var(--primary-green), var(--secondary-green));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 20px;
        }

        .logo-text {
            font-family: 'Playfair Display', serif;
            font-size: 24px;
            font-weight: 700;
            color: var(--primary-green);
        }

        .logo-text span {
            display: block;
            font-size: 11px;
            font-family: 'Open Sans', sans-serif;
            font-weight: 400;
            color: var(--earth-brown);
            letter-spacing: 2px;
        }

        .nav-menu {
            display: flex;
            list-style: none;
            gap: 35px;
        }

        .nav-menu a {
            text-decoration: none;
            color: var(--dark-text);
            font-weight: 500;
            font-size: 15px;
            transition: color 0.3s ease;
            position: relative;
        }

        .nav-menu a::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 0;
            height: 2px;
            background: var(--primary-green);
            transition: width 0.3s ease;
        }

        .nav-menu a:hover::after {
            width: 100%;
        }

        .nav-menu a:hover {
            color: var(--primary-green);
        }

        .mobile-toggle {
            display: none;
            position: absolute;
            right: 30px;
            flex-direction: column;
            cursor: pointer;
            gap: 5px;
        }

        .mobile-toggle span {
            width: 25px;
            height: 3px;
            background: var(--primary-green);
            border-radius: 3px;
            transition: 0.3s;
        }

        .hero {
            height: 100vh;
            min-height: 700px;
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
        }

        .hero-bg {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, #1a3a1a 0%, #2d5a27 50%, #4a7c43 100%);
        }

        .hero-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grain" width="100" height="100" patternUnits="userSpaceOnUse"><circle cx="25" cy="25" r="1" fill="rgba(255,255,255,0.03)"/><circle cx="75" cy="75" r="1" fill="rgba(255,255,255,0.03)"/></pattern></defs><rect width="100" height="100" fill="url(%23grain)"/></svg>');
        }

        .hero-pattern {
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 200px;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 200"><path fill="%23fafaf5" d="M0,160L48,144C96,128,192,96,288,90.7C384,85,480,107,576,122.7C672,139,768,149,864,138.7C960,128,1056,96,1152,90.7C1248,85,1344,107,1392,117.3L1440,128L1440,200L1392,200C1344,200,1248,200,1152,200C1056,200,960,200,864,200C768,200,672,200,576,200C480,200,384,200,288,200C192,200,96,200,48,200L0,200Z"/></svg>') no-repeat bottom;
            background-size: cover;
        }

        .hero-content {
            position: relative;
            z-index: 10;
            text-align: center;
            color: white;
            max-width: 900px;
            padding: 0 30px;
        }

        .hero-badge {
            display: inline-block;
            background: rgba(255,255,255,0.15);
            padding: 8px 25px;
            border-radius: 50px;
            font-size: 13px;
            letter-spacing: 3px;
            text-transform: uppercase;
            margin-bottom: 25px;
            backdrop-filter: blur(5px);
            border: 1px solid rgba(255,255,255,0.2);
        }

        .hero h1 {
            font-family: 'Playfair Display', serif;
            font-size: 72px;
            font-weight: 700;
            margin-bottom: 20px;
            text-shadow: 2px 4px 20px rgba(0,0,0,0.3);
            line-height: 1.1;
        }

        .hero p {
            font-size: 20px;
            opacity: 0.9;
            max-width: 600px;
            margin: 0 auto 40px;
            font-weight: 300;
            line-height: 1.8;
        }

        .hero-buttons {
            display: flex;
            gap: 20px;
            justify-content: center;
            flex-wrap: wrap;
        }

        .btn {
            padding: 16px 40px;
            border-radius: 50px;
            font-size: 15px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }

        .btn-primary {
            background: white;
            color: var(--primary-green);
        }

        .btn-primary:hover {
            background: var(--cream);
            transform: translateY(-3px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }

        .btn-secondary {
            background: transparent;
            color: white;
            border: 2px solid rgba(255,255,255,0.5);
        }

        .btn-secondary:hover {
            background: rgba(255,255,255,0.1);
            border-color: white;
        }

        .scroll-indicator {
            position: absolute;
            bottom: 50px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 10;
            animation: bounce 2s infinite;
        }

        .scroll-indicator a {
            color: white;
            font-size: 30px;
            opacity: 0.7;
            transition: opacity 0.3s;
        }

        @keyframes bounce {
            0%, 20%, 50%, 80%, 100% { transform: translateX(-50%) translateY(0); }
            40% { transform: translateX(-50%) translateY(-15px); }
            60% { transform: translateX(-50%) translateY(-7px); }
        }

        section {
            padding: 100px 30px;
        }

        .section-container {
            max-width: 1400px;
            margin: 0 auto;
        }

        .section-header {
            text-align: center;
            margin-bottom: 60px;
        }

        .section-tag {
            display: inline-block;
            background: linear-gradient(135deg, var(--light-green), var(--secondary-green));
            color: white;
            padding: 6px 20px;
            border-radius: 50px;
            font-size: 12px;
            letter-spacing: 2px;
            text-transform: uppercase;
            margin-bottom: 15px;
        }

        .section-header h2 {
            font-family: 'Playfair Display', serif;
            font-size: 42px;
            color: var(--primary-green);
            margin-bottom: 15px;
        }

        .section-header p {
            color: #666;
            font-size: 17px;
            max-width: 600px;
            margin: 0 auto;
        }

        .about-section {
            background: white;
        }

        .about-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 80px;
            align-items: center;
        }

        .about-image {
            position: relative;
        }

        .about-image-main {
            width: 100%;
            height: 500px;
            background: linear-gradient(135deg, var(--light-green), var(--secondary-green));
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 100px;
            color: white;
            overflow: hidden;
        }

        .about-image-main img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .about-image-badge {
            position: absolute;
            bottom: -30px;
            right: -30px;
            width: 150px;
            height: 150px;
            background: var(--primary-green);
            border-radius: 50%;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            color: white;
            box-shadow: 0 10px 40px rgba(45,90,39,0.3);
        }

        .about-image-badge span:first-child {
            font-family: 'Playfair Display', serif;
            font-size: 48px;
            font-weight: 700;
            line-height: 1;
        }

        .about-image-badge span:last-child {
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 2px;
        }

        .about-content h3 {
            font-family: 'Playfair Display', serif;
            font-size: 36px;
            color: var(--primary-green);
            margin-bottom: 25px;
        }

        .about-content p {
            color: #555;
            margin-bottom: 20px;
            font-size: 16px;
            line-height: 1.9;
        }

        .about-features {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-top: 35px;
        }

        .about-feature {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px;
            background: var(--light-bg);
            border-radius: 12px;
        }

        .about-feature i {
            width: 45px;
            height: 45px;
            background: var(--primary-green);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
        }

        .about-feature span {
            font-weight: 600;
            color: var(--dark-text);
        }

        .news-section {
            background: var(--light-bg);
        }

        .news-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 30px;
        }

        .news-card {
            background: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 5px 30px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
        }

        .news-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 50px rgba(0,0,0,0.15);
        }

        .news-card.featured {
            grid-column: span 2;
            grid-row: span 2;
        }

        .news-image {
            height: 200px;
            background: linear-gradient(135deg, var(--secondary-green), var(--light-green));
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 50px;
            color: white;
            position: relative;
            overflow: hidden;
        }

        .news-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .news-card.featured .news-image {
            height: 350px;
        }

        .news-date {
            position: absolute;
            top: 20px;
            left: 20px;
            background: white;
            padding: 10px 15px;
            border-radius: 10px;
            text-align: center;
        }

        .news-date span:first-child {
            display: block;
            font-size: 24px;
            font-weight: 700;
            color: var(--primary-green);
            line-height: 1;
        }

        .news-date span:last-child {
            font-size: 12px;
            color: #666;
            text-transform: uppercase;
        }

        .news-content {
            padding: 25px;
        }

        .news-category {
            display: inline-block;
            background: rgba(45,90,39,0.1);
            color: var(--primary-green);
            padding: 5px 15px;
            border-radius: 50px;
            font-size: 12px;
            font-weight: 600;
            margin-bottom: 12px;
        }

        .news-content h3 {
            font-family: 'Playfair Display', serif;
            font-size: 20px;
            color: var(--dark-text);
            margin-bottom: 12px;
            line-height: 1.4;
        }

        .news-card.featured .news-content h3 {
            font-size: 28px;
        }

        .news-content p {
            color: #666;
            font-size: 14px;
            line-height: 1.7;
        }

        .news-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: var(--primary-green);
            text-decoration: none;
            font-weight: 600;
            margin-top: 15px;
            transition: gap 0.3s;
        }

        .news-link:hover {
            gap: 15px;
        }

        .gallery-section {
            background: white;
        }

        .gallery-tabs {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin-bottom: 50px;
            flex-wrap: wrap;
        }

        .gallery-tab {
            padding: 12px 30px;
            border: 2px solid var(--light-green);
            border-radius: 50px;
            background: transparent;
            color: var(--dark-text);
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 14px;
        }

        .gallery-tab.active,
        .gallery-tab:hover {
            background: var(--primary-green);
            border-color: var(--primary-green);
            color: white;
        }

        .gallery-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
        }

        .gallery-item {
            position: relative;
            border-radius: 15px;
            overflow: hidden;
            cursor: pointer;
            aspect-ratio: 1;
        }

        .gallery-item.large {
            grid-column: span 2;
            grid-row: span 2;
        }

        .gallery-item-bg {
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, var(--light-green), var(--secondary-green));
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 40px;
            color: white;
            transition: transform 0.5s ease;
        }

        .gallery-item-bg img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .gallery-item:hover .gallery-item-bg {
            transform: scale(1.1);
        }

        .gallery-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(to top, rgba(0,0,0,0.7), transparent);
            opacity: 0;
            transition: opacity 0.3s ease;
            display: flex;
            align-items: flex-end;
            padding: 20px;
        }

        .gallery-item:hover .gallery-overlay {
            opacity: 1;
        }

        .gallery-overlay span {
            color: white;
            font-weight: 600;
        }

        .video-section {
            background: linear-gradient(135deg, var(--primary-green), var(--secondary-green));
            position: relative;
            overflow: hidden;
        }

        .video-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="80" cy="20" r="30" fill="rgba(255,255,255,0.03)"/><circle cx="20" cy="80" r="40" fill="rgba(255,255,255,0.03)"/></svg>');
        }

        .video-section .section-header h2,
        .video-section .section-header p {
            color: white;
        }

        .video-section .section-tag {
            background: rgba(255,255,255,0.2);
        }

        .video-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 30px;
            position: relative;
            z-index: 1;
        }

        .video-card {
            background: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            transition: transform 0.3s ease;
        }

        .video-card:hover {
            transform: translateY(-10px);
        }

        .video-thumbnail {
            height: 200px;
            background: linear-gradient(135deg, #1a3a1a, #2d5a27);
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow: hidden;
        }

        .video-thumbnail img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .play-button {
            width: 70px;
            height: 70px;
            background: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: var(--primary-green);
            box-shadow: 0 5px 30px rgba(0,0,0,0.3);
            transition: transform 0.3s ease;
            position: absolute;
        }

        .video-card:hover .play-button {
            transform: scale(1.1);
        }

        .video-info {
            padding: 20px;
        }

        .video-info h4 {
            font-family: 'Playfair Display', serif;
            font-size: 18px;
            color: var(--dark-text);
            margin-bottom: 8px;
        }

        .video-info p {
            color: #666;
            font-size: 13px;
        }

        .archive-section {
            background: var(--cream);
        }

        .archive-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 25px;
        }

        .archive-card {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
        }

        .archive-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0,0,0,0.15);
        }

        .archive-image {
            height: 180px;
            background: linear-gradient(45deg, #a0a0a0, #c0c0c0);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 40px;
            color: white;
            position: relative;
            overflow: hidden;
        }

        .archive-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .archive-year {
            position: absolute;
            bottom: 10px;
            right: 10px;
            background: rgba(0,0,0,0.7);
            color: white;
            padding: 5px 12px;
            border-radius: 5px;
            font-size: 12px;
            font-weight: 600;
        }

        .archive-info {
            padding: 15px;
        }

        .archive-info h4 {
            font-size: 15px;
            color: var(--dark-text);
            margin-bottom: 5px;
        }

        .archive-info p {
            color: #888;
            font-size: 12px;
        }

        .events-section {
            background: white;
        }

        .events-timeline {
            max-width: 900px;
            margin: 0 auto;
            position: relative;
        }

        .events-timeline::before {
            content: '';
            position: absolute;
            left: 50%;
            transform: translateX(-50%);
            width: 3px;
            height: 100%;
            background: var(--light-green);
            border-radius: 3px;
        }

        .event-item {
            display: flex;
            align-items: center;
            margin-bottom: 50px;
            position: relative;
        }

        .event-item:nth-child(odd) {
            flex-direction: row-reverse;
        }

        .event-content {
            width: 45%;
            background: var(--light-bg);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.05);
        }

        .event-item:nth-child(odd) .event-content {
            text-align: right;
        }

        .event-dot {
            position: absolute;
            left: 50%;
            transform: translateX(-50%);
            width: 20px;
            height: 20px;
            background: var(--primary-green);
            border-radius: 50%;
            border: 4px solid white;
            box-shadow: 0 0 0 3px var(--light-green);
            z-index: 1;
        }

        .event-date {
            display: inline-block;
            background: var(--primary-green);
            color: white;
            padding: 5px 15px;
            border-radius: 50px;
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 12px;
        }

        .event-content h4 {
            font-family: 'Playfair Display', serif;
            font-size: 20px;
            color: var(--dark-text);
            margin-bottom: 10px;
        }

        .event-content p {
            color: #666;
            font-size: 14px;
            line-height: 1.7;
        }

        .map-section {
            background: var(--light-bg);
            padding-bottom: 0;
        }

        .map-wrapper {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 0;
            background: white;
            border-radius: 20px 20px 0 0;
            overflow: hidden;
            box-shadow: 0 -10px 50px rgba(0,0,0,0.1);
        }

        .map-info {
            padding: 60px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .map-info h3 {
            font-family: 'Playfair Display', serif;
            font-size: 36px;
            color: var(--primary-green);
            margin-bottom: 20px;
        }

        .map-info > p {
            color: #666;
            margin-bottom: 30px;
            line-height: 1.8;
        }

        .contact-details {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .contact-item {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .contact-item i {
            width: 50px;
            height: 50px;
            background: var(--light-bg);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary-green);
            font-size: 20px;
        }

        .contact-item div strong {
            display: block;
            color: var(--dark-text);
            margin-bottom: 3px;
        }

        .contact-item div span {
            color: #666;
            font-size: 14px;
        }

        .map-container {
            height: 500px;
            background: #e8e8e8;
        }

        .map-container iframe {
            width: 100%;
            height: 100%;
            border: 0;
        }

        footer {
            background: var(--primary-green);
            color: white;
            padding: 80px 30px 30px;
        }

        .footer-container {
            max-width: 1400px;
            margin: 0 auto;
        }

        .footer-grid {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr 1fr;
            gap: 50px;
            margin-bottom: 50px;
        }

        .footer-brand h3 {
            font-family: 'Playfair Display', serif;
            font-size: 28px;
            margin-bottom: 15px;
        }

        .footer-brand p {
            opacity: 0.8;
            line-height: 1.8;
            margin-bottom: 25px;
        }

        .footer-social {
            display: flex;
            gap: 15px;
        }

        .footer-social a {
            width: 45px;
            height: 45px;
            background: rgba(255,255,255,0.1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .footer-social a:hover {
            background: white;
            color: var(--primary-green);
        }

        .footer-column h4 {
            font-size: 18px;
            margin-bottom: 25px;
            position: relative;
        }

        .footer-column h4::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 0;
            width: 30px;
            height: 2px;
            background: var(--light-green);
        }

        .footer-column ul {
            list-style: none;
        }

        .footer-column ul li {
            margin-bottom: 12px;
        }

        .footer-column ul a {
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .footer-column ul a:hover {
            color: white;
            padding-left: 5px;
        }

        .footer-bottom {
            border-top: 1px solid rgba(255,255,255,0.1);
            padding-top: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
        }

        .footer-bottom p {
            opacity: 0.7;
            font-size: 14px;
        }

        @media (max-width: 1200px) {
            .gallery-grid {
                grid-template-columns: repeat(3, 1fr);
            }
            
            .gallery-item.large {
                grid-column: span 2;
                grid-row: span 1;
            }
        }

        @media (max-width: 992px) {
            .nav-menu {
                display: none;
                position: absolute;
                top: 100%;
                left: 0;
                width: 100%;
                background: white;
                flex-direction: column;
                padding: 30px;
                gap: 20px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.1);
                align-items: center;
            }

            .nav-menu.active {
                display: flex;
            }

            .mobile-toggle {
                display: flex;
            }

            .hero h1 {
                font-size: 48px;
            }

            .about-grid {
                grid-template-columns: 1fr;
                gap: 50px;
            }

            .about-image-badge {
                right: 20px;
                bottom: -20px;
                width: 120px;
                height: 120px;
            }

            .about-image-badge span:first-child {
                font-size: 36px;
            }

            .news-grid {
                grid-template-columns: 1fr;
            }

            .news-card.featured {
                grid-column: span 1;
                grid-row: span 1;
            }

            .gallery-grid {
                grid-template-columns: repeat(2, 1fr);
            }

            .gallery-item.large {
                grid-column: span 1;
            }

            .video-grid {
                grid-template-columns: 1fr;
            }

            .archive-grid {
                grid-template-columns: repeat(2, 1fr);
            }

            .events-timeline::before {
                left: 20px;
            }

            .event-item,
            .event-item:nth-child(odd) {
                flex-direction: column;
                align-items: flex-start;
                padding-left: 50px;
            }

            .event-content,
            .event-item:nth-child(odd) .event-content {
                width: 100%;
                text-align: left;
            }

            .event-dot {
                left: 20px;
            }

            .map-wrapper {
                grid-template-columns: 1fr;
            }

            .footer-grid {
                grid-template-columns: 1fr 1fr;
            }
        }

        @media (max-width: 768px) {
            .logo {
                position: relative;
                left: 0;
            }

            .nav-container {
                justify-content: space-between;
            }

            section {
                padding: 70px 20px;
            }

            .hero h1 {
                font-size: 36px;
            }

            .hero p {
                font-size: 16px;
            }

            .section-header h2 {
                font-size: 32px;
            }

            .about-features {
                grid-template-columns: 1fr;
            }

            .gallery-grid {
                grid-template-columns: 1fr;
            }

            .archive-grid {
                grid-template-columns: 1fr;
            }

            .map-info {
                padding: 40px 30px;
            }

            .footer-grid {
                grid-template-columns: 1fr;
                text-align: center;
            }

            .footer-column h4::after {
                left: 50%;
                transform: translateX(-50%);
            }

            .footer-social {
                justify-content: center;
            }

            .footer-bottom {
                flex-direction: column;
                text-align: center;
            }
        }
    </style>
</head>
<body>

    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">
                <div class="logo-icon">
                    <i class="fas fa-leaf"></i>
                </div>
                <div class="logo-text">
                    <?php echo htmlspecialchars($settings['logo_text']); ?>
                    <span><?php echo htmlspecialchars($settings['logo_subtitle']); ?></span>
                </div>
            </div>
            <ul class="nav-menu">
                <?php foreach($menu as $item): ?>
                <li><a href="<?php echo htmlspecialchars($item['link']); ?>"><?php echo htmlspecialchars($item['title']); ?></a></li>
                <?php endforeach; ?>
            </ul>
            <div class="mobile-toggle">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    </nav>

    <section class="hero" id="anasayfa">
        <div class="hero-bg"></div>
        <div class="hero-overlay"></div>
        <div class="hero-pattern"></div>
        <div class="hero-content">
            <div class="hero-badge"><?php echo htmlspecialchars($hero['badge_text']); ?></div>
            <h1><?php echo htmlspecialchars($hero['title']); ?></h1>
            <p><?php echo htmlspecialchars($hero['description']); ?></p>
            <div class="hero-buttons">
                <a href="<?php echo htmlspecialchars($hero['button1_link']); ?>" class="btn btn-primary">
                    <i class="fas fa-info-circle"></i>
                    <?php echo htmlspecialchars($hero['button1_text']); ?>
                </a>
                <a href="<?php echo htmlspecialchars($hero['button2_link']); ?>" class="btn btn-secondary">
                    <i class="fas fa-images"></i>
                    <?php echo htmlspecialchars($hero['button2_text']); ?>
                </a>
            </div>
        </div>
        <div class="scroll-indicator">
            <a href="#hakkinda"><i class="fas fa-chevron-down"></i></a>
        </div>
    </section>

    <section class="about-section" id="hakkinda">
        <div class="section-container">
            <div class="about-grid">
                <div class="about-image">
                    <div class="about-image-main">
                        <?php if($about['image']): ?>
                            <img src="uploads/<?php echo htmlspecialchars($about['image']); ?>" alt="Kozdere">
                        <?php else: ?>
                            <i class="fas fa-mountain"></i>
                        <?php endif; ?>
                    </div>
                    <div class="about-image-badge">
                        <span><?php echo htmlspecialchars($about['badge_number']); ?></span>
                        <span><?php echo htmlspecialchars($about['badge_text']); ?></span>
                    </div>
                </div>
                <div class="about-content">
                    <div class="section-tag"><?php echo htmlspecialchars($about['tag_text']); ?></div>
                    <h3><?php echo htmlspecialchars($about['title']); ?></h3>
                    <?php echo nl2br(htmlspecialchars($about['content'])); ?>
                    <div class="about-features">
                        <?php foreach($aboutFeatures as $feature): ?>
                        <div class="about-feature">
                            <i class="fas <?php echo htmlspecialchars($feature['icon']); ?>"></i>
                            <span><?php echo htmlspecialchars($feature['title']); ?></span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="news-section" id="haberler">
        <div class="section-container">
            <div class="section-header">
                <div class="section-tag">Güncel</div>
                <h2>Haberler ve Duyurular</h2>
                <p>Köyümüzden en son gelişmeler ve önemli duyurular</p>
            </div>
            <div class="news-grid">
                <?php foreach($news as $index => $item): ?>
                <div class="news-card <?php echo $item['is_featured'] ? 'featured' : ''; ?>">
                    <div class="news-image">
                        <?php if($item['image']): ?>
                            <img src="uploads/<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['title']); ?>">
                        <?php else: ?>
                            <i class="fas fa-newspaper"></i>
                        <?php endif; ?>
                        <div class="news-date">
                            <span><?php echo formatDate($item['news_date'], 'd'); ?></span>
                            <span><?php echo formatDate($item['news_date'], 'm'); ?></span>
                        </div>
                    </div>
                    <div class="news-content">
                        <span class="news-category"><?php echo htmlspecialchars($item['category']); ?></span>
                        <h3><?php echo htmlspecialchars($item['title']); ?></h3>
                        <p><?php echo htmlspecialchars($item['short_content']); ?></p>
                        <a href="haber.php?id=<?php echo $item['id']; ?>" class="news-link">Devamını Oku <i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <section class="gallery-section" id="galeri">
        <div class="section-container">
            <div class="section-header">
                <div class="section-tag">Görsel</div>
                <h2>Fotoğraf Galerisi</h2>
                <p>Köyümüzün en güzel karelerini keşfedin</p>
            </div>
            <div class="gallery-tabs">
                <?php foreach($galleryCategories as $cat): ?>
                <button class="gallery-tab <?php echo $cat['sort_order'] == 0 ? 'active' : ''; ?>" data-category="<?php echo $cat['id']; ?>">
                    <?php echo htmlspecialchars($cat['name']); ?>
                </button>
                <?php endforeach; ?>
            </div>
            <div class="gallery-grid">
                <?php foreach($gallery as $item): ?>
                <div class="gallery-item <?php echo $item['is_large'] ? 'large' : ''; ?>" data-category="<?php echo $item['category_id']; ?>">
                    <div class="gallery-item-bg">
                        <?php if($item['image'] && file_exists('uploads/'.$item['image'])): ?>
                            <img src="uploads/<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['title']); ?>">
                        <?php else: ?>
                            <i class="fas <?php echo htmlspecialchars($item['image']); ?>"></i>
                        <?php endif; ?>
                    </div>
                    <div class="gallery-overlay"><span><?php echo htmlspecialchars($item['title']); ?></span></div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <section class="video-section">
        <div class="section-container">
            <div class="section-header">
                <div class="section-tag">Video</div>
                <h2>Video Galerisi</h2>
                <p>Köyümüzü daha yakından tanıyın</p>
            </div>
            <div class="video-grid">
                <?php foreach($videos as $video): ?>
                <div class="video-card" data-video="<?php echo htmlspecialchars($video['video_url']); ?>">
                    <div class="video-thumbnail">
                        <?php if($video['thumbnail']): ?>
                            <img src="uploads/<?php echo htmlspecialchars($video['thumbnail']); ?>" alt="<?php echo htmlspecialchars($video['title']); ?>">
                        <?php endif; ?>
                        <div class="play-button"><i class="fas fa-play"></i></div>
                    </div>
                    <div class="video-info">
                        <h4><?php echo htmlspecialchars($video['title']); ?></h4>
                        <p><i class="fas fa-clock"></i> <?php echo htmlspecialchars($video['duration']); ?> dakika</p>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <section class="archive-section" id="arsiv">
        <div class="section-container">
            <div class="section-header">
                <div class="section-tag">Arşiv</div>
                <h2>Eski Fotoğraflar ve Köy Arşivi</h2>
                <p>Geçmişten günümüze köyümüzün tarihi belgeleri</p>
            </div>
            <div class="archive-grid">
                <?php foreach($archive as $item): ?>
                <div class="archive-card">
                    <div class="archive-image">
                        <?php if($item['image']): ?>
                            <img src="uploads/<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['title']); ?>">
                        <?php else: ?>
                            <i class="fas fa-image"></i>
                        <?php endif; ?>
                        <span class="archive-year"><?php echo htmlspecialchars($item['year']); ?></span>
                    </div>
                    <div class="archive-info">
                        <h4><?php echo htmlspecialchars($item['title']); ?></h4>
                        <p><?php echo htmlspecialchars($item['description']); ?></p>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <section class="events-section" id="etkinlikler">
        <div class="section-container">
            <div class="section-header">
                <div class="section-tag">Takvim</div>
                <h2>Etkinlikler ve Gelişmeler</h2>
                <p>Köyümüzdeki önemli olaylar ve yaklaşan etkinlikler</p>
            </div>
            <div class="events-timeline">
                <?php foreach($events as $event): ?>
                <div class="event-item">
                    <div class="event-content">
                        <span class="event-date"><?php echo formatDate($event['event_date'], 'full'); ?></span>
                        <h4><?php echo htmlspecialchars($event['title']); ?></h4>
                        <p><?php echo htmlspecialchars($event['description']); ?></p>
                    </div>
                    <div class="event-dot"></div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <section class="map-section" id="iletisim">
        <div class="section-container">
            <div class="section-header">
                <div class="section-tag">Konum</div>
                <h2>Bize Ulaşın</h2>
                <p>Kozdere Köyü'nün konumu ve iletişim bilgileri</p>
            </div>
        </div>
        <div class="map-wrapper">
            <div class="map-info">
                <h3><?php echo htmlspecialchars($contact['title']); ?></h3>
                <p><?php echo htmlspecialchars($contact['description']); ?></p>
                <div class="contact-details">
                    <div class="contact-item">
                        <i class="fas fa-map-marker-alt"></i>
                        <div>
                            <strong>Adres</strong>
                            <span><?php echo htmlspecialchars($contact['address']); ?></span>
                        </div>
                    </div>
                    <div class="contact-item">
                        <i class="fas fa-phone"></i>
                        <div>
                            <strong>Telefon</strong>
                            <span><?php echo htmlspecialchars($contact['phone']); ?></span>
                        </div>
                    </div>
                    <div class="contact-item">
                        <i class="fas fa-envelope"></i>
                        <div>
                            <strong>E-posta</strong>
                            <span><?php echo htmlspecialchars($contact['email']); ?></span>
                        </div>
                    </div>
                    <div class="contact-item">
                        <i class="fas fa-clock"></i>
                        <div>
                            <strong>Muhtar Ofisi</strong>
                            <span><?php echo htmlspecialchars($contact['working_hours']); ?></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="map-container">
                <?php echo $contact['map_embed']; ?>
            </div>
        </div>
    </section>

    <footer>
        <div class="footer-container">
            <div class="footer-grid">
                <div class="footer-brand">
                    <h3><i class="fas fa-leaf"></i> <?php echo htmlspecialchars($settings['logo_text']); ?> <?php echo htmlspecialchars($settings['logo_subtitle']); ?></h3>
                    <p><?php echo htmlspecialchars($settings['footer_text']); ?></p>
                    <div class="footer-social">
                        <?php foreach($socialLinks as $social): ?>
                        <a href="<?php echo htmlspecialchars($social['url']); ?>" target="_blank"><i class="<?php echo htmlspecialchars($social['icon']); ?>"></i></a>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="footer-column">
                    <h4>Hızlı Linkler</h4>
                    <ul>
                        <?php foreach($menu as $item): ?>
                        <li><a href="<?php echo htmlspecialchars($item['link']); ?>"><i class="fas fa-chevron-right"></i> <?php echo htmlspecialchars($item['title']); ?></a></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <div class="footer-column">
                    <h4>Köy Bilgileri</h4>
                    <ul>
                        <li><a href="#"><i class="fas fa-chevron-right"></i> Köy Tarihi</a></li>
                        <li><a href="#"><i class="fas fa-chevron-right"></i> Muhtarlık</a></li>
                        <li><a href="#"><i class="fas fa-chevron-right"></i> Köy Derneği</a></li>
                        <li><a href="#"><i class="fas fa-chevron-right"></i> Nüfus Bilgileri</a></li>
                        <li><a href="#"><i class="fas fa-chevron-right"></i> Coğrafi Yapı</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <h4>Kaynaklar</h4>
                    <ul>
                        <li><a href="#arsiv"><i class="fas fa-chevron-right"></i> Arşiv</a></li>
                        <li><a href="#"><i class="fas fa-chevron-right"></i> Belgeler</a></li>
                        <li><a href="#"><i class="fas fa-chevron-right"></i> Soy Ağacı</a></li>
                        <li><a href="#arsiv"><i class="fas fa-chevron-right"></i> Eski Fotoğraflar</a></li>
                        <li><a href="#"><i class="fas fa-chevron-right"></i> Videolar</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> <?php echo htmlspecialchars($settings['site_title']); ?>. Tüm hakları saklıdır.</p>
                <p>Sevgiyle tasarlandı <i class="fas fa-heart" style="color: #ff6b6b;"></i></p>
            </div>
        </div>
    </footer>

    <script>
        document.querySelector('.mobile-toggle').addEventListener('click', function() {
            document.querySelector('.nav-menu').classList.toggle('active');
        });

        window.addEventListener('scroll', function() {
            const navbar = document.querySelector('.navbar');
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });

        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                    document.querySelector('.nav-menu').classList.remove('active');
                }
            });
        });

        document.querySelectorAll('.gallery-tab').forEach(tab => {
            tab.addEventListener('click', function() {
                document.querySelectorAll('.gallery-tab').forEach(t => t.classList.remove('active'));
                this.classList.add('active');
            });
        });
    </script>

</body>
</html>