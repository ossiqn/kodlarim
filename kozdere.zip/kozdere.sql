CREATE DATABASE IF NOT EXISTS kozdere CHARACTER SET utf8mb4 COLLATE utf8mb4_turkish_ci;
USE kozdere;

CREATE TABLE admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100),
    full_name VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    site_title VARCHAR(255) DEFAULT 'Kozdere Köyü',
    site_description TEXT,
    logo_text VARCHAR(100) DEFAULT 'Kozdere',
    logo_subtitle VARCHAR(100) DEFAULT 'Köyü Resmi Sitesi',
    footer_text TEXT,
    meta_keywords TEXT,
    meta_description TEXT
);

CREATE TABLE hero (
    id INT AUTO_INCREMENT PRIMARY KEY,
    badge_text VARCHAR(100) DEFAULT 'Hoş Geldiniz',
    title VARCHAR(255) DEFAULT 'Kozdere Köyü',
    description TEXT,
    button1_text VARCHAR(100),
    button1_link VARCHAR(255),
    button2_text VARCHAR(100),
    button2_link VARCHAR(255),
    background_image VARCHAR(255),
    is_active TINYINT(1) DEFAULT 1
);

CREATE TABLE about (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tag_text VARCHAR(100) DEFAULT 'Tarihimiz',
    title VARCHAR(255),
    content TEXT,
    image VARCHAR(255),
    badge_number VARCHAR(50) DEFAULT '150+',
    badge_text VARCHAR(100) DEFAULT 'Yıllık Tarih',
    is_active TINYINT(1) DEFAULT 1
);

CREATE TABLE about_features (
    id INT AUTO_INCREMENT PRIMARY KEY,
    icon VARCHAR(50),
    title VARCHAR(100),
    sort_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1
);

CREATE TABLE news (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category VARCHAR(100),
    title VARCHAR(255) NOT NULL,
    content TEXT,
    short_content TEXT,
    image VARCHAR(255),
    news_date DATE,
    is_featured TINYINT(1) DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE gallery_categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    sort_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1
);

CREATE TABLE gallery (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT,
    title VARCHAR(255),
    image VARCHAR(255),
    sort_order INT DEFAULT 0,
    is_large TINYINT(1) DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES gallery_categories(id) ON DELETE SET NULL
);

CREATE TABLE videos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    video_url VARCHAR(255),
    thumbnail VARCHAR(255),
    duration VARCHAR(20),
    sort_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE archive (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    image VARCHAR(255),
    year VARCHAR(10),
    sort_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    event_date DATE,
    location VARCHAR(255),
    sort_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE contact (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) DEFAULT 'İletişim Bilgileri',
    description TEXT,
    address TEXT,
    phone VARCHAR(50),
    email VARCHAR(100),
    working_hours VARCHAR(255),
    map_embed TEXT,
    map_lat VARCHAR(50),
    map_lng VARCHAR(50)
);

CREATE TABLE menu (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    link VARCHAR(255) NOT NULL,
    sort_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1
);

CREATE TABLE social_links (
    id INT AUTO_INCREMENT PRIMARY KEY,
    platform VARCHAR(50) NOT NULL,
    icon VARCHAR(50),
    url VARCHAR(255),
    sort_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1
);

CREATE TABLE messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100),
    phone VARCHAR(50),
    subject VARCHAR(255),
    message TEXT,
    is_read TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO admins (username, password, email, full_name) VALUES 
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin@kozdere.net', 'Site Yöneticisi');

INSERT INTO settings (site_title, site_description, footer_text) VALUES 
('Kozdere Köyü', 'Doğanın kalbinde, tarihin izinde...', 'Doğanın kalbinde, tarihin izinde... Köyümüzün resmi web sitesine hoş geldiniz.');

INSERT INTO hero (badge_text, title, description, button1_text, button1_link, button2_text, button2_link) VALUES 
('Hoş Geldiniz', 'Kozdere Köyü', 'Doğanın kalbinde, tarihin izinde... Yeşilin bin bir tonuyla buluştuğu, geleneklerin yaşatıldığı güzel köyümüze hoş geldiniz.', 'Köyümüzü Keşfedin', '#hakkinda', 'Fotoğraf Galerisi', '#galeri');

INSERT INTO about (tag_text, title, content, badge_number, badge_text) VALUES 
('Tarihimiz', 'Kozdere Köyü Tarihi', 'Kozdere Köyü, yüzyıllardır süregelen zengin bir kültürel mirasa ev sahipliği yapmaktadır. Köyümüz, doğal güzellikleri ve tarihi dokusuyla öne çıkan, Anadolu''nun en güzel köşelerinden biridir.\n\nDedelerimizden bize miras kalan bu topraklar, günümüzde de aynı sevgi ve saygıyla korunmakta, geleneklerimiz yaşatılmaktadır.', '150+', 'Yıllık Tarih');

INSERT INTO about_features (icon, title, sort_order) VALUES 
('fa-users', 'Birlik ve Beraberlik', 1),
('fa-tree', 'Doğal Güzellikler', 2),
('fa-landmark', 'Tarihi Mekanlar', 3),
('fa-heart', 'Sıcak Misafirperverlik', 4);

INSERT INTO menu (title, link, sort_order) VALUES 
('Ana Sayfa', '#anasayfa', 1),
('Köyümüz', '#hakkinda', 2),
('Haberler', '#haberler', 3),
('Galeri', '#galeri', 4),
('Arşiv', '#arsiv', 5),
('Etkinlikler', '#etkinlikler', 6),
('İletişim', '#iletisim', 7);

INSERT INTO social_links (platform, icon, url, sort_order) VALUES 
('Facebook', 'fab fa-facebook-f', '#', 1),
('Instagram', 'fab fa-instagram', '#', 2),
('YouTube', 'fab fa-youtube', '#', 3),
('WhatsApp', 'fab fa-whatsapp', '#', 4);

INSERT INTO gallery_categories (name, sort_order) VALUES 
('Tümü', 0),
('Doğa', 1),
('Köy Manzaraları', 2),
('Etkinlikler', 3),
('Mevsimler', 4);

INSERT INTO gallery (category_id, title, image, sort_order, is_large) VALUES 
(1, 'Köy Panoraması', 'fa-mountain', 1, 1),
(2, 'Orman Yolu', 'fa-tree', 2, 0),
(2, 'Dere Kenarı', 'fa-water', 3, 0),
(3, 'Tarihi Evler', 'fa-home', 4, 0),
(3, 'Gün Batımı', 'fa-sun', 5, 0),
(4, 'Sonbahar', 'fa-leaf', 6, 0),
(4, 'Kış Manzarası', 'fa-snowflake', 7, 0);

INSERT INTO videos (title, description, duration, sort_order) VALUES 
('Kozdere Köyü Tanıtım Filmi', 'Köyümüzün tanıtım videosu', '5:32', 1),
('Geleneksel Köy Şenliği 2024', 'Şenlik görüntüleri', '8:15', 2),
('Dört Mevsim Kozdere', 'Mevsimlik görüntüler', '4:45', 3);

INSERT INTO archive (title, description, year, sort_order) VALUES 
('Eski Köy Meydanı', 'Köyümüzün 60''lı yıllardaki görünümü', '1960', 1),
('Düğün Fotoğrafı', 'Geleneksel köy düğünü', '1975', 2),
('Okul Açılışı', 'İlkokul açılış töreni', '1982', 3),
('Hasat Zamanı', 'Geleneksel hasat günleri', '1990', 4);

INSERT INTO events (title, description, event_date, sort_order) VALUES 
('Geleneksel Köy Şenliği', 'Her yıl düzenlenen geleneksel köy şenliğimiz bu yıl da coşkuyla kutlanacak. Müzik, dans ve lezzetli yemekler sizleri bekliyor.', '2025-07-15', 1),
('Bahar Temizliği', 'Köyümüzün ortak alanlarının temizliği ve çevre düzenlemesi için tüm köylülerimizi bekliyoruz.', '2025-05-20', 2),
('Köy Derneği Toplantısı', 'Yılın ilk dernek toplantısında yeni dönem projeleri görüşülecek.', '2025-03-10', 3),
('Kış Yardımlaşması', 'İhtiyaç sahibi ailelerimize kış yardımı kampanyası düzenleniyor.', '2025-02-01', 4);

INSERT INTO news (category, title, content, short_content, news_date, is_featured) VALUES 
('Duyuru', 'Köy Meydanı Yenileme Projesi Başladı', 'Köyümüzün merkezi olan meydan alanı, modern bir anlayışla yeniden düzenleniyor.', 'Köyümüzün merkezi olan meydan alanı, modern bir anlayışla yeniden düzenleniyor. Proje kapsamında çevre düzenlemesi, oturma alanları ve aydınlatma çalışmaları yapılacak.', '2025-01-15', 1),
('Etkinlik', 'Yıllık Köy Şenliği Tarihi Belirlendi', 'Bu yılki geleneksel şenliğimiz Temmuz ayında gerçekleştirilecek.', 'Bu yılki geleneksel şenliğimiz Temmuz ayında gerçekleştirilecek.', '2025-01-10', 0),
('Altyapı', 'Yol Yapım Çalışmaları Tamamlandı', 'Köy içi yollarının asfaltlama çalışmaları başarıyla bitirildi.', 'Köy içi yollarının asfaltlama çalışmaları başarıyla bitirildi.', '2025-01-05', 0),
('Hizmet', 'İçme Suyu Şebekesi Yenilendi', 'Modern altyapı ile su kesintileri artık tarihe karışıyor.', 'Modern altyapı ile su kesintileri artık tarihe karışıyor.', '2025-01-01', 0);

INSERT INTO contact (title, description, address, phone, email, working_hours, map_embed) VALUES 
('İletişim Bilgileri', 'Köyümüzü ziyaret etmek veya bilgi almak için bizimle iletişime geçebilirsiniz.', 'Kozdere Köyü, Merkez / Türkiye', '+90 (XXX) XXX XX XX', 'info@kozdere.net', 'Pazartesi - Cuma: 09:00 - 17:00', '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3000!2d32!3d40!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNDDCsDA1JzI0LjAiTiAzMsKwMTUnMzYuMCJF!5e0!3m2!1str!2str!4v1600000000000!5m2!1str!2str" allowfullscreen="" loading="lazy"></iframe>');