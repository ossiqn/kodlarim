<?php
session_start();

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: 0");
$timeout = 1800;
if (isset($_SESSION['admin_giris_tarihi'])) {
    if (time() - $_SESSION['admin_giris_tarihi'] > $timeout) {
        session_destroy();
        header("Location: /login");
        exit;
    }
}

if (!isset($_SESSION['admin_giris']) || $_SESSION['admin_giris'] !== true) {
    header("Location: /login");
    exit;
}

require_once 'config.php';

if (isset($_GET['logout'])) {
    header("Location: /logout");
    exit;
}

$mesaj = '';
$mesaj_tur = 'success';

function resim_yukle($file, $prefix, $eski_yol = '') {
    if (!isset($file) || $file['error'] != 0) {
        return $eski_yol;
    }
    
    $izin_verilen = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'];
    $uzantisi = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    if (!in_array($uzantisi, $izin_verilen)) {
        return $eski_yol;
    }
    
    if (!file_exists('images')) {
        mkdir('images', 0777, true);
    }
    
    $dosya_adi = time() . '_' . $prefix . '_' . uniqid() . '.' . $uzantisi;
    $hedef = 'images/' . $dosya_adi;
    
    if (move_uploaded_file($file['tmp_name'], $hedef)) {
        return $hedef;
    }
    
    return $eski_yol;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['ayarlar_guncelle'])) {
        $eski = $db->query("SELECT * FROM peyzaj_ayarlar WHERE id=1")->fetch(PDO::FETCH_ASSOC);
        
        $site_baslik = $_POST['site_baslik'] ?? $eski['site_baslik'];
        $site_aciklama = $_POST['site_aciklama'] ?? $eski['site_aciklama'];
        $telefon = $_POST['telefon'] ?? $eski['telefon'];
        $eposta = $_POST['eposta'] ?? $eski['eposta'];
        $adres = $_POST['adres'] ?? $eski['adres'];
        $whatsapp = $_POST['whatsapp'] ?? $eski['whatsapp'];
        $hero_baslik = $_POST['hero_baslik'] ?? $eski['hero_baslik'];
        $hero_alt_baslik = $_POST['hero_alt_baslik'] ?? $eski['hero_alt_baslik'];
        $facebook = $_POST['facebook'] ?? $eski['facebook'];
        $instagram = $_POST['instagram'] ?? $eski['instagram'];
        
        $guncelle = $db->prepare("UPDATE peyzaj_ayarlar SET site_baslik=?, site_aciklama=?, telefon=?, eposta=?, adres=?, whatsapp=?, hero_baslik=?, hero_alt_baslik=?, facebook=?, instagram=? WHERE id=1");
        if ($guncelle->execute([$site_baslik, $site_aciklama, $telefon, $eposta, $adres, $whatsapp, $hero_baslik, $hero_alt_baslik, $facebook, $instagram])) {
            $mesaj = 'Ayarlar başarıyla güncellendi.';
        }
    }
    
    if (isset($_POST['blog_ekle'])) {
        $gorsel = resim_yukle($_FILES['gorsel'] ?? null, 'blog');
        $seo_url = strtolower(str_replace(' ', '-', $_POST['baslik'] ?? 'blog'));
        
        $ekle = $db->prepare("INSERT INTO peyzaj_blog (baslik, ozet, icerik, gorsel, seo_url) VALUES (?, ?, ?, ?, ?)");
        if ($ekle->execute([$_POST['baslik'], $_POST['ozet'], $_POST['icerik'], $gorsel, $seo_url])) {
            $mesaj = 'Blog yazısı eklendi.';
        }
    }
    
    if (isset($_POST['blog_duzenle'])) {
        $gorsel = resim_yukle($_FILES['gorsel'] ?? null, 'blog', $_POST['eski_gorsel']);
        
        $guncelle = $db->prepare("UPDATE peyzaj_blog SET baslik=?, ozet=?, icerik=?, gorsel=? WHERE id=?");
        if ($guncelle->execute([$_POST['baslik'], $_POST['ozet'], $_POST['icerik'], $gorsel, $_POST['id']])) {
            $mesaj = 'Blog yazısı güncellendi.';
        }
    }
    
    if (isset($_POST['hizmet_ekle'])) {
        $ekle = $db->prepare("INSERT INTO peyzaj_hizmetler (baslik, aciklama, ikon, sira) VALUES (?, ?, ?, ?)");
        if ($ekle->execute([$_POST['baslik'], $_POST['aciklama'], $_POST['ikon'], $_POST['sira']])) {
            $mesaj = 'Hizmet eklendi.';
        }
    }
    
    if (isset($_POST['hizmet_duzenle'])) {
        $guncelle = $db->prepare("UPDATE peyzaj_hizmetler SET baslik=?, aciklama=?, ikon=?, sira=? WHERE id=?");
        if ($guncelle->execute([$_POST['baslik'], $_POST['aciklama'], $_POST['ikon'], $_POST['sira'], $_POST['id']])) {
            $mesaj = 'Hizmet güncellendi.';
        }
    }
    
    if (isset($_POST['portfolyo_ekle'])) {
        $gorsel = resim_yukle($_FILES['gorsel'] ?? null, 'port');
        
        $ekle = $db->prepare("INSERT INTO peyzaj_portfolyo (baslik, gorsel, kategori, sira) VALUES (?, ?, ?, ?)");
        if ($ekle->execute([$_POST['baslik'], $gorsel, $_POST['kategori'], $_POST['sira']])) {
            $mesaj = 'Proje eklendi.';
        }
    }
    
    if (isset($_POST['portfolyo_duzenle'])) {
        $gorsel = resim_yukle($_FILES['gorsel'] ?? null, 'port', $_POST['eski_gorsel']);
        
        $guncelle = $db->prepare("UPDATE peyzaj_portfolyo SET baslik=?, gorsel=?, kategori=?, sira=? WHERE id=?");
        if ($guncelle->execute([$_POST['baslik'], $gorsel, $_POST['kategori'], $_POST['sira'], $_POST['id']])) {
            $mesaj = 'Proje güncellendi.';
        }
    }
    
    if (isset($_POST['talep_durum'])) {
        $guncelle = $db->prepare("UPDATE peyzaj_talepler SET durum=? WHERE id=?");
        if ($guncelle->execute([$_POST['yeni_durum'], $_POST['id']])) {
            $mesaj = 'Talep durumu güncellendi.';
        }
    }
}

if (isset($_GET['sil'])) {
    $id = (int)$_GET['sil'];
    $tip = $_GET['tip'] ?? '';
    
    if ($tip === 'blog') {
        $db->prepare("DELETE FROM peyzaj_blog WHERE id=?")->execute([$id]);
        $mesaj = 'Blog yazısı silindi.';
        $mesaj_tur = 'warning';
    } elseif ($tip === 'hizmet') {
        $db->prepare("DELETE FROM peyzaj_hizmetler WHERE id=?")->execute([$id]);
        $mesaj = 'Hizmet silindi.';
        $mesaj_tur = 'warning';
    } elseif ($tip === 'portfolyo') {
        $db->prepare("DELETE FROM peyzaj_portfolyo WHERE id=?")->execute([$id]);
        $mesaj = 'Proje silindi.';
        $mesaj_tur = 'warning';
    } elseif ($tip === 'talep') {
        $db->prepare("DELETE FROM peyzaj_talepler WHERE id=?")->execute([$id]);
        $mesaj = 'Talep silindi.';
        $mesaj_tur = 'warning';
    }
}

$ayarlar = $db->query("SELECT * FROM peyzaj_ayarlar WHERE id=1")->fetch(PDO::FETCH_ASSOC);
$bloglar = $db->query("SELECT * FROM peyzaj_blog ORDER BY tarih DESC")->fetchAll(PDO::FETCH_ASSOC);
$hizmetler = $db->query("SELECT * FROM peyzaj_hizmetler ORDER BY sira ASC")->fetchAll(PDO::FETCH_ASSOC);
$portfolyo = $db->query("SELECT * FROM peyzaj_portfolyo ORDER BY sira ASC")->fetchAll(PDO::FETCH_ASSOC);
$talepler = $db->query("SELECT * FROM peyzaj_talepler ORDER BY tarih DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - <?php echo htmlspecialchars($ayarlar['site_baslik']); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Poppins', sans-serif; background: #f1f5f9; }
        .sidebar { height: 100vh; background: #0f172a; color: white; position: fixed; left: 0; top: 0; width: 280px; padding: 20px 0; overflow-y: auto; z-index: 1000; }
        .sidebar-brand { font-size: 1.4rem; font-weight: 800; color: #10b981; padding: 0 20px 30px; text-align: center; }
        .nav-link { color: #94a3b8; margin: 5px 15px; padding: 12px 20px; border-radius: 8px; transition: 0.3s; }
        .nav-link:hover, .nav-link.active { background: #10b981; color: white; }
        .nav-link i { margin-right: 10px; width: 20px; }
        .main-content { margin-left: 280px; padding: 30px; }
        .topbar { background: white; padding: 20px 30px; border-radius: 12px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 2px 8px rgba(0,0,0,0.08); margin-bottom: 30px; flex-wrap: wrap; gap: 15px; }
        .card { border: none; box-shadow: 0 2px 8px rgba(0,0,0,0.08); border-radius: 12px; margin-bottom: 30px; }
        .card-header { background: white; border-bottom: 1px solid #f1f5f9; padding: 20px; border-radius: 12px 12px 0 0; font-weight: 700; color: #0f172a; }
        .card-body { padding: 25px; }
        .form-control, textarea { border-radius: 8px; border: 1px solid #e2e8f0; padding: 10px 14px; }
        .form-control:focus, textarea:focus { border-color: #10b981; box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.1); }
        .btn-brand { background: #10b981; color: white; border: none; padding: 10px 20px; border-radius: 8px; font-weight: 600; }
        .btn-brand:hover { background: #059669; color: white; }
        .btn-sm { padding: 6px 12px; font-size: 0.85rem; }
        .btn-edit { background: #3b82f6; color: white; border: none; padding: 6px 12px; border-radius: 6px; cursor: pointer; }
        .btn-edit:hover { background: #2563eb; }
        .btn-delete { background: #ef4444; color: white; border: none; padding: 6px 12px; border-radius: 6px; cursor: pointer; }
        .btn-delete:hover { background: #dc2626; }
        .table { vertical-align: middle; }
        .table thead th { background: #f8fafc; color: #475569; font-weight: 600; border: none; padding: 15px; }
        .table tbody td { border-color: #f1f5f9; padding: 15px; }
        .badge { padding: 6px 12px; border-radius: 6px; font-weight: 600; }
        .badge-success { background: #d1fae5; color: #065f46; }
        .badge-warning { background: #fef3c7; color: #92400e; }
        .badge-danger { background: #fee2e2; color: #991b1b; }
        .sidebar-toggle { display: none; background: #0f172a; color: white; border: none; padding: 10px 15px; border-radius: 6px; }
        @media (max-width: 991px) {
            .sidebar { left: -280px; transition: 0.3s; }
            .sidebar.active { left: 0; }
            .main-content { margin-left: 0; }
            .sidebar-toggle { display: block; }
        }
    </style>
</head>
<body>
    <div class="sidebar" id="sidebar">
        <div class="sidebar-brand"><i class="fas fa-leaf me-2"></i>Doğa Peyzaj</div>
        <nav class="nav flex-column nav-pills">
            <a href="#tab-genel" class="nav-link active" data-bs-toggle="tab"><i class="fas fa-cog"></i> Ayarlar</a>
            <a href="#tab-blog" class="nav-link" data-bs-toggle="tab"><i class="fas fa-blog"></i> Blog</a>
            <a href="#tab-hizmetler" class="nav-link" data-bs-toggle="tab"><i class="fas fa-handshake"></i> Hizmetler</a>
            <a href="#tab-portfolyo" class="nav-link" data-bs-toggle="tab"><i class="fas fa-images"></i> Portfolyo</a>
            <a href="#tab-talepler" class="nav-link" data-bs-toggle="tab"><i class="fas fa-inbox"></i> Talepler</a>
            <hr style="border-color: #334155; margin: 20px 0;">
            <a href="index.php" class="nav-link" target="_blank"><i class="fas fa-external-link-alt"></i> Siteyi Gör</a>
            <a href="/logout" class="nav-link"><i class="fas fa-sign-out-alt"></i> Çıkış Yap</a>
        </nav>
    </div>

    <div class="main-content">
        <div class="topbar">
            <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
            <div>
                <h4 class="m-0 mb-1 fw-bold">Yönetim Paneli</h4>
                <small class="text-muted">Hoş geldiniz, yönetici!</small>
            </div>
            <div>
                <a href="/logout" class="btn btn-sm btn-danger"><i class="fas fa-sign-out-alt me-2"></i>Çıkış</a>
            </div>
        </div>

        <?php if ($mesaj): ?>
            <div class="alert alert-<?php echo $mesaj_tur; ?> alert-dismissible fade show" role="alert">
                <i class="fas fa-check-circle me-2"></i><?php echo $mesaj; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="tab-content">
            <div class="tab-pane fade show active" id="tab-genel">
                <div class="card">
                    <div class="card-header">Site Ayarları</div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Site Başlığı</label>
                                    <input type="text" name="site_baslik" class="form-control" value="<?php echo htmlspecialchars($ayarlar['site_baslik']); ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Telefon</label>
                                    <input type="tel" name="telefon" class="form-control" value="<?php echo htmlspecialchars($ayarlar['telefon']); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">E-Posta</label>
                                    <input type="email" name="eposta" class="form-control" value="<?php echo htmlspecialchars($ayarlar['eposta']); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">WhatsApp Numarası</label>
                                    <input type="text" name="whatsapp" class="form-control" value="<?php echo htmlspecialchars($ayarlar['whatsapp']); ?>">
                                </div>
                                <div class="col-12 mb-3">
                                    <label class="form-label">Adres</label>
                                    <input type="text" name="adres" class="form-control" value="<?php echo htmlspecialchars($ayarlar['adres']); ?>">
                                </div>
                                <div class="col-12 mb-3">
                                    <label class="form-label">Site Açıklaması</label>
                                    <textarea name="site_aciklama" class="form-control" rows="3"><?php echo htmlspecialchars($ayarlar['site_aciklama']); ?></textarea>
                                </div>
                                <div class="col-12 mb-3">
                                    <label class="form-label">Hero Başlığı</label>
                                    <input type="text" name="hero_baslik" class="form-control" value="<?php echo htmlspecialchars($ayarlar['hero_baslik']); ?>">
                                </div>
                                <div class="col-12 mb-3">
                                    <label class="form-label">Hero Alt Başlığı</label>
                                    <textarea name="hero_alt_baslik" class="form-control" rows="2"><?php echo htmlspecialchars($ayarlar['hero_alt_baslik']); ?></textarea>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Facebook</label>
                                    <input type="text" name="facebook" class="form-control" value="<?php echo htmlspecialchars($ayarlar['facebook'] ?? ''); ?>">
                                </div>
                                <div class="col-md-6 mb-4">
                                    <label class="form-label">Instagram</label>
                                    <input type="text" name="instagram" class="form-control" value="<?php echo htmlspecialchars($ayarlar['instagram'] ?? ''); ?>">
                                </div>
                                <div class="col-12">
                                    <button type="submit" name="ayarlar_guncelle" class="btn-brand"><i class="fas fa-save me-2"></i>Kaydet</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="tab-pane fade" id="tab-blog">
                <div class="row">
                    <div class="col-lg-5">
                        <div class="card">
                            <div class="card-header">Yeni Blog Yazısı</div>
                            <div class="card-body">
                                <form method="POST" enctype="multipart/form-data">
                                    <div class="mb-3">
                                        <label class="form-label">Başlık</label>
                                        <input type="text" name="baslik" class="form-control" required>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Özet</label>
                                        <textarea name="ozet" class="form-control" rows="2"></textarea>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">İçerik</label>
                                        <textarea name="icerik" class="form-control" rows="5"></textarea>
                                    </div>
                                    <div class="mb-4">
                                        <label class="form-label">Görsel</label>
                                        <input type="file" name="gorsel" accept="image/*" class="form-control">
                                    </div>
                                    <button type="submit" name="blog_ekle" class="btn-brand w-100"><i class="fas fa-plus me-2"></i>Ekle</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-7">
                        <div class="card">
                            <div class="card-header">Blog Yazıları</div>
                            <div class="card-body p-0">
                                <table class="table mb-0">
                                    <thead>
                                        <tr>
                                            <th>Başlık</th>
                                            <th>Tarih</th>
                                            <th class="text-end">İşlem</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($bloglar as $blog): ?>
                                        <tr>
                                            <td class="fw-bold"><?php echo htmlspecialchars(substr($blog['baslik'], 0, 30)); ?></td>
                                            <td><small><?php echo date('d.m.Y', strtotime($blog['tarih'])); ?></small></td>
                                            <td class="text-end">
                                                <button class="btn-edit btn-sm" data-bs-toggle="modal" data-bs-target="#editBlog<?php echo $blog['id']; ?>"><i class="fas fa-edit"></i></button>
                                                <a href="?sil=<?php echo $blog['id']; ?>&tip=blog" class="btn-delete btn-sm" onclick="return confirm('Silmek istediğinize emin misiniz?');"><i class="fas fa-trash"></i></a>
                                            </td>
                                        </tr>

                                        <div class="modal fade" id="editBlog<?php echo $blog['id']; ?>">
                                            <div class="modal-dialog modal-lg">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Blog Düzenle</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <form method="POST" enctype="multipart/form-data">
                                                        <div class="modal-body">
                                                            <input type="hidden" name="id" value="<?php echo $blog['id']; ?>">
                                                            <input type="hidden" name="eski_gorsel" value="<?php echo htmlspecialchars($blog['gorsel']); ?>">
                                                            <div class="mb-3">
                                                                <label class="form-label">Başlık</label>
                                                                <input type="text" name="baslik" class="form-control" value="<?php echo htmlspecialchars($blog['baslik']); ?>" required>
                                                            </div>
                                                            <div class="mb-3">
                                                                <label class="form-label">Özet</label>
                                                                <textarea name="ozet" class="form-control" rows="2"><?php echo htmlspecialchars($blog['ozet']); ?></textarea>
                                                            </div>
                                                            <div class="mb-3">
                                                                <label class="form-label">İçerik</label>
                                                                <textarea name="icerik" class="form-control" rows="6"><?php echo htmlspecialchars($blog['icerik']); ?></textarea>
                                                            </div>
                                                            <div class="mb-3">
                                                                <label class="form-label">Görsel</label>
                                                                <input type="file" name="gorsel" accept="image/*" class="form-control">
                                                                <?php if ($blog['gorsel']): ?>
                                                                    <img src="<?php echo htmlspecialchars($blog['gorsel']); ?>" style="max-height: 100px; margin-top: 10px; border-radius: 6px;">
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="submit" name="blog_duzenle" class="btn-brand"><i class="fas fa-save me-2"></i>Güncelle</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="tab-pane fade" id="tab-hizmetler">
                <div class="row">
                    <div class="col-lg-5">
                        <div class="card">
                            <div class="card-header">Yeni Hizmet</div>
                            <div class="card-body">
                                <form method="POST">
                                    <div class="mb-3">
                                        <label class="form-label">Başlık</label>
                                        <input type="text" name="baslik" class="form-control" required>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Açıklama</label>
                                        <textarea name="aciklama" class="form-control" rows="3"></textarea>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Font Awesome İkon (örn: fa-leaf)</label>
                                        <input type="text" name="ikon" class="form-control" value="fa-leaf">
                                    </div>
                                    <div class="mb-4">
                                        <label class="form-label">Sıra Numarası</label>
                                        <input type="number" name="sira" class="form-control" value="0">
                                    </div>
                                    <button type="submit" name="hizmet_ekle" class="btn-brand w-100"><i class="fas fa-plus me-2"></i>Ekle</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-7">
                        <div class="card">
                            <div class="card-header">Hizmetler</div>
                            <div class="card-body p-0">
                                <table class="table mb-0">
                                    <thead>
                                        <tr>
                                            <th>İkon</th>
                                            <th>Başlık</th>
                                            <th>Sıra</th>
                                            <th class="text-end">İşlem</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($hizmetler as $hizmet): ?>
                                        <tr>
                                            <td><i class="fas <?php echo htmlspecialchars($hizmet['ikon']); ?> fa-lg" style="color: #10b981;"></i></td>
                                            <td class="fw-bold"><?php echo htmlspecialchars($hizmet['baslik']); ?></td>
                                            <td><small><?php echo htmlspecialchars($hizmet['sira']); ?></small></td>
                                            <td class="text-end">
                                                <button class="btn-edit btn-sm" data-bs-toggle="modal" data-bs-target="#editHizmet<?php echo $hizmet['id']; ?>"><i class="fas fa-edit"></i></button>
                                                <a href="?sil=<?php echo $hizmet['id']; ?>&tip=hizmet" class="btn-delete btn-sm" onclick="return confirm('Silmek istediğinize emin misiniz?');"><i class="fas fa-trash"></i></a>
                                            </td>
                                        </tr>

                                        <div class="modal fade" id="editHizmet<?php echo $hizmet['id']; ?>">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Hizmet Düzenle</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <form method="POST">
                                                        <div class="modal-body">
                                                            <input type="hidden" name="id" value="<?php echo $hizmet['id']; ?>">
                                                            <div class="mb-3">
                                                                <label class="form-label">Başlık</label>
                                                                <input type="text" name="baslik" class="form-control" value="<?php echo htmlspecialchars($hizmet['baslik']); ?>" required>
                                                            </div>
                                                            <div class="mb-3">
                                                                <label class="form-label">Açıklama</label>
                                                                <textarea name="aciklama" class="form-control" rows="3"><?php echo htmlspecialchars($hizmet['aciklama']); ?></textarea>
                                                            </div>
                                                            <div class="mb-3">
                                                                <label class="form-label">Font Awesome İkon</label>
                                                                <input type="text" name="ikon" class="form-control" value="<?php echo htmlspecialchars($hizmet['ikon']); ?>">
                                                            </div>
                                                            <div class="mb-3">
                                                                <label class="form-label">Sıra Numarası</label>
                                                                <input type="number" name="sira" class="form-control" value="<?php echo htmlspecialchars($hizmet['sira']); ?>">
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="submit" name="hizmet_duzenle" class="btn-brand"><i class="fas fa-save me-2"></i>Güncelle</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="tab-pane fade" id="tab-portfolyo">
                <div class="row">
                    <div class="col-lg-5">
                        <div class="card">
                            <div class="card-header">Yeni Proje</div>
                            <div class="card-body">
                                <form method="POST" enctype="multipart/form-data">
                                    <div class="mb-3">
                                        <label class="form-label">Proje Başlığı</label>
                                        <input type="text" name="baslik" class="form-control" required>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Kategori</label>
                                        <input type="text" name="kategori" class="form-control" placeholder="Örn: Peyzaj Tasarımı">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Proje Görseli</label>
                                        <input type="file" name="gorsel" accept="image/*" class="form-control" required>
                                    </div>
                                    <div class="mb-4">
                                        <label class="form-label">Sıra Numarası</label>
                                        <input type="number" name="sira" class="form-control" value="0">
                                    </div>
                                    <button type="submit" name="portfolyo_ekle" class="btn-brand w-100"><i class="fas fa-plus me-2"></i>Ekle</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-7">
                        <div class="card">
                            <div class="card-header">Projeler</div>
                            <div class="card-body p-0">
                                <table class="table mb-0">
                                    <thead>
                                        <tr>
                                            <th>Başlık</th>
                                            <th>Kategori</th>
                                            <th>Sıra</th>
                                            <th class="text-end">İşlem</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($portfolyo as $proje): ?>
                                        <tr>
                                            <td class="fw-bold"><?php echo htmlspecialchars(substr($proje['baslik'], 0, 20)); ?></td>
                                            <td><?php echo htmlspecialchars($proje['kategori']); ?></td>
                                            <td><small><?php echo htmlspecialchars($proje['sira']); ?></small></td>
                                            <td class="text-end">
                                                <button class="btn-edit btn-sm" data-bs-toggle="modal" data-bs-target="#editPort<?php echo $proje['id']; ?>"><i class="fas fa-edit"></i></button>
                                                <a href="?sil=<?php echo $proje['id']; ?>&tip=portfolyo" class="btn-delete btn-sm" onclick="return confirm('Silmek istediğinize emin misiniz?');"><i class="fas fa-trash"></i></a>
                                            </td>
                                        </tr>

                                        <div class="modal fade" id="editPort<?php echo $proje['id']; ?>">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Proje Düzenle</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <form method="POST" enctype="multipart/form-data">
                                                        <div class="modal-body">
                                                            <input type="hidden" name="id" value="<?php echo $proje['id']; ?>">
                                                            <input type="hidden" name="eski_gorsel" value="<?php echo htmlspecialchars($proje['gorsel']); ?>">
                                                            <div class="mb-3">
                                                                <label class="form-label">Başlık</label>
                                                                <input type="text" name="baslik" class="form-control" value="<?php echo htmlspecialchars($proje['baslik']); ?>" required>
                                                            </div>
                                                            <div class="mb-3">
                                                                <label class="form-label">Kategori</label>
                                                                <input type="text" name="kategori" class="form-control" value="<?php echo htmlspecialchars($proje['kategori']); ?>">
                                                            </div>
                                                            <div class="mb-3">
                                                                <label class="form-label">Görsel Değiştir</label>
                                                                <input type="file" name="gorsel" accept="image/*" class="form-control">
                                                                <?php if ($proje['gorsel']): ?>
                                                                    <img src="<?php echo htmlspecialchars($proje['gorsel']); ?>" style="max-height: 100px; margin-top: 10px; border-radius: 6px;">
                                                                <?php endif; ?>
                                                            </div>
                                                            <div class="mb-3">
                                                                <label class="form-label">Sıra</label>
                                                                <input type="number" name="sira" class="form-control" value="<?php echo htmlspecialchars($proje['sira']); ?>">
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="submit" name="portfolyo_duzenle" class="btn-brand"><i class="fas fa-save me-2"></i>Güncelle</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="tab-pane fade" id="tab-talepler">
                <div class="card">
                    <div class="card-header">Gelen Talepler</div>
                    <div class="card-body p-0">
                        <table class="table mb-0">
                            <thead>
                                <tr>
                                    <th>Ad Soyad</th>
                                    <th>Telefon</th>
                                    <th>Hizmet</th>
                                    <th>Durum</th>
                                    <th class="text-end">İşlem</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($talepler as $talep): ?>
                                <tr>
                                    <td class="fw-bold"><?php echo htmlspecialchars($talep['ad_soyad']); ?></td>
                                    <td><?php echo htmlspecialchars($talep['telefon']); ?></td>
                                    <td><small><?php echo htmlspecialchars($talep['hizmet'] ?? 'Belirtilmemiş'); ?></small></td>
                                    <td>
                                        <span class="badge badge-<?php 
                                            echo $talep['durum'] === 'Cevaplandi' ? 'success' : 
                                                ($talep['durum'] === 'Okundu' ? 'warning' : 'danger'); 
                                        ?>">
                                            <?php echo htmlspecialchars($talep['durum']); ?>
                                        </span>
                                    </td>
                                    <td class="text-end">
                                        <button class="btn-edit btn-sm" data-bs-toggle="modal" data-bs-target="#viewTalep<?php echo $talep['id']; ?>"><i class="fas fa-eye"></i></button>
                                        <a href="?sil=<?php echo $talep['id']; ?>&tip=talep" class="btn-delete btn-sm" onclick="return confirm('Silmek istediğinize emin misiniz?');"><i class="fas fa-trash"></i></a>
                                    </td>
                                </tr>

                                <div class="modal fade" id="viewTalep<?php echo $talep['id']; ?>">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Talep Detayı</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <p><strong>Ad Soyad:</strong> <?php echo htmlspecialchars($talep['ad_soyad']); ?></p>
                                                <p><strong>Telefon:</strong> <?php echo htmlspecialchars($talep['telefon']); ?></p>
                                                <p><strong>Hizmet:</strong> <?php echo htmlspecialchars($talep['hizmet'] ?? 'Belirtilmemiş'); ?></p>
                                                <p><strong>Alan (m²):</strong> <?php echo htmlspecialchars($talep['alan_m2'] ?? 'Belirtilmemiş'); ?></p>
                                                <p><strong>Tarih:</strong> <?php echo date('d.m.Y H:i', strtotime($talep['tarih'])); ?></p>
                                                <p><strong>Mesaj:</strong></p>
                                                <p><?php echo nl2br(htmlspecialchars($talep['mesaj'])); ?></p>
                                                <form method="POST" class="mt-3">
                                                    <input type="hidden" name="id" value="<?php echo $talep['id']; ?>">
                                                    <label class="form-label">Durum Güncelle</label>
                                                    <div class="input-group">
                                                        <select name="yeni_durum" class="form-select">
                                                            <option value="Bekliyor" <?php echo $talep['durum'] === 'Bekliyor' ? 'selected' : ''; ?>>Bekliyor</option>
                                                            <option value="Okundu" <?php echo $talep['durum'] === 'Okundu' ? 'selected' : ''; ?>>Okundu</option>
                                                            <option value="Cevaplandi" <?php echo $talep['durum'] === 'Cevaplandi' ? 'selected' : ''; ?>>Cevaplandı</option>
                                                        </select>
                                                        <button type="submit" name="talep_durum" class="btn btn-brand">Güncelle</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.getElementById('sidebarToggle')?.addEventListener('click', function() {
            document.getElementById('sidebar').classList.toggle('active');
        });
        
        document.addEventListener('click', function(event) {
            if (!event.target.closest('.sidebar') && !event.target.closest('#sidebarToggle')) {
                document.getElementById('sidebar').classList.remove('active');
            }
        });
    </script>
</body>
</html>
