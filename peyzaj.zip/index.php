<?php
require 'config.php';

try {
    $db->exec("CREATE TABLE IF NOT EXISTS peyzaj_ayarlar (
        id INT AUTO_INCREMENT PRIMARY KEY,
        site_baslik VARCHAR(255) DEFAULT 'Doğa Peyzaj & Bahçe Düzenleme',
        site_aciklama TEXT,
        telefon VARCHAR(50) DEFAULT '+90 500 000 00 00',
        eposta VARCHAR(100) DEFAULT 'info@dogapeyzaj.com',
        adres TEXT,
        whatsapp VARCHAR(50) DEFAULT '905000000000',
        hero_baslik VARCHAR(255) DEFAULT 'Hayalinizdeki Bahçeyi Birlikte Tasarlıyoruz',
        hero_alt_baslik TEXT DEFAULT 'Uzman ekibimizle doğanın estetiğini yaşam alanlarınıza taşıyoruz. Profesyonel peyzaj, otomatik sulama ve bahçe bakım hizmetleri.',
        hakkimizda TEXT,
        facebook VARCHAR(255),
        instagram VARCHAR(255)
    )");

    $ayarCheck = $db->query("SELECT COUNT(*) FROM peyzaj_ayarlar")->fetchColumn();
    if ($ayarCheck == 0) {
        $db->exec("INSERT INTO peyzaj_ayarlar (site_baslik) VALUES ('Doğa Peyzaj')");
    }

    @$db->exec("UPDATE peyzaj_ayarlar SET telefon = '+90 500 000 00 00', whatsapp = '905000000000' WHERE telefon = '+90 555 123 45 67'");

    $db->exec("CREATE TABLE IF NOT EXISTS peyzaj_hizmetler (
        id INT AUTO_INCREMENT PRIMARY KEY,
        baslik VARCHAR(255) NOT NULL,
        aciklama TEXT,
        ikon VARCHAR(100) DEFAULT 'fa-leaf',
        sira INT DEFAULT 0
    )");

    $db->exec("CREATE TABLE IF NOT EXISTS peyzaj_portfolyo (
        id INT AUTO_INCREMENT PRIMARY KEY,
        baslik VARCHAR(255) NOT NULL,
        gorsel VARCHAR(255),
        kategori VARCHAR(100) DEFAULT 'Genel',
        sira INT DEFAULT 0
    )");

    $db->exec("CREATE TABLE IF NOT EXISTS peyzaj_talepler (
        id INT AUTO_INCREMENT PRIMARY KEY,
        ad_soyad VARCHAR(100) NOT NULL,
        telefon VARCHAR(50) NOT NULL,
        hizmet VARCHAR(100),
        alan_m2 VARCHAR(50),
        mesaj TEXT,
        tarih TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        durum ENUM('Bekliyor', 'Okundu', 'Cevaplandi') DEFAULT 'Bekliyor'
    )");

    @$db->exec("ALTER TABLE peyzaj_ayarlar ADD COLUMN hero_gorsel VARCHAR(255) DEFAULT 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&w=1000&q=80'");
    @$db->exec("ALTER TABLE peyzaj_ayarlar ADD COLUMN hakkimizda_baslik VARCHAR(255) DEFAULT 'Doğayı Yaşam Alanlarınıza Sanatla Taşıyoruz'");
    @$db->exec("ALTER TABLE peyzaj_ayarlar ADD COLUMN hakkimizda_icerik TEXT");
    @$db->exec("ALTER TABLE peyzaj_ayarlar ADD COLUMN hakkimizda_gorsel VARCHAR(255) DEFAULT 'https://images.unsplash.com/photo-1558904541-efa843a96f09?auto=format&fit=crop&w=800&q=80'");
    @$db->exec("ALTER TABLE peyzaj_ayarlar ADD COLUMN stat_1_sayi VARCHAR(50) DEFAULT '15+'");
    @$db->exec("ALTER TABLE peyzaj_ayarlar ADD COLUMN stat_1_metin VARCHAR(100) DEFAULT 'Yıllık Tecrübe'");
    @$db->exec("ALTER TABLE peyzaj_ayarlar ADD COLUMN stat_2_sayi VARCHAR(50) DEFAULT '500+'");
    @$db->exec("ALTER TABLE peyzaj_ayarlar ADD COLUMN stat_2_metin VARCHAR(100) DEFAULT 'Mutlu Müşteri'");
    @$db->exec("ALTER TABLE peyzaj_ayarlar ADD COLUMN stat_3_sayi VARCHAR(50) DEFAULT '1200+'");
    @$db->exec("ALTER TABLE peyzaj_ayarlar ADD COLUMN stat_3_metin VARCHAR(100) DEFAULT 'Tamamlanan Proje'");
    @$db->exec("ALTER TABLE peyzaj_ayarlar ADD COLUMN stat_4_sayi VARCHAR(50) DEFAULT '%100'");
    @$db->exec("ALTER TABLE peyzaj_ayarlar ADD COLUMN stat_4_metin VARCHAR(100) DEFAULT 'Müşteri Memnuniyeti'");
} catch (Exception $e) {}

$ayarlar = $db->query("SELECT * FROM peyzaj_ayarlar LIMIT 1")->fetch(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['teklif_gonder'])) {
    $ekle = $db->prepare("INSERT INTO peyzaj_talepler (ad_soyad, telefon, hizmet, alan_m2, mesaj) VALUES (?, ?, ?, ?, ?)");
    $ekle->execute([$_POST['ad_soyad'], $_POST['telefon'], $_POST['hizmet'], $_POST['alan_m2'], $_POST['mesaj']]);
    $mesaj_basarili = true;
}

$hizmetler = [];
try { $hizmetler = $db->query("SELECT * FROM peyzaj_hizmetler ORDER BY sira ASC")->fetchAll(); } catch(Exception $e) {}

$portfolyo = [];
try { $portfolyo = $db->query("SELECT * FROM peyzaj_portfolyo ORDER BY sira ASC")->fetchAll(); } catch(Exception $e) {}

$hak_icerik = !empty($ayarlar['hakkimizda_icerik']) ? $ayarlar['hakkimizda_icerik'] : "Yılların getirdiği tecrübe ve doğaya olan tutkumuzla, hayalinizdeki bahçeleri gerçeğe dönüştürüyoruz. Modern peyzaj mimarlığı ilkelerini, sizin isteklerinizle harmanlayarak estetik, kullanışlı ve sürdürülebilir yaşam alanları tasarlıyoruz.\n\nAmacımız sadece ağaç dikmek değil, ailenizle huzurla vakit geçirebileceğiniz bir ekosistem yaratmaktır. Kaliteli malzeme, titiz işçilik ve zamanında teslimat prensibimizle her zaman yanınızdayız.";
?>
<!DOCTYPE html>
<html lang="tr" style="scroll-behavior: smooth;">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($ayarlar['site_baslik']) ?></title>
    <meta name="description" content="<?= htmlspecialchars($ayarlar['site_aciklama']) ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap');
        
        :root {
            --primary: #059669;
            --primary-dark: #047857;
            --primary-light: #34d399;
            --accent: #f59e0b;
            --bg-light: #f8fafc;
            --text-dark: #0f172a;
            --text-muted: #64748b;
        }

        body {
            font-family: 'Outfit', sans-serif;
            background-color: var(--bg-light);
            color: var(--text-dark);
            overflow-x: hidden;
        }

        .reveal {
            opacity: 0;
            transform: translateY(40px);
            transition: all 0.8s cubic-bezier(0.16, 1, 0.3, 1);
        }
        .reveal.active {
            opacity: 1;
            transform: translateY(0);
        }

        .navbar {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(15px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.03);
            padding: 15px 0;
            transition: all 0.4s;
        }

        .navbar-brand {
            font-weight: 800;
            font-size: 1.8rem;
            color: var(--primary) !important;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .nav-link {
            font-weight: 600;
            color: var(--text-dark) !important;
            padding: 10px 18px !important;
            transition: all 0.3s;
            position: relative;
        }

        .nav-link::after {
            content: '';
            position: absolute;
            bottom: 5px; left: 18px; right: 18px;
            height: 2px;
            background: var(--primary);
            transform: scaleX(0);
            transition: transform 0.3s ease;
        }

        .nav-link:hover::after {
            transform: scaleX(1);
        }

        .btn-call {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: #fff !important;
            border-radius: 50px;
            padding: 12px 28px !important;
            font-weight: 700;
            box-shadow: 0 10px 25px rgba(5, 150, 105, 0.3);
            transition: all 0.3s;
            border: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        .btn-call:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 35px rgba(5, 150, 105, 0.4);
            color: #fff !important;
        }
        
        .btn-login-nav {
            color: var(--text-muted);
            border: 2px solid #e2e8f0;
            border-radius: 50px;
            padding: 10px 22px;
            font-weight: 700;
            text-decoration: none;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            background: transparent;
        }
        
        .btn-login-nav:hover {
            border-color: var(--primary);
            color: var(--primary);
            background: rgba(5, 150, 105, 0.05);
        }

        .hero-section {
            padding: 180px 0 120px;
            background: linear-gradient(135deg, #ecfdf5 0%, #f1f5f9 100%);
            position: relative;
            overflow: hidden;
        }

        .hero-section::before {
            content: '';
            position: absolute;
            width: 800px;
            height: 800px;
            background: radial-gradient(circle, rgba(16, 185, 129, 0.1) 0%, transparent 70%);
            top: -200px;
            right: -200px;
            border-radius: 50%;
            z-index: 0;
        }

        .hero-badge {
            background: rgba(5, 150, 105, 0.1);
            color: var(--primary-dark);
            padding: 10px 24px;
            border-radius: 50px;
            font-weight: 700;
            font-size: 0.95rem;
            display: inline-block;
            margin-bottom: 25px;
            border: 1px solid rgba(5, 150, 105, 0.2);
            position: relative;
            z-index: 1;
        }

        .hero-title {
            font-size: clamp(2.5rem, 5vw, 4.5rem);
            font-weight: 800;
            color: var(--text-dark);
            line-height: 1.15;
            margin-bottom: 25px;
            letter-spacing: -1.5px;
            position: relative;
            z-index: 1;
        }

        .hero-title span {
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .hero-desc {
            font-size: 1.25rem;
            color: var(--text-muted);
            margin-bottom: 40px;
            line-height: 1.7;
            position: relative;
            z-index: 1;
        }

        .hero-img-box {
            position: relative;
            z-index: 1;
        }

        .hero-img {
            width: 100%;
            border-radius: 40px;
            box-shadow: 0 30px 60px rgba(5, 150, 105, 0.15);
            border: 12px solid #fff;
            transform: rotate(3deg);
            transition: all 0.6s cubic-bezier(0.16, 1, 0.3, 1);
        }

        .hero-img:hover {
            transform: rotate(0deg) scale(1.03);
            box-shadow: 0 40px 80px rgba(5, 150, 105, 0.25);
        }

        .stats-wrapper {
            background: #fff;
            border-radius: 30px;
            padding: 40px;
            box-shadow: 0 20px 50px rgba(0,0,0,0.04);
            margin-top: -60px;
            position: relative;
            z-index: 10;
        }

        .stat-item h3 {
            font-size: 2.5rem;
            font-weight: 800;
            color: var(--primary);
            margin-bottom: 5px;
        }

        .stat-item p {
            font-weight: 600;
            color: var(--text-muted);
            margin: 0;
            text-transform: uppercase;
            font-size: 0.9rem;
            letter-spacing: 1px;
        }

        .section-padding { padding: 120px 0; }

        .section-title {
            font-size: clamp(2rem, 4vw, 3rem);
            font-weight: 800;
            margin-bottom: 1.5rem;
            color: var(--text-dark);
            letter-spacing: -1px;
        }

        .section-subtitle {
            color: var(--primary);
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 3px;
            margin-bottom: 15px;
            display: inline-block;
            background: rgba(5, 150, 105, 0.1);
            padding: 8px 20px;
            border-radius: 50px;
        }

        .about-img {
            width: 100%;
            border-radius: 30px;
            box-shadow: 0 20px 50px rgba(0,0,0,0.1);
            position: relative;
            z-index: 1;
        }

        .about-badge {
            position: absolute;
            bottom: -30px;
            right: -30px;
            background: var(--primary);
            color: #fff;
            padding: 30px;
            border-radius: 24px;
            box-shadow: 0 15px 30px rgba(5, 150, 105, 0.3);
            z-index: 2;
            text-align: center;
            border: 5px solid #fff;
        }

        .service-card {
            background: #fff;
            border-radius: 30px;
            padding: 45px 35px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.03);
            border: 1px solid rgba(0,0,0,0.03);
            transition: all 0.5s cubic-bezier(0.16, 1, 0.3, 1);
            height: 100%;
            position: relative;
            overflow: hidden;
            z-index: 1;
        }

        .service-card::before {
            content: '';
            position: absolute;
            top: 0; left: 0; width: 100%; height: 100%;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            clip-path: circle(0% at 100% 100%);
            transition: all 0.6s cubic-bezier(0.16, 1, 0.3, 1);
            z-index: -1;
        }

        .service-card:hover {
            transform: translateY(-15px);
            box-shadow: 0 25px 50px rgba(5, 150, 105, 0.2);
            border-color: transparent;
        }

        .service-card:hover::before {
            clip-path: circle(150% at 100% 100%);
        }

        .service-icon {
            width: 80px;
            height: 80px;
            background: rgba(5, 150, 105, 0.1);
            color: var(--primary);
            border-radius: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2.2rem;
            margin-bottom: 30px;
            transition: all 0.5s;
        }

        .service-card:hover .service-icon {
            background: rgba(255,255,255,0.2);
            color: #fff;
            transform: scale(1.1) rotate(-10deg);
        }

        .service-card h4 {
            font-weight: 800;
            font-size: 1.5rem;
            margin-bottom: 15px;
            transition: all 0.4s;
        }

        .service-card p {
            color: var(--text-muted);
            line-height: 1.7;
            margin: 0;
            transition: all 0.4s;
        }

        .service-card:hover h4, .service-card:hover p {
            color: #fff;
        }

        .portfolio-card {
            border-radius: 24px;
            overflow: hidden;
            position: relative;
            box-shadow: 0 15px 35px rgba(0,0,0,0.06);
            cursor: pointer;
            aspect-ratio: 4/3;
        }

        .portfolio-img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: all 0.7s cubic-bezier(0.16, 1, 0.3, 1);
        }

        .portfolio-card:hover .portfolio-img {
            transform: scale(1.1) rotate(2deg);
        }

        .portfolio-overlay {
            position: absolute;
            inset: 0;
            background: linear-gradient(to top, rgba(15, 23, 42, 0.9), rgba(15, 23, 42, 0.2));
            padding: 40px 30px;
            display: flex;
            flex-direction: column;
            justify-content: flex-end;
            opacity: 0;
            transition: all 0.5s;
        }

        .portfolio-card:hover .portfolio-overlay {
            opacity: 1;
        }

        .portfolio-overlay .badge {
            background: var(--primary);
            align-self: flex-start;
            padding: 8px 16px;
            font-size: 0.85rem;
            margin-bottom: 15px;
            transform: translateY(20px);
            transition: all 0.5s 0.1s;
            opacity: 0;
        }

        .portfolio-overlay h5 {
            color: #fff;
            font-size: 1.5rem;
            font-weight: 700;
            transform: translateY(20px);
            transition: all 0.5s 0.2s;
            opacity: 0;
        }

        .portfolio-card:hover .portfolio-overlay .badge,
        .portfolio-card:hover .portfolio-overlay h5 {
            transform: translateY(0);
            opacity: 1;
        }

        .quote-wrapper {
            background: #fff;
            border-radius: 40px;
            box-shadow: 0 30px 60px rgba(0,0,0,0.05);
            overflow: hidden;
        }

        .quote-bg {
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
            padding: 60px;
            color: #fff;
            height: 100%;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .form-control, .form-select {
            background: var(--bg-light);
            border: 2px solid transparent;
            padding: 16px 24px;
            border-radius: 16px;
            font-weight: 500;
            color: var(--text-dark);
            transition: all 0.3s;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 5px rgba(5, 150, 105, 0.1);
            background: #fff;
        }

        .btn-submit {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: #fff;
            border: none;
            padding: 18px 30px;
            border-radius: 16px;
            font-weight: 800;
            font-size: 1.15rem;
            width: 100%;
            box-shadow: 0 10px 25px rgba(5, 150, 105, 0.3);
            transition: all 0.3s;
        }

        .btn-submit:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 35px rgba(5, 150, 105, 0.5);
        }

        .whatsapp-float {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 65px;
            height: 65px;
            background-color: #25d366;
            color: #FFF;
            border-radius: 50px;
            text-align: center;
            font-size: 35px;
            box-shadow: 0 15px 30px rgba(37, 211, 102, 0.4);
            z-index: 1000;
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            transition: all 0.3s;
            animation: pulse-wa 2s infinite;
        }

        .whatsapp-float:hover {
            background-color: #128c7e;
            color: #fff;
            transform: scale(1.1);
        }

        @keyframes pulse-wa {
            0% { box-shadow: 0 0 0 0 rgba(37, 211, 102, 0.5); }
            70% { box-shadow: 0 0 0 20px rgba(37, 211, 102, 0); }
            100% { box-shadow: 0 0 0 0 rgba(37, 211, 102, 0); }
        }

        footer {
            background: #0f172a;
            color: #94a3b8;
            padding: 80px 0 30px;
        }

        .footer-brand {
            color: #fff;
            font-size: 2rem;
            font-weight: 800;
            margin-bottom: 25px;
            display: inline-block;
            text-decoration: none;
        }

        .footer-brand i { color: var(--primary); }

        .social-circle {
            width: 45px; height: 45px;
            background: rgba(255,255,255,0.05);
            display: inline-flex; align-items: center; justify-content: center;
            border-radius: 50%; color: #fff;
            transition: all 0.3s; text-decoration: none;
        }
        .social-circle:hover { background: var(--primary); transform: translateY(-3px); color: #fff; }

        @media (max-width: 991px) {
            .hero-section { padding: 130px 0 80px; text-align: center; }
            .hero-img { margin-top: 50px; }
            .stats-wrapper { margin-top: 30px; padding: 30px; }
            .about-badge { right: auto; left: 50%; transform: translateX(-50%); bottom: -20px; width: 80%; }
            .btn-login-nav { justify-content: center; margin-bottom: 10px; }
        }
    </style>
</head>
<body>

    <nav class="navbar navbar-expand-lg fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#"><i class="fa-solid fa-leaf"></i> <?= htmlspecialchars($ayarlar['site_baslik'] ?? 'Doğa Peyzaj') ?></a>
            <button class="navbar-toggler border-0 shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item"><a class="nav-link" href="#hakkimizda">Hakkımızda</a></li>
                    <li class="nav-item"><a class="nav-link" href="#hizmetler">Hizmetler</a></li>
                    <li class="nav-item"><a class="nav-link" href="#projeler">Portfolyo</a></li>
                    <li class="nav-item"><a class="nav-link" href="#iletisim">İletişim</a></li>
                </ul>
                <div class="d-flex flex-column flex-lg-row align-items-lg-center gap-2 mt-3 mt-lg-0">
                    <a href="login.php" class="btn-login-nav" title="Yönetim Paneli Girişi">
                        <i class="fa-solid fa-lock me-2"></i> Giriş
                    </a>
                    <button type="button" class="btn btn-call" data-bs-toggle="modal" data-bs-target="#callConfirmModal">
                        <i class="fa-solid fa-phone-volume me-2"></i> Keşif İste
                    </button>
                </div>
            </div>
        </div>
    </nav>

    <div class="modal fade" id="callConfirmModal" tabindex="-1" aria-labelledby="callConfirmModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered px-3">
            <div class="modal-content" style="border-radius: 24px; border: none; box-shadow: 0 20px 50px rgba(5, 150, 105, 0.2);">
                <div class="modal-body text-center py-5 px-4">
                    <div class="bg-light rounded-circle d-inline-flex align-items-center justify-content-center mb-4" style="width: 80px; height: 80px;">
                        <i class="fa-solid fa-phone-volume fa-3x" style="color: var(--primary);"></i>
                    </div>
                    <h4 class="fw-bold mb-3 text-dark">Arama Yapılsın mı?</h4>
                    <p class="text-muted mb-4 fs-6">Şimdi <strong><?= htmlspecialchars($ayarlar['telefon'] ?? '+90 500 000 00 00') ?></strong> numaralı hattı aramak üzeresiniz. Devam etmek istiyor musunuz?</p>

                    <div class="d-flex justify-content-center gap-3 flex-wrap">
                        <button type="button" class="btn btn-light px-4 py-2 rounded-pill fw-bold" data-bs-dismiss="modal" style="color: var(--text-muted);">Vazgeç</button>
                        <a href="tel:<?= htmlspecialchars($ayarlar['telefon'] ?? '+90 500 000 00 00') ?>" class="btn btn-call px-4 py-2 rounded-pill fw-bold" style="padding: 10px 24px !important;">Evet, Ara <i class="fa-solid fa-arrow-right ms-2"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php if(isset($mesaj_basarili)): ?>
        <div class="position-fixed top-0 start-50 translate-middle-x p-3" style="z-index: 9999; margin-top: 90px;">
            <div class="alert alert-success shadow-lg border-0 rounded-4 fw-bold px-4 py-3" style="background: var(--primary); color:#fff;">
                <i class="fa-solid fa-circle-check me-2 fs-5"></i> Talebiniz başarıyla alındı! En kısa sürede dönüş yapacağız.
            </div>
        </div>
        <script>setTimeout(() => { document.querySelector('.alert').style.display='none'; }, 4000);</script>
    <?php endif; ?>

    <section class="hero-section">
        <div class="container">
            <div class="row align-items-center g-5">
                <div class="col-lg-6 reveal">
                    <div class="hero-badge"><i class="fa-solid fa-seedling me-2"></i> Profesyonel Peyzaj Mimarisi</div>
                    <h1 class="hero-title"><?= htmlspecialchars($ayarlar['hero_baslik'] ?? 'Hayalinizdeki Bahçeyi Birlikte Tasarlıyoruz') ?></h1>
                    <p class="hero-desc"><?= htmlspecialchars($ayarlar['hero_alt_baslik'] ?? 'Uzman ekibimizle doğanın estetiğini yaşam alanlarınıza taşıyoruz.') ?></p>
                    <div class="d-flex gap-3 justify-content-center justify-content-lg-start flex-wrap">
                        <a href="#iletisim" class="btn btn-call" style="padding: 16px 35px !important; font-size: 1.1rem;">Ücretsiz Fiyat Al</a>
                        <a href="#projeler" class="btn btn-light rounded-pill fw-bold" style="padding: 16px 35px; box-shadow: 0 10px 20px rgba(0,0,0,0.05); color: var(--text-dark); border: 2px solid transparent;">Çalışmalarımız</a>
                    </div>
                </div>
                <div class="col-lg-6 reveal" style="transition-delay: 0.2s;">
                    <div class="hero-img-box">
                        <img src="<?= htmlspecialchars($ayarlar['hero_gorsel'] ?? 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&w=1000&q=80') ?>" alt="Peyzaj Tasarımı" class="hero-img">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="container">
        <div class="stats-wrapper reveal">
            <div class="row g-4 text-center">
                <div class="col-6 col-md-3 stat-item border-end">
                    <h3><?= htmlspecialchars($ayarlar['stat_1_sayi'] ?? '15+') ?></h3>
                    <p><?= htmlspecialchars($ayarlar['stat_1_metin'] ?? 'Yıllık Tecrübe') ?></p>
                </div>
                <div class="col-6 col-md-3 stat-item border-end d-none d-md-block">
                    <h3><?= htmlspecialchars($ayarlar['stat_2_sayi'] ?? '500+') ?></h3>
                    <p><?= htmlspecialchars($ayarlar['stat_2_metin'] ?? 'Mutlu Müşteri') ?></p>
                </div>
                <div class="col-6 col-md-3 stat-item border-end d-none d-md-block">
                    <h3><?= htmlspecialchars($ayarlar['stat_3_sayi'] ?? '1200+') ?></h3>
                    <p><?= htmlspecialchars($ayarlar['stat_3_metin'] ?? 'Proje') ?></p>
                </div>
                <div class="col-6 col-md-3 stat-item">
                    <h3><?= htmlspecialchars($ayarlar['stat_4_sayi'] ?? '%100') ?></h3>
                    <p><?= htmlspecialchars($ayarlar['stat_4_metin'] ?? 'Memnuniyet') ?></p>
                </div>
            </div>
        </div>
    </div>

    <section id="hakkimizda" class="section-padding">
        <div class="container">
            <div class="row align-items-center g-5">
                <div class="col-lg-6 reveal pe-lg-5">
                    <div class="position-relative">
                        <img src="<?= htmlspecialchars($ayarlar['hakkimizda_gorsel'] ?? 'https://images.unsplash.com/photo-1558904541-efa843a96f09?auto=format&fit=crop&w=800&q=80') ?>" class="about-img" alt="Hakkımızda">
                        <div class="about-badge d-none d-md-block">
                            <i class="fa-solid fa-leaf fs-1 mb-2"></i>
                            <h4 class="fw-bold mb-0">Doğayla İç İçe</h4>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 reveal" style="transition-delay: 0.2s;">
                    <span class="section-subtitle">Hakkımızda</span>
                    <h2 class="section-title"><?= htmlspecialchars($ayarlar['hakkimizda_baslik'] ?? 'Doğayı Yaşam Alanlarınıza Sanatla Taşıyoruz') ?></h2>
                    <div class="text-muted fs-5" style="line-height: 1.8;">
                        <?= nl2br(htmlspecialchars($hak_icerik)) ?>
                    </div>
                    <ul class="list-unstyled mt-4 fs-5 fw-medium">
                        <li class="mb-3"><i class="fa-solid fa-check text-primary me-3 fs-4"></i> Ücretsiz Keşif ve Projelendirme</li>
                        <li class="mb-3"><i class="fa-solid fa-check text-primary me-3 fs-4"></i> Alanında Uzman Ziraat ve Peyzaj Mimarları</li>
                        <li><i class="fa-solid fa-check text-primary me-3 fs-4"></i> Kaliteli Malzeme, Garantili İşçilik</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <section id="hizmetler" class="section-padding bg-white">
        <div class="container">
            <div class="text-center reveal mb-5">
                <span class="section-subtitle">Uzmanlık Alanlarımız</span>
                <h2 class="section-title">Profesyonel Hizmetlerimiz</h2>
            </div>
            
            <div class="row g-4">
                <?php if(empty($hizmetler)): ?>
                    <div class="col-12 text-center text-muted py-5">Henüz hizmet eklenmemiş.</div>
                <?php else: ?>
                    <?php foreach($hizmetler as $index => $hizmet): ?>
                    <div class="col-md-6 col-lg-4 reveal" style="transition-delay: <?= ($index % 3) * 0.1 ?>s;">
                        <div class="service-card">
                            <div class="service-icon">
                                <i class="fa-solid <?= htmlspecialchars($hizmet['ikon']) ?>"></i>
                            </div>
                            <h4><?= htmlspecialchars($hizmet['baslik']) ?></h4>
                            <p><?= htmlspecialchars($hizmet['aciklama']) ?></p>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <section id="projeler" class="section-padding">
        <div class="container">
            <div class="d-flex justify-content-between align-items-end reveal mb-5 flex-wrap gap-3">
                <div>
                    <span class="section-subtitle">Sanatımız</span>
                    <h2 class="section-title mb-0">Tamamlanan Projeler</h2>
                </div>
                <a href="#iletisim" class="btn btn-outline-dark rounded-pill px-4 py-2 fw-bold border-2">Sıradaki Proje Sizin Olsun <i class="fa-solid fa-arrow-right ms-2"></i></a>
            </div>

            <div class="row g-4">
                <?php if(empty($portfolyo)): ?>
                    <div class="col-12 text-center text-muted py-5">Henüz proje eklenmemiş.</div>
                <?php else: ?>
                    <?php foreach($portfolyo as $index => $proje): ?>
                    <div class="col-md-6 col-lg-4 reveal" style="transition-delay: <?= ($index % 3) * 0.1 ?>s;">
                        <div class="portfolio-card">
                            <img src="<?= htmlspecialchars($proje['gorsel']) ?>" class="portfolio-img" alt="<?= htmlspecialchars($proje['baslik']) ?>">
                            <div class="portfolio-overlay">
                                <span class="badge"><?= htmlspecialchars($proje['kategori']) ?></span>
                                <h5><?= htmlspecialchars($proje['baslik']) ?></h5>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <section id="iletisim" class="section-padding bg-white">
        <div class="container">
            <div class="quote-wrapper reveal">
                <div class="row g-0">
                    <div class="col-lg-5">
                        <div class="quote-bg">
                            <h2 class="fw-bold mb-4 fs-1">Hayallerinizi Ertelemeyin!</h2>
                            <p class="fs-5 mb-5 opacity-75">Bahçenizin ölçülerini ve aklınızdaki tasarımı bizimle paylaşın. Uzman peyzaj mimarlarımız alanınızı inceleyip size en uygun projeyi ücretsiz sunsun.</p>
                            
                            <div class="d-flex align-items-center gap-4 mb-4">
                                <div class="bg-white bg-opacity-25 p-4 rounded-circle"><i class="fa-solid fa-phone-volume fs-3"></i></div>
                                <div>
                                    <small class="d-block text-uppercase fw-bold opacity-75 letter-spacing-1">Hemen Arayın</small>
                                    <a href="tel:<?= htmlspecialchars($ayarlar['telefon'] ?? '+90 500 000 00 00') ?>" class="fs-3 fw-bold text-white text-decoration-none"><?= htmlspecialchars($ayarlar['telefon'] ?? '+90 500 000 00 00') ?></a>
                                </div>
                            </div>
                            <div class="d-flex align-items-center gap-4">
                                <div class="bg-white bg-opacity-25 p-4 rounded-circle"><i class="fa-solid fa-envelope fs-3"></i></div>
                                <div>
                                    <small class="d-block text-uppercase fw-bold opacity-75 letter-spacing-1">E-Posta Gönderin</small>
                                    <a href="mailto:<?= htmlspecialchars($ayarlar['eposta'] ?? 'info@dogapeyzaj.com') ?>" class="fs-4 fw-bold text-white text-decoration-none"><?= htmlspecialchars($ayarlar['eposta'] ?? 'info@dogapeyzaj.com') ?></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-7 p-4 p-md-5 bg-white">
                        <h3 class="fw-bold mb-4 text-dark">Ücretsiz Keşif Formu</h3>
                        <form method="POST">
                            <div class="row g-4">
                                <div class="col-md-6">
                                    <label class="form-label">Adınız Soyadınız</label>
                                    <input type="text" name="ad_soyad" class="form-control" required placeholder="Ahmet Yılmaz">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Telefon Numarası</label>
                                    <input type="tel" name="telefon" class="form-control" required placeholder="05XX XXX XX XX">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">İstediğiniz Hizmet</label>
                                    <select name="hizmet" class="form-select">
                                        <option value="Komple Bahçe Tasarımı">Komple Bahçe Tasarımı</option>
                                        <option value="Çim Ekimi & Serimi">Çim Ekimi & Serimi</option>
                                        <option value="Otomatik Sulama">Otomatik Sulama</option>
                                        <option value="Periyodik Bakım">Periyodik Bakım</option>
                                        <option value="Diğer">Diğer</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Tahmini Alan (m²)</label>
                                    <input type="text" name="alan_m2" class="form-control" placeholder="Örn: 150">
                                </div>
                                <div class="col-12">
                                    <label class="form-label">Mesajınız & Detaylar</label>
                                    <textarea name="mesaj" class="form-control" rows="4" placeholder="Bahçenizle ilgili hayallerinizi veya alanın durumunu yazın..."></textarea>
                                </div>
                                <div class="col-12 mt-2">
                                    <button type="submit" name="teklif_gonder" class="btn-submit"><i class="fa-solid fa-paper-plane me-2"></i> Talebi Ücretsiz Gönder</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="row g-5">
                <div class="col-lg-4 text-center text-lg-start">
                    <a href="#" class="footer-brand"><i class="fa-solid fa-leaf"></i> <?= htmlspecialchars($ayarlar['site_baslik'] ?? 'Doğa Peyzaj') ?></a>
                    <p class="mb-4 pe-lg-4 text-muted" style="line-height: 1.8;">Doğanın eşsiz renklerini ve huzurunu yaşam alanlarınıza taşıyoruz. Yılların tecrübesiyle profesyonel peyzaj mimarlığı ve uygulama hizmetleri sunuyoruz.</p>
                    <div class="d-flex gap-3 justify-content-center justify-content-lg-start">
                        <?php if(!empty($ayarlar['facebook'])): ?>
                            <a href="<?= htmlspecialchars($ayarlar['facebook']) ?>" target="_blank" class="social-circle"><i class="fa-brands fa-facebook-f"></i></a>
                        <?php endif; ?>
                        <?php if(!empty($ayarlar['instagram'])): ?>
                            <a href="<?= htmlspecialchars($ayarlar['instagram']) ?>" target="_blank" class="social-circle"><i class="fa-brands fa-instagram"></i></a>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-4 text-center">
                    <h5 class="text-white fw-bold mb-4 fs-4">Hızlı Menü</h5>
                    <ul class="list-unstyled">
                        <li class="mb-3"><a href="#hakkimizda" class="text-muted text-decoration-none hover-primary transition">Kurumsal</a></li>
                        <li class="mb-3"><a href="#hizmetler" class="text-muted text-decoration-none hover-primary transition">Neler Yapıyoruz?</a></li>
                        <li class="mb-3"><a href="#projeler" class="text-muted text-decoration-none hover-primary transition">Tamamlanan İşler</a></li>
                        <li class="mb-3"><a href="#iletisim" class="text-muted text-decoration-none hover-primary transition">Ücretsiz Keşif Al</a></li>
                    </ul>
                </div>
                <div class="col-lg-4 text-center text-lg-end">
                    <h5 class="text-white fw-bold mb-4 fs-4">Bize Ulaşın</h5>
                    <p class="mb-3 text-muted"><i class="fa-solid fa-location-dot me-2 text-primary fs-5"></i> <?= htmlspecialchars($ayarlar['adres'] ?? 'Merkez / Türkiye') ?></p>
                    <p class="mb-3 text-muted"><i class="fa-solid fa-phone me-2 text-primary fs-5"></i> <?= htmlspecialchars($ayarlar['telefon'] ?? '+90 500 000 00 00') ?></p>
                    <p class="mb-0 text-muted"><i class="fa-solid fa-envelope me-2 text-primary fs-5"></i> <?= htmlspecialchars($ayarlar['eposta'] ?? 'info@dogapeyzaj.com') ?></p>
                </div>
            </div>
            <div class="border-top border-secondary border-opacity-25 mt-5 pt-4 text-center text-muted fw-medium">
                &copy; <?= date('Y') ?> <?= htmlspecialchars($ayarlar['site_baslik'] ?? '') ?>. Tüm Hakları Saklıdır. | Yazılım: OSSIQN
            </div>
        </div>
    </footer>

    <?php if(!empty($ayarlar['whatsapp'])): ?>
    <a href="https://wa.me/<?= preg_replace('/[^0-9]/', '', $ayarlar['whatsapp']) ?>" class="whatsapp-float" target="_blank">
        <i class="fa-brands fa-whatsapp"></i>
    </a>
    <?php endif; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const reveals = document.querySelectorAll('.reveal');
            
            function revealOnScroll() {
                const windowHeight = window.innerHeight;
                const elementVisible = 100;
                
                reveals.forEach((reveal) => {
                    const elementTop = reveal.getBoundingClientRect().top;
                    if (elementTop < windowHeight - elementVisible) {
                        reveal.classList.add('active');
                    }
                });
            }
            
            window.addEventListener('scroll', revealOnScroll);
            revealOnScroll();
        });
    </script>
</body>
</html>