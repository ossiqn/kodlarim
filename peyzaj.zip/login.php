<?php
session_start();
$ADMIN_SIFRE = 'admin123';

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: 0");
if (isset($_SESSION['admin_giris']) && $_SESSION['admin_giris'] === true) {
    header("Location: /admin");
    exit;
}

$sifre_hatasi = '';
$giris_basarili = false;

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['sifre'])) {
    if ($_POST['sifre'] === $ADMIN_SIFRE) {
        $_SESSION['admin_giris'] = true;
        $_SESSION['admin_giris_tarihi'] = time();
        $giris_basarili = true;
    } else {
        $sifre_hatasi = 'Şifre yanlış! Lütfen tekrar deneyin.';
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Giriş - Doğa Peyzaj</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {
            font-family: 'Poppins', sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow: hidden;
        }
        
        body::before {
            content: '';
            position: absolute;
            width: 400px;
            height: 400px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            top: -100px;
            left: -100px;
            animation: float 6s ease-in-out infinite;
        }
        
        body::after {
            content: '';
            position: absolute;
            width: 300px;
            height: 300px;
            background: rgba(255, 255, 255, 0.08);
            border-radius: 50%;
            bottom: -80px;
            right: -80px;
            animation: float 8s ease-in-out infinite reverse;
        }
        
        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(20px); }
        }
        
        .login-container {
            position: relative;
            z-index: 1;
            width: 100%;
            padding: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
        }
        
        .login-card {
            background: rgba(255, 255, 255, 0.98);
            backdrop-filter: blur(20px);
            border-radius: 30px;
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.15), 
                        0 0 100px rgba(102, 126, 234, 0.15), 
                        inset 0 1px 0 rgba(255, 255, 255, 0.8);
            padding: 60px 45px;
            max-width: 420px;
            width: 100%;
            border: 1px solid rgba(255, 255, 255, 0.8);
            animation: slideUp 0.7s cubic-bezier(0.34, 1.56, 0.64, 1);
            position: relative;
            overflow: hidden;
        }
        
        .login-card::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 300px;
            height: 300px;
            background: radial-gradient(circle, rgba(102, 126, 234, 0.2) 0%, transparent 70%);
            border-radius: 50%;
            pointer-events: none;
        }
        
        .login-card::after {
            content: '';
            position: absolute;
            bottom: -30%;
            left: -30%;
            width: 250px;
            height: 250px;
            background: radial-gradient(circle, rgba(240, 147, 251, 0.2) 0%, transparent 70%);
            border-radius: 50%;
            pointer-events: none;
        }
        
        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .login-card h1 {
            text-align: center;
            color: #0f172a;
            margin-bottom: 12px;
            font-weight: 800;
            font-size: 2rem;
            letter-spacing: -0.5px;
        }
        
        .login-card .subtitle {
            text-align: center;
            color: #64748b;
            margin-bottom: 40px;
            font-size: 0.95rem;
            font-weight: 500;
            letter-spacing: 0.3px;
        }
        
        .icon-lock {
            font-size: 4.5rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 25px;
            text-align: center;
            animation: bounce 3s cubic-bezier(0.68, -0.55, 0.265, 1.55) infinite;
            filter: drop-shadow(0 4px 15px rgba(102, 126, 234, 0.3));
        }
        
        @keyframes bounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-15px); }
        }
        
        .form-label {
            color: #1e293b;
            font-weight: 700;
            margin-bottom: 12px;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            display: flex;
            align-items: center;
        }
        
        .form-label i {
            font-size: 1rem;
            margin-right: 8px;
        }
        
        .form-control {
            border-radius: 14px;
            padding: 14px 18px;
            border: 2px solid #e2e8f0;
            background: linear-gradient(to bottom, #ffffff, #f8fafc);
            font-size: 0.95rem;
            font-weight: 500;
            transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
            color: #1e293b;
        }
        
        .form-control:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.15), 
                        0 8px 20px rgba(102, 126, 234, 0.2);
            background: white;
            transform: translateY(-3px);
        }
        
        .form-control::placeholder {
            color: #cbd5e1;
            font-weight: 500;
        }
        
        .input-group .btn {
            background: white !important;
            border: 2px solid #e2e8f0 !important;
            color: #667eea !important;
            transition: all 0.3s ease;
            border-radius: 0 12px 12px 0 !important;
            cursor: pointer;
        }
        
        .input-group .btn:hover {
            background: #f8fafc !important;
            transform: scale(1.05);
        }
        
        .btn-login {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            padding: 15px 24px;
            font-weight: 800;
            border-radius: 14px;
            margin-top: 32px;
            letter-spacing: 1px;
            transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
            font-size: 1.05rem;
            position: relative;
            overflow: hidden;
            box-shadow: 0 10px 25px rgba(102, 126, 234, 0.3);
            color: white;
        }
        
        .btn-login::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.3);
            transition: left 0.4s ease;
            z-index: 1;
        }
        
        .btn-login:hover::before {
            left: 100%;
        }
        
        .btn-login:hover {
            transform: translateY(-4px);
            box-shadow: 0 20px 40px rgba(102, 126, 234, 0.4), 
                        0 0 60px rgba(102, 126, 234, 0.2);
        }
        
        .btn-login:active {
            transform: translateY(-1px);
        }
        
        .alert {
            border-radius: 12px;
            border: none;
            font-weight: 500;
            margin-bottom: 25px;
            animation: slideDown 0.4s ease-out;
            padding: 12px 16px;
        }
        
        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .alert-danger {
            background: rgba(239, 68, 68, 0.1);
            color: #dc2626;
            border: 1px solid rgba(239, 68, 68, 0.2);
        }
        
        .alert-success {
            background: rgba(34, 197, 94, 0.1);
            color: #16a34a;
            border: 1px solid rgba(34, 197, 94, 0.2);
        }
        
        .alert-danger i {
            font-weight: 700;
        }
        
        .divider {
            margin: 28px 0;
            position: relative;
            text-align: center;
            color: #cbd5e1;
            font-size: 1.2rem;
        }
        
        .divider::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 0;
            right: 0;
            height: 1px;
            background: #e2e8f0;
        }
        
        .footer-text {
            text-align: center;
            color: #64748b;
            font-size: 0.85rem;
            margin-top: 25px;
        }
        
        .footer-text i {
            color: #667eea;
            font-weight: 700;
        }
        
        .mb-3 {
            position: relative;
            z-index: 2;
        }
        
        form {
            position: relative;
            z-index: 2;
        }
        
        @media (max-width: 576px) {
            .login-card {
                padding: 40px 25px;
            }
            
            .login-card h1 {
                font-size: 1.5rem;
            }
            
            .icon-lock {
                font-size: 3rem;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-card">
            <div class="icon-lock">
                <i class="fas fa-crown"></i>
            </div>
            <h1>Admin Paneli</h1>
            <p class="subtitle">Yönetim paneline hoş geldiniz</p>
            
            <?php if ($giris_basarili): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert" id="successAlert">
                    <i class="fas fa-check-circle me-2"></i>
                    <strong>Başarılı!</strong> Giriş yapılıyor...
                </div>
                <script>
                    setTimeout(function() {
                        window.location.href = '/admin';
                    }, 3000);
                </script>
            <?php elseif ($sifre_hatasi): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="fas fa-times-circle me-2"></i>
                    <strong>Hata:</strong> <?php echo htmlspecialchars($sifre_hatasi); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <?php if (!$giris_basarili): ?>
            <form method="POST" novalidate>
                <div class="mb-3">
                    <label class="form-label" for="sifre">
                        <i class="fas fa-lock"></i>Admin Şifresi
                    </label>
                    <div class="input-group">
                        <input type="password" id="sifre" name="sifre" class="form-control" 
                               placeholder="Şifrenizi girin" required autofocus>
                        <button class="btn" type="button" 
                                onmousedown="document.getElementById('sifre').type='text'" 
                                onmouseup="document.getElementById('sifre').type='password'"
                                ontouchstart="document.getElementById('sifre').type='text'" 
                                ontouchend="document.getElementById('sifre').type='password'"
                                title="Şifreyi göster/gizle">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                </div>
                
                <button type="submit" class="btn btn-login w-100">
                    <i class="fas fa-sign-in-alt me-2"></i>Giriş Yap
                </button>
            </form>
            <?php endif; ?>
            
            <div class="divider">•••</div>
            
            <p class="footer-text">
                <i class="fas fa-lock-alt me-2"></i>Güvenli ve Korumalı Alan
            </p>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
