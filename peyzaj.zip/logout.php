<?php
session_start();

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: 0");
session_destroy();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Çıkış Yapılıyor - Doğa Peyzaj</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {
            font-family: 'Poppins', sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow: hidden;
        }
        
        body::before {
            content: '';
            position: absolute;
            width: 400px;
            height: 400px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            top: -100px;
            left: -100px;
            animation: float 6s ease-in-out infinite;
        }
        
        body::after {
            content: '';
            position: absolute;
            width: 300px;
            height: 300px;
            background: rgba(255, 255, 255, 0.08);
            border-radius: 50%;
            bottom: -80px;
            right: -80px;
            animation: float 8s ease-in-out infinite reverse;
        }
        
        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(20px); }
        }
        
        .logout-container {
            position: relative;
            z-index: 1;
            width: 100%;
            padding: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
        }
        
        .logout-card {
            background: rgba(255, 255, 255, 0.98);
            backdrop-filter: blur(20px);
            border-radius: 30px;
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.15), 
                        0 0 100px rgba(102, 126, 234, 0.15), 
                        inset 0 1px 0 rgba(255, 255, 255, 0.8);
            padding: 60px 45px;
            max-width: 420px;
            width: 100%;
            border: 1px solid rgba(255, 255, 255, 0.8);
            animation: slideUp 0.7s cubic-bezier(0.34, 1.56, 0.64, 1);
            position: relative;
            overflow: hidden;
            text-align: center;
        }
        
        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .icon-logout {
            font-size: 4.5rem;
            background: linear-gradient(135deg, #22c55e 0%, #16a34a 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 20px;
            animation: slideDown 0.7s ease-out;
        }
        
        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .logout-card h1 {
            color: #0f172a;
            font-weight: 800;
            font-size: 1.8rem;
            margin-bottom: 12px;
        }
        
        .logout-card p {
            color: #64748b;
            font-size: 0.95rem;
            font-weight: 500;
            margin-bottom: 0;
        }
        
        .countdown {
            font-size: 3rem;
            font-weight: 800;
            background: linear-gradient(135deg, #22c55e 0%, #16a34a 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin: 30px 0;
            animation: pulse 1s ease-in-out infinite;
        }
        
        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.1); }
        }
        
        @media (max-width: 576px) {
            .logout-card {
                padding: 40px 25px;
            }
            
            .logout-card h1 {
                font-size: 1.4rem;
            }
            
            .icon-logout {
                font-size: 3rem;
            }
            
            .countdown {
                font-size: 2.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="logout-container">
        <div class="logout-card">
            <div class="icon-logout">
                <i class="fas fa-check-circle"></i>
            </div>
            <h1>Çıkış Başarılı</h1>
            <p>Oturumunuz kapatılmıştır.</p>
            
            <div class="countdown" id="countdown">3</div>
            
            <p style="margin-top: 20px; color: #94a3b8; font-size: 0.85rem;">
                <i class="fas fa-info-circle me-2"></i>Giriş sayfasına yönlendiriliyorsunuz...
            </p>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        let count = 3;
        const countdownEl = document.getElementById('countdown');
        
        const interval = setInterval(function() {
            count--;
            countdownEl.textContent = count;
            
            if (count <= 0) {
                clearInterval(interval);
                window.location.href = '/login';
            }
        }, 1000);
    </script>
</body>
</html>
