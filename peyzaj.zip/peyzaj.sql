SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+03:00";

CREATE TABLE IF NOT EXISTS `peyzaj_ayarlar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_baslik` varchar(255) DEFAULT 'Doğa Peyzaj & Bahçe Düzenleme',
  `site_aciklama` text DEFAULT 'Uzman ekibimizle doğanın estetiğini yaşam alanlarınıza taşıyoruz.',
  `telefon` varchar(50) DEFAULT '+90 555 123 45 67',
  `eposta` varchar(100) DEFAULT 'info@dogapeyzaj.com',
  `adres` text DEFAULT 'Merkez / Türkiye',
  `whatsapp` varchar(50) DEFAULT '905551234567',
  `hero_baslik` varchar(255) DEFAULT 'Hayalinizdeki Bahçeyi Birlikte Tasarlıyoruz',
  `hero_alt_baslik` text DEFAULT 'Uzman ekibimizle doğanın estetiğini yaşam alanlarınıza taşıyoruz. Profesyonel peyzaj, otomatik sulama ve bahçe bakım hizmetleri.',
  `hakkimizda` text,
  `facebook` varchar(255) DEFAULT NULL,
  `instagram` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `peyzaj_ayarlar` (`id`, `site_baslik`) VALUES (1, 'Doğa Peyzaj');

CREATE TABLE IF NOT EXISTS `peyzaj_blog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `baslik` varchar(255) NOT NULL,
  `ozet` text DEFAULT NULL,
  `icerik` text DEFAULT NULL,
  `gorsel` varchar(255) DEFAULT NULL,
  `seo_url` varchar(255) DEFAULT NULL,
  `tarih` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `peyzaj_hizmetler` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `baslik` varchar(255) NOT NULL,
  `aciklama` text DEFAULT NULL,
  `ikon` varchar(100) DEFAULT 'fa-leaf',
  `sira` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `peyzaj_hizmetler` (`id`, `baslik`, `aciklama`, `ikon`, `sira`) VALUES
(1, 'Peyzaj Tasarımı', 'Alanınıza en uygun, estetik ve sürdürülebilir bahçe tasarımları oluşturuyoruz.', 'fa-seedling', 1),
(2, 'Otomatik Sulama', 'Suyunuzu israf etmeden, bitkilerinizin ihtiyacı olan sulama sistemlerini kuruyoruz.', 'fa-droplet', 2),
(3, 'Çim Ekimi & Bakım', 'Rulo çim serimi, tohumlama ve periyodik çim havalandırma, gübreleme işlemleri.', 'fa-leaf', 3),
(4, 'Ağaç Budama', 'Meyve ve süs ağaçlarınızın mevsime uygun, sağlıklı form budama işlemleri.', 'fa-tree', 4);

CREATE TABLE IF NOT EXISTS `peyzaj_portfolyo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `baslik` varchar(255) NOT NULL,
  `gorsel` varchar(255) DEFAULT NULL,
  `kategori` varchar(100) DEFAULT 'Genel',
  `sira` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `peyzaj_talepler` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ad_soyad` varchar(100) NOT NULL,
  `telefon` varchar(50) NOT NULL,
  `hizmet` varchar(100) DEFAULT NULL,
  `alan_m2` varchar(50) DEFAULT NULL,
  `mesaj` text DEFAULT NULL,
  `tarih` timestamp NOT NULL DEFAULT current_timestamp(),
  `durum` enum('Bekliyor','Okundu','Cevaplandi') DEFAULT 'Bekliyor',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

COMMIT;