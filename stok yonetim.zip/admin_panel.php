<?php
require 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['islem'])) {
    if ($_POST['islem'] == 'onayla') {
        $talep_id = $_POST['talep_id'];
        $onaylanan_miktar = $_POST['onaylanan_miktar'];
        $guncelle = $db->prepare("UPDATE requests SET approved_qty = ?, status = 'Onaylandı' WHERE id = ?");
        $guncelle->execute([$onaylanan_miktar, $talep_id]);
        header("Location: admin_panel.php?durum=onaylandi&page=talepler");
        exit;
    } 
    elseif ($_POST['islem'] == 'yeni_ekle') {
        $product_name = $_POST['product_name'];
        $category_id = empty($_POST['category_id']) ? null : $_POST['category_id'];
        $sku = $_POST['sku'];
        $quantity = $_POST['quantity'];
        $unit_type = $_POST['unit_type'];
        $low_limit = $_POST['low_limit'];
        $ekle = $db->prepare("INSERT INTO stocks (product_name, category_id, sku, quantity, unit_type, low_limit) VALUES (?, ?, ?, ?, ?, ?)");
        $ekle->execute([$product_name, $category_id, $sku, $quantity, $unit_type, $low_limit]);
        header("Location: admin_panel.php?durum=eklendi&page=stoklar");
        exit;
    }
    elseif ($_POST['islem'] == 'stok_guncelle') {
        $stock_id = $_POST['stock_id'];
        $eklenen_miktar = $_POST['eklenen_miktar'];
        $guncelle = $db->prepare("UPDATE stocks SET quantity = quantity + ? WHERE id = ?");
        $guncelle->execute([$eklenen_miktar, $stock_id]);
        header("Location: admin_panel.php?durum=guncellendi&page=stoklar");
        exit;
    }
    elseif ($_POST['islem'] == 'kategori_ekle') {
        $category_name = $_POST['category_name'];
        $description = $_POST['description'];
        $unit_types = $_POST['unit_types'];
        $ekle = $db->prepare("INSERT INTO categories (category_name, description, unit_types) VALUES (?, ?, ?)");
        $ekle->execute([$category_name, $description, $unit_types]);
        header("Location: admin_panel.php?durum=kategori_eklendi&page=kategoriler");
        exit;
    }
    elseif ($_POST['islem'] == 'kategori_duzenle') {
        $kategori_id = $_POST['kategori_id'];
        $category_name = $_POST['category_name'];
        $description = $_POST['description'];
        $unit_types = $_POST['unit_types'];
        $guncelle = $db->prepare("UPDATE categories SET category_name = ?, description = ?, unit_types = ? WHERE id = ?");
        $guncelle->execute([$category_name, $description, $unit_types, $kategori_id]);
        header("Location: admin_panel.php?durum=kategori_guncellendi&page=kategoriler");
        exit;
    }
}

$bekleyen_sayi = $db->query("SELECT COUNT(*) as sayi FROM requests WHERE status = 'Beklemede'")->fetch()['sayi'];
$kritik_sayi = $db->query("SELECT COUNT(*) as sayi FROM stocks WHERE quantity <= low_limit")->fetch()['sayi'];
$kritik_urunler = $db->query("SELECT product_name, sku, quantity, unit_type, low_limit FROM stocks WHERE quantity <= low_limit ORDER BY quantity ASC")->fetchAll();

$kategoriler = $db->query("SELECT * FROM categories ORDER BY category_name ASC")->fetchAll();
$talepler = $db->query("SELECT r.id, d.name as birim_adi, s.product_name, s.quantity as mevcut_stok, r.requested_qty, r.created_at FROM requests r JOIN departments d ON r.department_id = d.id JOIN stocks s ON r.stock_id = s.id WHERE r.status = 'Beklemede' ORDER BY r.created_at DESC")->fetchAll();
$gecmis_talepler = $db->query("SELECT r.id, d.name as birim_adi, s.product_name, r.approved_qty, r.status, r.photo_path, r.updated_at FROM requests r JOIN departments d ON r.department_id = d.id JOIN stocks s ON r.stock_id = s.id WHERE r.status != 'Beklemede' ORDER BY r.updated_at DESC LIMIT 100")->fetchAll();
$stoklar = $db->query("SELECT s.*, c.category_name FROM stocks s LEFT JOIN categories c ON s.category_id = c.id ORDER BY s.product_name ASC")->fetchAll();

$page = isset($_GET['page']) ? $_GET['page'] : 'dashboard';
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kurumsal Yönetim Merkezi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.13.5/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
        
        body { font-family: 'Inter', sans-serif; background-color: #f4f7fa; color: #344767; overflow-x: hidden; }
        
        .wrapper { display: flex; width: 100%; align-items: stretch; min-height: 100vh; }
        
        .sidebar { min-width: 260px; max-width: 260px; background: #fff; box-shadow: 0 4px 20px 0 rgba(0,0,0,0.05); z-index: 1045; display: flex; flex-direction: column; transition: all 0.3s ease; }
        .sidebar-header { padding: 25px 20px; border-bottom: 1px solid #f0f2f5; text-align: center; }
        .sidebar-menu { padding: 20px 15px; flex-grow: 1; overflow-y: auto; }
        .menu-item { display: flex; align-items: center; padding: 12px 15px; color: #67748e; text-decoration: none; border-radius: 10px; margin-bottom: 8px; font-weight: 500; transition: all 0.3s ease; }
        .menu-item i { width: 30px; font-size: 1.1rem; }
        .menu-item:hover, .menu-item.active { background: #eef2f6; color: #3a416f; box-shadow: 0 2px 6px rgba(0,0,0,0.04); }
        .menu-item.active i { color: #cb0c9f; }
        
        .sidebar-overlay { display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); z-index: 1040; opacity: 0; transition: opacity 0.3s; }
        .sidebar-overlay.show { display: block; opacity: 1; }

        .main-content { flex-grow: 1; display: flex; flex-direction: column; min-width: 0; width: 100%; }
        .topbar { background: #fff; padding: 15px 30px; box-shadow: 0 2px 10px rgba(0,0,0,0.02); display: flex; justify-content: space-between; align-items: center; }
        .content-body { padding: 30px; }

        .mobile-toggle-btn { display: none; background: transparent; border: none; font-size: 1.5rem; color: #344767; cursor: pointer; padding: 0; margin-right: 15px; }

        .card-enterprise { background: #fff; border: none; border-radius: 16px; box-shadow: 0 4px 15px rgba(0,0,0,0.03); margin-bottom: 30px; }
        .card-header-custom { background: transparent; border-bottom: 1px solid #f0f2f5; padding: 20px 25px; font-weight: 600; font-size: 1.1rem; color: #344767; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px; }
        .card-body-custom { padding: 25px; }

        .stat-widget { padding: 25px; border-radius: 16px; display: flex; align-items: center; justify-content: space-between; color: #fff; box-shadow: 0 8px 20px rgba(0,0,0,0.1); transition: transform 0.2s; }
        .stat-widget.clickable:hover { transform: translateY(-5px); }
        .stat-bg-warning { background: linear-gradient(310deg, #f53939, #fbcf33); }
        .stat-bg-danger { background: linear-gradient(310deg, #ea0606, #ff667c); }
        
        .table-responsive-custom { width: 100%; overflow-x: auto; -webkit-overflow-scrolling: touch; }
        .table-enterprise { width: 100% !important; margin-bottom: 0; border-collapse: separate; border-spacing: 0; white-space: nowrap; }
        .table-enterprise thead th { border-bottom: 1px solid #e9ecef; color: #8392ab; font-size: 0.75rem; text-transform: uppercase; font-weight: 700; padding: 15px; letter-spacing: 0.5px; }
        .table-enterprise tbody td { padding: 15px; vertical-align: middle; border-bottom: 1px solid #f0f2f5; font-size: 0.875rem; color: #67748e; }
        
        .badge-enterprise { padding: 6px 12px; border-radius: 6px; font-weight: 600; font-size: 0.75rem; }
        
        .btn-action { background: linear-gradient(310deg, #17ad37, #98ec2d); border: none; color: #fff; border-radius: 8px; font-weight: 600; padding: 8px 16px; transition: all 0.2s; box-shadow: 0 4px 7px -1px rgba(0,0,0,0.11); }
        .btn-action:hover { transform: translateY(-1px); box-shadow: 0 5px 10px rgba(0,0,0,0.15); color: #fff; }
        
        .form-control-pro { border: 1px solid #d2d6da; border-radius: 8px; padding: 10px 15px; font-size: 0.875rem; transition: border-color 0.2s; }
        .form-control-pro:focus { border-color: #cb0c9f; box-shadow: 0 0 0 2px rgba(203, 12, 159, 0.2); outline: none; }

        .img-preview { width: 40px; height: 40px; border-radius: 8px; object-fit: cover; border: 1px solid #e9ecef; cursor: pointer; transition: transform 0.2s; }
        .img-preview:hover { transform: scale(1.15); }

        div.dataTables_wrapper div.dataTables_filter input { border: 1px solid #d2d6da; border-radius: 8px; padding: 6px 12px; outline: none; }
        div.dataTables_wrapper div.dataTables_filter input:focus { border-color: #cb0c9f; }

        @media (max-width: 991px) {
            .sidebar { position: fixed; left: -260px; top: 0; bottom: 0; height: 100vh; }
            .sidebar.active { left: 0; }
            .mobile-toggle-btn { display: inline-block; }
            .topbar { padding: 15px 20px; }
            .content-body { padding: 15px; }
            .card-body-custom { padding: 15px; }
            .stat-widget { padding: 20px; }
            .stat-widget h2 { font-size: 1.5rem; }
            
            div.dataTables_wrapper div.dataTables_filter { text-align: left; margin-top: 10px; }
            div.dataTables_wrapper div.dataTables_filter input { width: 100%; margin-left: 0; }
        }
    </style>
</head>
<body>

    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <div class="wrapper">
        <nav class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <h5 class="fw-bold mb-0 text-dark"><i class="fa-solid fa-layer-group text-primary me-2"></i>Stok Yönetim</h5>
                <span class="small text-muted">devoloper by: ossiqn</span>
            </div>
            <div class="sidebar-menu">
                <a href="?page=dashboard" class="menu-item <?= $page == 'dashboard' ? 'active' : '' ?>"><i class="fa-solid fa-chart-pie"></i> Kontrol Paneli</a>
                <a href="?page=talepler" class="menu-item <?= $page == 'talepler' ? 'active' : '' ?>">
                    <i class="fa-solid fa-clipboard-list"></i> Bekleyen Talepler
                    <?php if($bekleyen_sayi > 0): ?><span class="badge bg-danger ms-auto rounded-pill"><?= $bekleyen_sayi ?></span><?php endif; ?>
                </a>
                <a href="?page=stoklar" class="menu-item <?= $page == 'stoklar' ? 'active' : '' ?>"><i class="fa-solid fa-boxes-stacked"></i> Depo ve Stoklar</a>
                <a href="?page=kategoriler" class="menu-item <?= $page == 'kategoriler' ? 'active' : '' ?>"><i class="fa-solid fa-tags"></i> Kategori Yönetimi</a>
                <a href="?page=gecmis" class="menu-item <?= $page == 'gecmis' ? 'active' : '' ?>"><i class="fa-solid fa-clock-rotate-left"></i> İşlem Geçmişi</a>
            </div>
            <div class="p-3 mt-auto border-top bg-white">
                <a href="logout.php" class="btn btn-light w-100 text-danger fw-bold shadow-sm rounded-3"><i class="fa-solid fa-right-from-bracket me-2"></i>Çıkış Yap</a>
            </div>
        </nav>

        <div class="main-content">
            <header class="topbar">
                <div class="d-flex align-items-center">
                    <button class="mobile-toggle-btn" id="mobileMenuBtn"><i class="fa-solid fa-bars"></i></button>
                    <h5 class="mb-0 fw-bold text-dark text-capitalize fs-6 fs-md-5">
                        <?= $page == 'dashboard' ? 'Kontrol Paneli' : ($page == 'talepler' ? 'Talep Yönetimi' : ($page == 'stoklar' ? 'Depo ve Envanter' : ($page == 'kategoriler' ? 'Kategori Yönetimi' : 'İşlem Kayıtları'))) ?>
                    </h5>
                </div>
                <div class="d-flex align-items-center">
                    <div class="d-flex align-items-center bg-light rounded-pill px-2 py-1 px-md-3 py-md-2 shadow-sm border">
                        <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-2" style="width: 30px; height: 30px; font-size: 0.8rem;"><i class="fa-solid fa-user-tie"></i></div>
                        <span class="fw-bold text-dark fs-6 d-none d-sm-inline"><?= htmlspecialchars($_SESSION['full_name'] ?? 'Yönetici') ?></span>
                    </div>
                </div>
            </header>

            <div class="content-body">

                <?php if($page == 'dashboard'): ?>
                <div class="row">
                    <div class="col-xl-6 col-md-6 mb-4">
                        <div class="stat-widget stat-bg-warning">
                            <div><p class="text-sm mb-1 text-uppercase fw-bold opacity-75">Bekleyen İşlemler</p><h2 class="mb-0 fw-bold text-white"><?= $bekleyen_sayi ?> Adet</h2></div>
                            <div class="bg-white text-dark rounded-circle d-flex justify-content-center align-items-center shadow" style="width: 50px; height: 50px;"><i class="fa-solid fa-hourglass-half fs-4"></i></div>
                        </div>
                    </div>
                    <div class="col-xl-6 col-md-6 mb-4">
                        <div class="stat-widget stat-bg-danger clickable" style="cursor: pointer;" data-bs-toggle="offcanvas" data-bs-target="#kritikStokOffcanvas">
                            <div><p class="text-sm mb-1 text-uppercase fw-bold opacity-75">Kritik Stok Uyarısı</p><h2 class="mb-0 fw-bold text-white"><?= $kritik_sayi ?> Ürün</h2></div>
                            <div class="bg-white text-danger rounded-circle d-flex justify-content-center align-items-center shadow" style="width: 50px; height: 50px;"><i class="fa-solid fa-triangle-exclamation fs-4"></i></div>
                        </div>
                    </div>
                </div>
                <div class="card-enterprise">
                    <div class="card-header-custom"><div class="d-flex align-items-center"><i class="fa-solid fa-bolt text-warning me-2"></i>Sistem Özeti</div></div>
                    <div class="card-body-custom text-center py-5">
                        <i class="fa-solid fa-server fa-3x fa-md-4x text-muted opacity-25 mb-3"></i>
                        <h5 class="fw-bold text-dark">Sistem Aktif ve Sorunsuz Çalışıyor</h5>
                        <p class="text-muted small">Sol menüyü kullanarak stokları yönetebilir veya bekleyen siparişleri onaylayabilirsiniz.</p>
                    </div>
                </div>
                <?php endif; ?>

                <?php if($page == 'kategoriler'): ?>
                <div class="row">
                    <div class="col-lg-4 mb-4">
                        <div class="card-enterprise h-100 mb-0">
                            <div class="card-header-custom"><div class="d-flex align-items-center"><i class="fa-solid fa-folder-plus text-primary me-2"></i>Yeni Kategori Ekle</div></div>
                            <div class="card-body-custom">
                                <form method="POST">
                                    <input type="hidden" name="islem" value="kategori_ekle">
                                    <div class="mb-3">
                                        <label class="text-xs fw-bold text-muted mb-1 text-uppercase">Kategori Adı</label>
                                        <input type="text" name="category_name" class="form-control form-control-pro w-100" placeholder="Örn: Medikal Malzeme" required>
                                    </div>
                                    <div class="mb-3">
                                        <label class="text-xs fw-bold text-muted mb-1 text-uppercase">Desteklenen Birimler</label>
                                        <input type="text" name="unit_types" class="form-control form-control-pro w-100" placeholder="Örn: Adet,Kutu" required>
                                    </div>
                                    <div class="mb-4">
                                        <label class="text-xs fw-bold text-muted mb-1 text-uppercase">İçerik / Detay</label>
                                        <textarea name="description" class="form-control form-control-pro w-100" rows="3" placeholder="Örn: Kan değerleri vs."></textarea>
                                    </div>
                                    <button type="submit" class="btn btn-primary w-100 py-2 rounded-3 fw-bold"><i class="fa-solid fa-plus me-2"></i>Kategoriyi Kaydet</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-8">
                        <div class="card-enterprise">
                            <div class="card-header-custom"><div class="d-flex align-items-center"><i class="fa-solid fa-tags text-secondary me-2"></i>Mevcut Kategoriler</div></div>
                            <div class="card-body-custom p-0 p-md-4">
                                <div class="table-responsive-custom px-3 px-md-0 pb-3 pb-md-0 pt-3 pt-md-0">
                                    <table class="table table-enterprise datatable">
                                        <thead><tr><th>Kategori Adı</th><th>Geçerli Birimler</th><th>İçerik / Detay</th><th class="text-center">İşlem</th></tr></thead>
                                        <tbody>
                                            <?php foreach($kategoriler as $kat): ?>
                                            <tr>
                                                <td><h6 class="mb-0 text-sm fw-bold text-dark"><?= htmlspecialchars($kat['category_name']) ?></h6></td>
                                                <td><span class="badge bg-light text-dark border badge-enterprise"><?= htmlspecialchars($kat['unit_types']) ?></span></td>
                                                <td><span class="text-sm text-muted d-inline-block text-truncate" style="max-width: 150px;"><?= htmlspecialchars($kat['description']) ?: '-' ?></span></td>
                                                <td class="text-center">
                                                    <button onclick="kategoriDuzenle(<?= $kat['id'] ?>, '<?= htmlspecialchars(addslashes($kat['category_name'])) ?>', '<?= htmlspecialchars(addslashes($kat['unit_types'])) ?>', '<?= htmlspecialchars(addslashes($kat['description'])) ?>')" class="btn btn-sm btn-light border shadow-sm text-primary"><i class="fa-solid fa-pen"></i></button>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <?php if($page == 'talepler'): ?>
                <div class="card-enterprise">
                    <div class="card-header-custom"><div class="d-flex align-items-center"><i class="fa-solid fa-list-check text-primary me-2"></i>Birimlerden Gelen Siparişler</div></div>
                    <div class="card-body-custom p-0 p-md-4">
                        <div class="table-responsive-custom px-3 px-md-0 pb-3 pb-md-0 pt-3 pt-md-0">
                            <table class="table table-enterprise datatable">
                                <thead><tr><th>Tarih</th><th>Talep Eden Birim</th><th>Ürün Adı</th><th>Depo Durumu</th><th>İstenen</th><th>İşlem (Onayla)</th></tr></thead>
                                <tbody>
                                    <?php foreach($talepler as $talep): ?>
                                    <tr>
                                        <td><span class="text-xs fw-bold"><?= date('d.m.Y H:i', strtotime($talep['created_at'])) ?></span></td>
                                        <td><h6 class="mb-0 text-sm fw-bold text-dark"><?= htmlspecialchars($talep['birim_adi']) ?></h6></td>
                                        <td><span class="text-sm fw-bold text-primary"><?= htmlspecialchars($talep['product_name']) ?></span></td>
                                        <td><span class="badge bg-secondary badge-enterprise"><?= $talep['mevcut_stok'] ?> Adet</span></td>
                                        <td><span class="badge bg-warning text-dark badge-enterprise fs-6"><?= $talep['requested_qty'] ?> Adet</span></td>
                                        <td>
                                            <form method="POST" class="d-flex align-items-center m-0 flex-nowrap">
                                                <input type="hidden" name="islem" value="onayla"><input type="hidden" name="talep_id" value="<?= $talep['id'] ?>">
                                                <input type="number" name="onaylanan_miktar" class="form-control-pro me-2 text-center" value="<?= $talep['requested_qty'] ?>" min="1" max="<?= $talep['mevcut_stok'] ?>" style="width: 70px;" required>
                                                <button type="submit" class="btn-action flex-shrink-0"><i class="fa-solid fa-check"></i></button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <?php if($page == 'stoklar'): ?>
                <div class="row">
                    <div class="col-lg-4 mb-4">
                        <div class="card-enterprise h-100 mb-0">
                            <div class="card-header-custom"><div class="d-flex align-items-center"><i class="fa-solid fa-plus text-success me-2"></i>Sisteme Yeni Ürün Tanımla</div></div>
                            <div class="card-body-custom">
                                <form method="POST">
                                    <input type="hidden" name="islem" value="yeni_ekle">
                                    <div class="mb-3"><label class="text-xs fw-bold text-muted mb-1 text-uppercase">Ürün Adı</label><input type="text" name="product_name" class="form-control form-control-pro w-100" required></div>
                                    <div class="mb-3">
                                        <label class="text-xs fw-bold text-muted mb-1 text-uppercase">Kategori</label>
                                        <select name="category_id" id="kategori_secici" class="form-select form-control-pro w-100" required>
                                            <option value="">Kategori Seçiniz</option>
                                            <?php foreach($kategoriler as $kat): ?>
                                                <option value="<?= $kat['id'] ?>" data-birimler="<?= htmlspecialchars($kat['unit_types']) ?>"><?= htmlspecialchars($kat['category_name']) ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="mb-3"><label class="text-xs fw-bold text-muted mb-1 text-uppercase">Barkod / SKU</label><input type="text" name="sku" class="form-control form-control-pro w-100" required></div>
                                    <div class="row mb-3 g-2">
                                        <div class="col-6"><label class="text-xs fw-bold text-muted mb-1 text-uppercase">Başlangıç Miktarı</label><input type="number" name="quantity" class="form-control form-control-pro w-100" min="0" required></div>
                                        <div class="col-6">
                                            <label class="text-xs fw-bold text-muted mb-1 text-uppercase">Birim Cinsi</label>
                                            <select name="unit_type" id="birim_secici" class="form-select form-control-pro w-100" required>
                                                <option value="">Kategori Seçin</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="mb-4"><label class="text-xs fw-bold text-muted mb-1 text-uppercase">Kritik Sınır</label><input type="number" name="low_limit" class="form-control form-control-pro w-100" required></div>
                                    <button type="submit" class="btn btn-dark w-100 py-2 rounded-3 fw-bold"><i class="fa-solid fa-database me-2"></i>Kayıt Oluştur</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-8">
                        <div class="card-enterprise">
                            <div class="card-header-custom"><div class="d-flex align-items-center"><i class="fa-solid fa-warehouse text-secondary me-2"></i>Aktif Envanter Listesi</div></div>
                            <div class="card-body-custom p-0 p-md-4">
                                <div class="table-responsive-custom px-3 px-md-0 pb-3 pb-md-0 pt-3 pt-md-0">
                                    <table class="table table-enterprise datatable">
                                        <thead><tr><th>Stok Adı / Kodu</th><th>Kategori</th><th class="text-center">Mevcut Miktar</th><th>Hızlı Stok Girişi</th></tr></thead>
                                        <tbody>
                                            <?php foreach($stoklar as $stok): ?>
                                            <tr>
                                                <td><h6 class="mb-0 text-sm fw-bold text-dark"><?= htmlspecialchars($stok['product_name']) ?></h6><span class="text-xs text-muted">SKU: <?= htmlspecialchars($stok['sku']) ?></span></td>
                                                <td><span class="badge bg-light text-dark border badge-enterprise"><?= $stok['category_name'] ? htmlspecialchars($stok['category_name']) : 'Genel' ?></span></td>
                                                <td class="text-center"><span class="badge <?= $stok['quantity'] <= $stok['low_limit'] ? 'bg-danger' : 'bg-success' ?> badge-enterprise px-3 py-2"><?= $stok['quantity'] ?> <?= $stok['unit_type'] ?></span></td>
                                                <td>
                                                    <form method="POST" class="d-flex m-0 flex-nowrap" style="min-width: 120px;">
                                                        <input type="hidden" name="islem" value="stok_guncelle"><input type="hidden" name="stock_id" value="<?= $stok['id'] ?>">
                                                        <input type="number" name="eklenen_miktar" class="form-control-pro me-2 text-center px-1" placeholder="+" min="1" required style="width: 60px;">
                                                        <button type="submit" class="btn btn-dark rounded-3 px-3 flex-shrink-0"><i class="fa-solid fa-plus"></i></button>
                                                    </form>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <?php if($page == 'gecmis'): ?>
                <div class="card-enterprise">
                    <div class="card-header-custom"><div class="d-flex align-items-center"><i class="fa-solid fa-folder-open text-info me-2"></i>Tamamlanmış İşlem Kayıtları (Log)</div></div>
                    <div class="card-body-custom p-0 p-md-4">
                        <div class="table-responsive-custom px-3 px-md-0 pb-3 pb-md-0 pt-3 pt-md-0">
                            <table class="table table-enterprise datatable">
                                <thead><tr><th>Son İşlem</th><th>Talep Sahibi</th><th>Ürün Bilgisi</th><th class="text-center">Miktar</th><th>Süreç Durumu</th><th class="text-center">Islak İmza</th></tr></thead>
                                <tbody>
                                    <?php foreach($gecmis_talepler as $gecmis): ?>
                                    <tr>
                                        <td><span class="text-xs fw-bold"><?= date('d.m.Y H:i', strtotime($gecmis['updated_at'])) ?></span></td>
                                        <td><h6 class="mb-0 text-sm fw-bold text-dark"><?= htmlspecialchars($gecmis['birim_adi']) ?></h6></td>
                                        <td><span class="text-sm fw-bold text-dark"><?= htmlspecialchars($gecmis['product_name']) ?></span></td>
                                        <td class="text-center"><span class="badge bg-light text-dark border badge-enterprise"><?= $gecmis['approved_qty'] ?> Adet</span></td>
                                        <td>
                                            <?php if($gecmis['status'] == 'Onaylandı'): ?><span class="badge bg-warning text-dark badge-enterprise"><i class="fa-solid fa-truck-fast me-1"></i>Kuryede</span>
                                            <?php elseif($gecmis['status'] == 'Teslim Edildi'): ?><span class="badge bg-success badge-enterprise"><i class="fa-solid fa-check-double me-1"></i>Teslim Edildi</span><?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <?php if($gecmis['photo_path']): ?><img src="<?= $gecmis['photo_path'] ?>" class="img-preview shadow-sm" onclick="resmiBuyut(this.src)"><?php else: ?><span class="text-xs text-muted">-</span><?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

            </div>
        </div>
    </div>

    <div class="offcanvas offcanvas-end" tabindex="-1" id="kritikStokOffcanvas">
        <div class="offcanvas-header border-bottom">
            <h5 class="offcanvas-title fw-bold text-danger"><i class="fa-solid fa-triangle-exclamation me-2"></i>Kritik Stoktaki Ürünler</h5>
            <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
        </div>
        <div class="offcanvas-body p-0">
            <?php if(count($kritik_urunler) > 0): ?>
                <ul class="list-group list-group-flush">
                    <?php foreach($kritik_urunler as $urun): ?>
                        <li class="list-group-item p-3 d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="mb-0 fw-bold text-dark"><?= htmlspecialchars($urun['product_name']) ?></h6>
                                <small class="text-muted">SKU: <?= htmlspecialchars($urun['sku']) ?></small>
                            </div>
                            <span class="badge bg-danger rounded-pill fs-6 px-2 py-1"><?= $urun['quantity'] ?> / <?= $urun['low_limit'] ?> <?= $urun['unit_type'] ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <div class="text-center p-5">
                    <i class="fa-solid fa-check-circle text-success mb-3 opacity-50" style="font-size: 3rem;"></i>
                    <h6 class="text-muted">Şu an kritik stokta ürün bulunmuyor.</h6>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="modal fade" id="kategoriDuzenleModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 shadow-lg">
                <div class="modal-header border-bottom">
                    <h5 class="modal-title fw-bold text-dark"><i class="fa-solid fa-pen-to-square text-primary me-2"></i>Kategori Düzenle</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-4">
                    <form method="POST">
                        <input type="hidden" name="islem" value="kategori_duzenle">
                        <input type="hidden" name="kategori_id" id="edit_kategori_id">
                        <div class="mb-3">
                            <label class="text-xs fw-bold text-muted mb-1 text-uppercase">Kategori Adı</label>
                            <input type="text" name="category_name" id="edit_category_name" class="form-control form-control-pro w-100" required>
                        </div>
                        <div class="mb-3">
                            <label class="text-xs fw-bold text-muted mb-1 text-uppercase">Desteklenen Birimler</label>
                            <input type="text" name="unit_types" id="edit_unit_types" class="form-control form-control-pro w-100" required>
                        </div>
                        <div class="mb-4">
                            <label class="text-xs fw-bold text-muted mb-1 text-uppercase">İçerik / Detay</label>
                            <textarea name="description" id="edit_description" class="form-control form-control-pro w-100" rows="4"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary w-100 py-2 rounded-3 fw-bold">Değişiklikleri Kaydet</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="imageModal" tabindex="-1"><div class="modal-dialog modal-dialog-centered modal-lg"><div class="modal-content bg-transparent border-0"><div class="modal-body p-0 text-center position-relative"><button type="button" class="btn-close btn-close-white position-absolute top-0 end-0 m-3 shadow" style="z-index: 10;" data-bs-dismiss="modal"></button><img src="" id="modalImage" class="img-fluid rounded-4 shadow-lg" style="max-height: 85vh; border: 4px solid white;"></div></div></div></div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.5/js/dataTables.bootstrap5.min.js"></script>
    
    <script>
        $(document).ready(function() {
            // Sidebar Mobil Geçişi
            $('#mobileMenuBtn').click(function() {
                $('#sidebar').addClass('active');
                $('#sidebarOverlay').addClass('show');
            });
            $('#sidebarOverlay').click(function() {
                $('#sidebar').removeClass('active');
                $(this).removeClass('show');
            });

            // DataTables Başlatma
            $('.datatable').DataTable({
                "language": {
                    "url": "//cdn.datatables.net/plug-ins/1.13.5/i18n/tr.json"
                },
                "pageLength": 10,
                "ordering": true,
                "info": true,
                "lengthChange": false,
                "responsive": false // Kendi wrapper'ımızı kullandığımız için false yapıyoruz
            });

            // Kategori seçildiğinde birimleri dinamik getiren script
            $('#kategori_secici').change(function() {
                var secilen = $(this).find('option:selected');
                var birimler = secilen.data('birimler');
                var birimSelect = $('#birim_secici');
                
                birimSelect.empty();
                
                if (birimler && birimler.trim() !== "") {
                    var birimDizisi = birimler.split(',');
                    birimDizisi.forEach(function(birim) {
                        var temizBirim = birim.trim();
                        if(temizBirim !== "") {
                            birimSelect.append('<option value="' + temizBirim + '">' + temizBirim + '</option>');
                        }
                    });
                } else {
                    birimSelect.append('<option value="">Önce Kategori Seçin</option>');
                }
            });

            // SweetAlert2 Bildirimleri
            const urlParams = new URLSearchParams(window.location.search);
            if(urlParams.has('durum')) {
                let durum = urlParams.get('durum');
                let mesaj = "", icon = "success";
                
                if(durum === 'onaylandi') mesaj = "Talep başarıyla sahaya iletildi!";
                else if(durum === 'eklendi') mesaj = "Yeni ürün başarıyla depoya kaydedildi!";
                else if(durum === 'guncellendi') mesaj = "Stok miktarı başarıyla güncellendi!";
                else if(durum === 'kategori_eklendi') mesaj = "Yeni kategori başarıyla oluşturuldu!";
                else if(durum === 'kategori_guncellendi') mesaj = "Kategori bilgileri başarıyla güncellendi!";
                
                if(mesaj !== "") {
                    Swal.fire({
                        title: 'İşlem Başarılı!',
                        text: mesaj,
                        icon: icon,
                        confirmButtonColor: '#17ad37',
                        timer: 3000,
                        timerProgressBar: true
                    }).then(() => {
                        window.history.replaceState(null, null, window.location.pathname + "?page=" + urlParams.get('page'));
                    });
                }
            }
        });

        // Fonksiyonlar
        function resmiBuyut(src) {
            $('#modalImage').attr('src', src);
            new bootstrap.Modal(document.getElementById('imageModal')).show();
        }

        function kategoriDuzenle(id, name, units, desc) {
            $('#edit_kategori_id').val(id);
            $('#edit_category_name').val(name);
            $('#edit_unit_types').val(units);
            $('#edit_description').val(desc);
            new bootstrap.Modal(document.getElementById('kategoriDuzenleModal')).show();
        }
    </script>
</body>
</html>