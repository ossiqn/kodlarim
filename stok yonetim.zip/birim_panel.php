<?php
require 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'birim') {
    header("Location: login.php");
    exit;
}

$department_id = $_SESSION['department_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['islem']) && $_POST['islem'] == 'talep_olustur') {
    $stock_id = $_POST['stock_id'];
    $requested_qty = $_POST['requested_qty'];

    $stok_kontrol = $db->prepare("SELECT quantity FROM stocks WHERE id = ?");
    $stok_kontrol->execute([$stock_id]);
    $mevcut_stok = $stok_kontrol->fetchColumn();

    if($requested_qty <= $mevcut_stok) {
        $ekle = $db->prepare("INSERT INTO requests (department_id, stock_id, requested_qty, status) VALUES (?, ?, ?, 'Beklemede')");
        $ekle->execute([$department_id, $stock_id, $requested_qty]);
        header("Location: birim_panel.php?durum=basarili");
    } else {
        header("Location: birim_panel.php?durum=hata");
    }
    exit;
}

$stoklar = $db->query("SELECT * FROM stocks WHERE quantity > 0 ORDER BY product_name ASC")->fetchAll();

$gecmis_talepler = $db->prepare("
    SELECT r.id, s.product_name, s.unit_type, r.requested_qty, r.approved_qty, r.status, r.created_at 
    FROM requests r 
    JOIN stocks s ON r.stock_id = s.id 
    WHERE r.department_id = ? 
    ORDER BY r.created_at DESC
");
$gecmis_talepler->execute([$department_id]);
$talepler = $gecmis_talepler->fetchAll();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Birim Paneli - Stok Talebi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.13.5/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
        
        body { 
            font-family: 'Poppins', sans-serif; 
            background-color: #f4f7fa; 
            padding-bottom: 50px;
        }
        
        .navbar-custom { 
            background: linear-gradient(135deg, #0f2027, #203a43, #2c5364); 
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }
        
        @keyframes slideInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        @keyframes pulseAlert {
            0% { transform: scale(1); opacity: 1; }
            50% { transform: scale(1.1); opacity: 0.7; }
            100% { transform: scale(1); opacity: 1; }
        }

        .animated-card {
            animation: slideInUp 0.6s ease-out forwards;
            opacity: 0;
        }

        .glass-panel {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 24px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.04);
            border: 1px solid rgba(255,255,255,0.2);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .glass-panel:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 40px rgba(0,0,0,0.08);
        }

        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 8px 16px;
            border-radius: 50px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        .bg-beklemede { background: #fff8e1; color: #f57c00; border: 1px solid #ffe082; }
        .bg-onaylandi { background: #e8f5e9; color: #2e7d32; border: 1px solid #a5d6a7; }
        .bg-teslim { background: #e3f2fd; color: #1565c0; border: 1px solid #90caf9; }

        .pulse-icon {
            animation: pulseAlert 2s infinite;
            color: #f57c00;
        }

        .mobile-request-card {
            background: #fff;
            border-radius: 18px;
            padding: 20px;
            margin-bottom: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.03);
            border-left: 6px solid #ddd;
            transition: all 0.2s ease;
        }
        .mobile-request-card:active {
            transform: scale(0.98);
        }
        .border-beklemede { border-left-color: #ffb300; }
        .border-onaylandi { border-left-color: #43a047; }
        .border-teslim { border-left-color: #1e88e5; }

        .form-control-custom {
            border-radius: 12px;
            border: 2px solid #e2e8f0;
            padding: 14px;
            font-size: 0.95rem;
            transition: all 0.3s;
            background-color: #f8fafc;
        }
        .form-control-custom:focus {
            border-color: #2c5364;
            background-color: #fff;
            box-shadow: 0 0 0 4px rgba(44, 83, 100, 0.1);
        }
        
        .btn-custom {
            background: linear-gradient(135deg, #2c5364, #203a43);
            border: none;
            color: white;
            border-radius: 12px;
            padding: 14px;
            font-weight: 600;
            letter-spacing: 0.5px;
            transition: all 0.3s;
            box-shadow: 0 8px 20px rgba(44, 83, 100, 0.2);
        }
        .btn-custom:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 25px rgba(44, 83, 100, 0.3);
            color: #fff;
        }

        .table-custom { margin-bottom: 0; }
        .table-custom thead th { border-bottom: 2px solid #edf2f7; color: #64748b; font-size: 0.75rem; font-weight: 700; letter-spacing: 0.5px; padding: 15px; }
        .table-custom tbody td { padding: 16px 15px; vertical-align: middle; border-bottom: 1px solid #f1f5f9; color: #334155; }
        
        div.dataTables_wrapper div.dataTables_filter input { border: 2px solid #e2e8f0; border-radius: 10px; padding: 8px 15px; outline: none; }
        div.dataTables_wrapper div.dataTables_filter input:focus { border-color: #2c5364; }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom sticky-top">
        <div class="container py-2">
            <a class="navbar-brand fw-bold fs-4" href="#"><i class="fa-solid fa-layer-group me-2 text-info"></i>Enterprise Birim</a>
            <div class="d-flex align-items-center">
                <span class="text-light me-4 d-none d-sm-inline opacity-75"><i class="fa-solid fa-user-tie me-2"></i><?= htmlspecialchars($_SESSION['full_name'] ?? 'Kullanıcı') ?></span>
                <a href="logout.php" class="btn btn-danger btn-sm rounded-pill px-4 fw-bold shadow"><i class="fa-solid fa-right-from-bracket me-2"></i>Çıkış</a>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <div class="row">
            <div class="col-lg-4 mb-4">
                <div class="glass-panel p-4 p-md-5 animated-card" style="animation-delay: 0.1s;">
                    <div class="text-center mb-4">
                        <div class="bg-primary bg-opacity-10 text-primary rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 60px; height: 60px;">
                            <i class="fa-solid fa-cart-plus fs-3"></i>
                        </div>
                        <h4 class="fw-bold text-dark mb-0">Talep Oluştur</h4>
                        <p class="text-muted small">Merkez depodan ürün isteyin</p>
                    </div>

                    <form method="POST">
                        <input type="hidden" name="islem" value="talep_olustur">
                        <div class="mb-4">
                            <label class="form-label fw-bold text-dark small text-uppercase">Malzeme Seçimi</label>
                            <select name="stock_id" id="stokSecici" class="form-select form-control-custom" required>
                                <option value="" data-stok="0" data-birim="">Listeden seçin...</option>
                                <?php foreach($stoklar as $stok): ?>
                                    <option value="<?= $stok['id'] ?>" data-stok="<?= $stok['quantity'] ?>" data-birim="<?= htmlspecialchars($stok['unit_type'] ?? 'Adet') ?>">
                                        <?= htmlspecialchars($stok['product_name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-4 position-relative">
                            <label class="form-label fw-bold text-dark small text-uppercase">İstenen Miktar</label>
                            <input type="number" name="requested_qty" id="miktarGirdisi" class="form-control form-control-custom" min="1" placeholder="0" required disabled>
                            <div id="stokUyari" class="small mt-2 fw-semibold text-info d-none"><i class="fa-solid fa-circle-info me-1"></i>Depo Limiti: <span id="maxStokYazisi"></span></div>
                        </div>
                        <button type="submit" id="gonderBtn" class="btn btn-custom w-100 fs-6 mt-2" disabled><i class="fa-solid fa-paper-plane me-2"></i>Talebi Gönder</button>
                    </form>
                </div>
            </div>

            <div class="col-lg-8 mb-4">
                <div class="glass-panel p-4 p-md-5 animated-card" style="animation-delay: 0.2s;">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h4 class="fw-bold text-dark mb-0"><i class="fa-solid fa-clock-rotate-left text-primary me-2"></i>Geçmiş Taleplerim</h4>
                    </div>

                    <div class="d-none d-md-block">
                        <div class="table-responsive">
                            <table class="table table-custom datatable w-100">
                                <thead>
                                    <tr>
                                        <th>Tarih</th>
                                        <th>Ürün Adı</th>
                                        <th class="text-center">İstenen</th>
                                        <th class="text-center">Onaylanan</th>
                                        <th>Güncel Durum</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($talepler as $talep): ?>
                                        <tr>
                                            <td>
                                                <span class="fw-bold text-dark d-block"><?= date('d.m.Y', strtotime($talep['created_at'])) ?></span>
                                                <span class="text-muted small"><?= date('H:i', strtotime($talep['created_at'])) ?></span>
                                            </td>
                                            <td class="fw-bold text-primary"><?= htmlspecialchars($talep['product_name']) ?></td>
                                            <td class="text-center"><span class="badge bg-light text-dark border fs-6 px-3 py-2 rounded-3"><?= $talep['requested_qty'] ?> <?= htmlspecialchars($talep['unit_type']) ?></span></td>
                                            <td class="text-center">
                                                <?php if($talep['approved_qty']): ?>
                                                    <span class="badge bg-success bg-opacity-10 text-success border border-success fs-6 px-3 py-2 rounded-3"><?= $talep['approved_qty'] ?> <?= htmlspecialchars($talep['unit_type']) ?></span>
                                                <?php else: ?>
                                                    <span class="text-muted opacity-50"><i class="fa-solid fa-minus"></i></span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php 
                                                if($talep['status'] == 'Beklemede') echo '<span class="status-badge bg-beklemede"><i class="fa-solid fa-hourglass-half pulse-icon"></i> İnceleniyor</span>';
                                                elseif($talep['status'] == 'Onaylandı') echo '<span class="status-badge bg-onaylandi"><i class="fa-solid fa-truck-fast"></i> Sahaya İletildi</span>';
                                                elseif($talep['status'] == 'Teslim Edildi') echo '<span class="status-badge bg-teslim"><i class="fa-solid fa-check-double"></i> Tamamlandı</span>';
                                                ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="d-block d-md-none mt-3">
                        <?php if(count($talepler) > 0): ?>
                            <?php foreach($talepler as $talep): ?>
                                <?php 
                                    $border_class = 'border-beklemede';
                                    $status_html = '<span class="status-badge bg-beklemede px-2 py-1"><i class="fa-solid fa-hourglass-half pulse-icon me-1"></i>Bekliyor</span>';
                                    
                                    if($talep['status'] == 'Onaylandı'){
                                        $border_class = 'border-onaylandi';
                                        $status_html = '<span class="status-badge bg-onaylandi px-2 py-1"><i class="fa-solid fa-truck-fast me-1"></i>Yolda</span>';
                                    } elseif($talep['status'] == 'Teslim Edildi'){
                                        $border_class = 'border-teslim';
                                        $status_html = '<span class="status-badge bg-teslim px-2 py-1"><i class="fa-solid fa-check-double me-1"></i>Teslim</span>';
                                    }
                                ?>
                                <div class="mobile-request-card <?= $border_class ?>">
                                    <div class="d-flex justify-content-between align-items-start mb-3">
                                        <h6 class="fw-bold text-dark mb-0 fs-5"><?= htmlspecialchars($talep['product_name']) ?></h6>
                                        <?= $status_html ?>
                                    </div>
                                    <div class="row g-2 mb-3">
                                        <div class="col-6">
                                            <div class="p-2 bg-light rounded-3 text-center">
                                                <small class="text-muted d-block mb-1">İstenen</small>
                                                <strong class="text-dark fs-6"><?= $talep['requested_qty'] ?> <?= htmlspecialchars($talep['unit_type']) ?></strong>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="p-2 <?= $talep['approved_qty'] ? 'bg-success bg-opacity-10' : 'bg-light' ?> rounded-3 text-center">
                                                <small class="text-muted d-block mb-1">Onaylanan</small>
                                                <strong class="<?= $talep['approved_qty'] ? 'text-success' : 'text-muted' ?> fs-6"><?= $talep['approved_qty'] ? $talep['approved_qty'].' '.htmlspecialchars($talep['unit_type']) : '-' ?></strong>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="text-muted small text-end border-top pt-2">
                                        <i class="fa-regular fa-clock me-1"></i><?= date('d.m.Y H:i', strtotime($talep['created_at'])) ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="text-center py-5">
                                <i class="fa-solid fa-folder-open fa-3x text-muted opacity-25 mb-3"></i>
                                <h6 class="text-muted">Henüz bir talep oluşturmadınız.</h6>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.5/js/dataTables.bootstrap5.min.js"></script>

    <script>
        $(document).ready(function() {
            $('.datatable').DataTable({
                "language": { "url": "//cdn.datatables.net/plug-ins/1.13.5/i18n/tr.json" },
                "pageLength": 5,
                "lengthChange": false,
                "ordering": false,
                "info": false
            });

            $('#stokSecici').change(function() {
                var secilen = $(this).find('option:selected');
                var maxStok = parseInt(secilen.data('stok'));
                var birim = secilen.data('birim');
                var input = $('#miktarGirdisi');
                var uyari = $('#stokUyari');
                var btn = $('#gonderBtn');

                if (maxStok > 0) {
                    input.prop('disabled', false).attr('max', maxStok).val('');
                    $('#maxStokYazisi').text('Maksimum ' + maxStok + ' ' + birim);
                    uyari.removeClass('d-none');
                    btn.prop('disabled', false);
                } else {
                    input.prop('disabled', true).removeAttr('max').val('');
                    uyari.addClass('d-none');
                    btn.prop('disabled', true);
                }
            });

            const urlParams = new URLSearchParams(window.location.search);
            if(urlParams.has('durum')) {
                let durum = urlParams.get('durum');
                if(durum === 'basarili') {
                    Swal.fire({
                        title: 'Gönderildi!',
                        text: 'Talebiniz başarıyla merkez depoya iletildi.',
                        icon: 'success',
                        confirmButtonColor: '#2c5364',
                        timer: 3000,
                        timerProgressBar: true
                    }).then(() => {
                        window.history.replaceState(null, null, window.location.pathname);
                    });
                } else if(durum === 'hata') {
                    Swal.fire({
                        title: 'Hata!',
                        text: 'Depodaki mevcut stoktan daha fazla ürün talep edemezsiniz.',
                        icon: 'error',
                        confirmButtonColor: '#d33'
                    }).then(() => {
                        window.history.replaceState(null, null, window.location.pathname);
                    });
                }
            }
        });
    </script>
</body>
</html>