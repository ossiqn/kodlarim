<?php
require 'config.php';

if (isset($_SESSION['user_id']) && isset($_SESSION['role'])) {
    if ($_SESSION['role'] == 'admin') header("Location: admin_panel.php");
    elseif ($_SESSION['role'] == 'birim') header("Location: birim_panel.php");
    elseif ($_SESSION['role'] == 'saha') header("Location: saha_panel.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OSSIQN Portal - Ana Sayfa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap');
        
        body {
            font-family: 'Poppins', sans-serif;
            background: radial-gradient(circle at top right, #1a2a6c, #11212b, #000000);
            height: 100vh;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            position: relative;
        }

        body::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background: url('https://www.transparenttextures.com/patterns/cubes.png');
            opacity: 0.05;
            z-index: 0;
        }

        .glass-card {
            background: rgba(25, 30, 40, 0.6);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 24px;
            padding: 4rem 3rem;
            text-align: center;
            color: white;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5);
            animation: slideUp 0.8s cubic-bezier(0.16, 1, 0.3, 1) forwards;
            opacity: 0;
            transform: translateY(40px);
            max-width: 650px;
            width: 90%;
            position: relative;
            z-index: 1;
        }

        @keyframes slideUp {
            to { opacity: 1; transform: translateY(0); }
        }

        .icon-wrapper {
            font-size: 4.5rem;
            margin-bottom: 1.5rem;
            color: #00f2fe;
            filter: drop-shadow(0 0 15px rgba(0, 242, 254, 0.4));
            animation: float 4s ease-in-out infinite;
        }

        @keyframes float {
            0% { transform: translateY(0px); }
            50% { transform: translateY(-10px); }
            100% { transform: translateY(0px); }
        }

        .brand-title {
            font-size: 2.5rem;
            font-weight: 800;
            margin-bottom: 0.5rem;
            background: linear-gradient(135deg, #fff 0%, #00f2fe 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            letter-spacing: 1px;
        }

        .description-text {
            font-size: 1.1rem;
            color: rgba(255, 255, 255, 0.7);
            margin-bottom: 2.5rem;
            line-height: 1.6;
        }

        .btn-custom {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            border: none;
            color: #000;
            padding: 16px 45px;
            font-size: 1.2rem;
            font-weight: 700;
            border-radius: 50px;
            transition: all 0.3s ease;
            box-shadow: 0 8px 25px rgba(0, 242, 254, 0.3);
            text-decoration: none;
            display: inline-block;
            letter-spacing: 0.5px;
        }

        .btn-custom:hover {
            transform: translateY(-3px) scale(1.02);
            box-shadow: 0 12px 30px rgba(0, 242, 254, 0.5);
            color: #000;
        }

        .footer-text {
            position: absolute;
            bottom: -50px;
            left: 0;
            width: 100%;
            text-align: center;
            font-size: 0.8rem;
            color: rgba(255, 255, 255, 0.3);
            letter-spacing: 2px;
        }

        @media (max-width: 576px) {
            .glass-card {
                padding: 3rem 1.5rem;
            }
            .brand-title {
                font-size: 1.8rem;
            }
            .description-text {
                font-size: 0.95rem;
            }
            .btn-custom {
                width: 100%;
                padding: 14px 20px;
                font-size: 1.1rem;
            }
        }
    </style>
</head>
<body>
    <div class="glass-card">
        <div class="icon-wrapper">
            <i class="fa-brands fa-space-awesome"></i>
        </div>
        <h1 class="brand-title">OSSIQN Portal</h1>
        <p class="description-text">Kurumsal stok yönetimi, birim talepleri ve saha operasyonlarını tek bir merkezden, yeni nesil altyapıyla dijital olarak yönetin.</p>
        <a href="login.php" class="btn-custom">
            Sisteme Geçiş Yap <i class="fa-solid fa-arrow-right ms-2"></i>
        </a>
        
        <div class="footer-text">
            DEVELOPER BY: OSSIQN
        </div>
    </div>
</body>
</html>