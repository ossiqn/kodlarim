<?php
require 'config.php';

$hata = '';
$basarili_yonlendirme = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    $sorgu = $db->prepare("SELECT * FROM users WHERE username = ?");
    $sorgu->execute([$username]);
    $kullanici = $sorgu->fetch();

    if ($kullanici && $password === $kullanici['password']) {
        $_SESSION['user_id'] = $kullanici['id'];
        $_SESSION['role'] = $kullanici['role'];
        $_SESSION['full_name'] = $kullanici['full_name'];
        $_SESSION['department_id'] = $kullanici['department_id'];

        if ($kullanici['role'] == 'admin') $basarili_yonlendirme = "admin_panel.php";
        elseif ($kullanici['role'] == 'birim') $basarili_yonlendirme = "birim_panel.php";
        elseif ($kullanici['role'] == 'saha') $basarili_yonlendirme = "saha_panel.php";
    } else {
        $hata = 'Giriş bilgileri hatalı! Lütfen kontrol edin.';
    }
} else {
    if (isset($_SESSION['user_id']) && isset($_SESSION['role'])) {
        if ($_SESSION['role'] == 'admin') header("Location: admin_panel.php");
        elseif ($_SESSION['role'] == 'birim') header("Location: birim_panel.php");
        elseif ($_SESSION['role'] == 'saha') header("Location: saha_panel.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sisteme Giriş - OSSIQN Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap');
        
        body {
            font-family: 'Poppins', sans-serif;
            background: radial-gradient(circle at top right, #1a2a6c, #11212b, #000000);
            height: 100vh;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            position: relative;
        }

        body::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background: url('https://www.transparenttextures.com/patterns/cubes.png');
            opacity: 0.05;
            z-index: 0;
        }

        .glass-card {
            background: rgba(25, 30, 40, 0.6);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 24px;
            padding: 3rem 2.5rem;
            color: white;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5);
            animation: slideUp 0.8s cubic-bezier(0.16, 1, 0.3, 1) forwards;
            opacity: 0;
            transform: translateY(40px);
            width: 100%;
            max-width: 420px;
            margin: 0 15px;
            position: relative;
            z-index: 1;
        }

        @keyframes slideUp {
            to { opacity: 1; transform: translateY(0); }
        }

        .icon-header {
            font-size: 3.5rem;
            color: #00f2fe;
            text-align: center;
            margin-bottom: 1rem;
            filter: drop-shadow(0 0 15px rgba(0, 242, 254, 0.4));
            animation: float 4s ease-in-out infinite;
        }

        @keyframes float {
            0% { transform: translateY(0px); }
            50% { transform: translateY(-8px); }
            100% { transform: translateY(0px); }
        }

        .brand-link {
            color: #fff;
            text-decoration: none;
            transition: all 0.3s ease;
            text-shadow: 0 0 10px rgba(0, 242, 254, 0.2);
            letter-spacing: 1px;
        }
        
        .brand-link:hover {
            color: #00f2fe;
            text-shadow: 0 0 20px rgba(0, 242, 254, 0.7);
        }

        .input-group-glass {
            background: rgba(0, 0, 0, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            overflow: hidden;
        }

        .input-group-glass:focus-within {
            border-color: #00f2fe;
            box-shadow: 0 0 15px rgba(0, 242, 254, 0.2);
            background: rgba(0, 0, 0, 0.4);
        }

        .input-group-text-glass {
            background: transparent;
            border: none;
            color: rgba(255, 255, 255, 0.5);
            padding: 15px;
            font-size: 1.1rem;
        }

        .form-control-glass {
            background: transparent;
            border: none;
            color: white;
            padding: 15px 15px 15px 0;
            font-size: 0.95rem;
            width: 100%;
            outline: none;
        }

        .form-control-glass::placeholder {
            color: rgba(255, 255, 255, 0.4);
        }

        .form-label {
            font-weight: 500;
            font-size: 0.85rem;
            margin-bottom: 0.5rem;
            color: rgba(255, 255, 255, 0.7);
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .btn-custom {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            border: none;
            color: #000;
            padding: 14px;
            font-size: 1.1rem;
            font-weight: 700;
            border-radius: 12px;
            transition: all 0.3s ease;
            box-shadow: 0 8px 25px rgba(0, 242, 254, 0.3);
            width: 100%;
            margin-top: 1rem;
            letter-spacing: 0.5px;
        }

        .btn-custom:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 30px rgba(0, 242, 254, 0.5);
        }

        .btn-secondary-custom {
            display: block;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            color: rgba(255, 255, 255, 0.7);
            padding: 12px;
            font-size: 0.95rem;
            font-weight: 500;
            border-radius: 12px;
            transition: all 0.3s ease;
            text-align: center;
            width: 100%;
            margin-top: 10px;
            text-decoration: none;
        }

        .btn-secondary-custom:hover {
            background: rgba(255, 255, 255, 0.1);
            color: #fff;
            transform: translateY(-2px);
        }

        .toggle-password {
            background: transparent;
            border: none;
            color: rgba(255, 255, 255, 0.5);
            padding: 15px;
            cursor: pointer;
            transition: color 0.3s;
        }

        .toggle-password:hover {
            color: #00f2fe;
        }

        .footer-text {
            position: absolute;
            bottom: -40px;
            left: 0;
            width: 100%;
            text-align: center;
            font-size: 0.75rem;
            color: rgba(255, 255, 255, 0.3);
            letter-spacing: 1px;
        }

        @media (max-width: 576px) {
            .glass-card {
                padding: 2rem 1.5rem;
                border-radius: 20px;
            }
            .icon-header {
                font-size: 2.8rem;
                margin-bottom: 0.8rem;
            }
            .brand-link {
                font-size: 1.6rem;
            }
            .form-control-glass {
                padding: 12px 12px 12px 0;
                font-size: 0.9rem;
            }
            .input-group-text-glass {
                padding: 12px;
            }
            .toggle-password {
                padding: 12px;
            }
            .btn-custom {
                padding: 12px;
                font-size: 1rem;
            }
            .btn-secondary-custom {
                padding: 10px;
                font-size: 0.9rem;
            }
            .footer-text {
                bottom: -30px;
                font-size: 0.7rem;
            }
            div.swal2-popup {
                width: 85% !important;
                padding: 1.2rem !important;
                border-radius: 16px !important;
            }
            h2.swal2-title {
                font-size: 1.3rem !important;
            }
            div.swal2-html-container {
                font-size: 0.9rem !important;
            }
        }
    </style>
</head>
<body>
    <div class="glass-card">
        <div class="icon-header">
            <i class="fa-brands fa-space-awesome"></i>
        </div>
        <h3 class="text-center fw-bold mb-1">
            <a href="https://github.com/ossiqn/kodlarim" target="_blank" class="brand-link">OSSIQN</a>
        </h3>
        <p class="text-center text-muted small mb-4">Güvenli Yönetim Portalı</p>
        
        <form method="POST" id="loginForm">
            <div class="mb-4">
                <label class="form-label">Kullanıcı Adı</label>
                <div class="input-group-glass">
                    <div class="input-group-text-glass"><i class="fa-solid fa-user"></i></div>
                    <input type="text" name="username" class="form-control-glass" placeholder="Kullanıcı adınızı girin" required autocomplete="off">
                </div>
            </div>
            <div class="mb-4">
                <label class="form-label">Şifre</label>
                <div class="input-group-glass">
                    <div class="input-group-text-glass"><i class="fa-solid fa-lock"></i></div>
                    <input type="password" name="password" id="passwordInput" class="form-control-glass" placeholder="Şifrenizi girin" required>
                    <button type="button" class="toggle-password" id="toggleBtn"><i class="fa-regular fa-eye"></i></button>
                </div>
            </div>
            <button type="submit" class="btn-custom">
                Sisteme Giriş Yap <i class="fa-solid fa-arrow-right-to-bracket ms-2"></i>
            </button>
            <a href="index.php" class="btn-secondary-custom">
                <i class="fa-solid fa-house me-1"></i> Ana Sayfaya Dön
            </a>
        </form>
        
        <div class="footer-text">
            DEVELOPER BY: OSSIQN
        </div>
    </div>

    <script>
        document.getElementById('toggleBtn').addEventListener('click', function() {
            const passInput = document.getElementById('passwordInput');
            const icon = this.querySelector('i');
            
            if (passInput.type === 'password') {
                passInput.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                passInput.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });

        document.addEventListener('DOMContentLoaded', function() {
            <?php if($basarili_yonlendirme): ?>
                Swal.fire({
                    title: 'Giriş Başarılı!',
                    text: 'Yönlendiriliyorsunuz...',
                    icon: 'success',
                    timer: 2000,
                    timerProgressBar: true,
                    showConfirmButton: false,
                    background: '#191e28',
                    color: '#fff',
                    iconColor: '#00f2fe',
                    customClass: {
                        popup: 'border border-secondary border-opacity-25 rounded-4'
                    }
                }).then(() => {
                    window.location.href = '<?= $basarili_yonlendirme ?>';
                });
            <?php elseif($hata): ?>
                Swal.fire({
                    title: 'Erişim Reddedildi!',
                    text: '<?= htmlspecialchars($hata) ?>',
                    icon: 'error',
                    background: '#191e28',
                    color: '#fff',
                    confirmButtonColor: '#00f2fe',
                    iconColor: '#ff4b2b',
                    customClass: {
                        popup: 'border border-secondary border-opacity-25 rounded-4'
                    }
                });
                
                const card = document.querySelector('.glass-card');
                card.animate([
                    { transform: 'translateX(0)' },
                    { transform: 'translateX(-10px)' },
                    { transform: 'translateX(10px)' },
                    { transform: 'translateX(-10px)' },
                    { transform: 'translateX(10px)' },
                    { transform: 'translateX(0)' }
                ], {
                    duration: 400,
                    easing: 'ease-in-out'
                });
            <?php endif; ?>
        });
    </script>
</body>
</html>