<?php
require 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'saha') {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['islem']) && $_POST['islem'] == 'teslim_et') {
    $talep_id = $_POST['talep_id'];
    $approved_qty = $_POST['approved_qty'];
    $stock_id = $_POST['stock_id'];
    
    $photo_path = null;
    
    if (isset($_FILES['kanit_foto']) && $_FILES['kanit_foto']['error'] == 0) {
        $uzanti = strtolower(pathinfo($_FILES['kanit_foto']['name'], PATHINFO_EXTENSION));
        $yeni_isim = 'kanit_' . time() . '_' . rand(1000, 9999) . '.' . $uzanti;
        $hedef_klasor = 'uploads/kanitlar/';
        
        if (!file_exists($hedef_klasor)) { mkdir($hedef_klasor, 0777, true); }
        if (move_uploaded_file($_FILES['kanit_foto']['tmp_name'], $hedef_klasor . $yeni_isim)) {
            $photo_path = $hedef_klasor . $yeni_isim;
        }
    }

    $db->beginTransaction();
    try {
        $guncelle_talep = $db->prepare("UPDATE requests SET status = 'Teslim Edildi', photo_path = ? WHERE id = ?");
        $guncelle_talep->execute([$photo_path, $talep_id]);

        $guncelle_stok = $db->prepare("UPDATE stocks SET quantity = quantity - ? WHERE id = ?");
        $guncelle_stok->execute([$approved_qty, $stock_id]);

        $db->commit();
        header("Location: saha_panel.php?durum=basarili&tab=bekleyen");
        exit;
    } catch (Exception $e) {
        $db->rollBack();
        header("Location: saha_panel.php?durum=hata&tab=bekleyen");
        exit;
    }
}

$talepler = $db->query("
    SELECT r.id, d.name as birim_adi, s.id as stock_id, s.product_name, r.approved_qty, r.created_at 
    FROM requests r JOIN departments d ON r.department_id = d.id JOIN stocks s ON r.stock_id = s.id 
    WHERE r.status = 'Onaylandı' ORDER BY r.created_at ASC
")->fetchAll();

$gecmis_teslimatlar = $db->query("
    SELECT r.id, d.name as birim_adi, s.product_name, r.approved_qty, r.photo_path, r.updated_at 
    FROM requests r JOIN departments d ON r.department_id = d.id JOIN stocks s ON r.stock_id = s.id 
    WHERE r.status = 'Teslim Edildi' ORDER BY r.updated_at DESC LIMIT 50
")->fetchAll();

$active_tab = isset($_GET['tab']) ? $_GET['tab'] : 'bekleyen';
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Saha Paneli - Teslimat Onayı</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
        body { font-family: 'Poppins', sans-serif; background-color: #f4f7fa; padding-bottom: 70px; }
        .navbar-custom { background: linear-gradient(135deg, #e52d27 0%, #b31217 100%); box-shadow: 0 4px 20px rgba(229, 45, 39, 0.2); }
        
        @keyframes slideInUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
        .animated-card { animation: slideInUp 0.5s ease-out forwards; opacity: 0; }
        
        .nav-pills-custom { background: #fff; padding: 8px; border-radius: 16px; box-shadow: 0 4px 15px rgba(0,0,0,0.03); }
        .nav-pills-custom .nav-link { color: #64748b; font-weight: 600; border-radius: 12px; padding: 12px 20px; border: none; transition: all 0.3s; }
        .nav-pills-custom .nav-link:hover { color: #e52d27; }
        .nav-pills-custom .nav-link.active { background: #e52d27; color: white; box-shadow: 0 4px 15px rgba(229, 45, 39, 0.3); }

        .delivery-card { background: #ffffff; border-radius: 20px; box-shadow: 0 8px 25px rgba(0,0,0,0.04); border: none; border-left: 6px solid #e52d27; padding: 25px; margin-bottom: 25px; transition: transform 0.2s; }
        .history-card { background: #ffffff; border-radius: 18px; border-left: 6px solid #10b981; padding: 20px; margin-bottom: 15px; box-shadow: 0 5px 20px rgba(0,0,0,0.03); }
        
        .file-upload-wrapper { position: relative; overflow: hidden; display: inline-block; width: 100%; }
        .file-upload-wrapper input[type=file] { font-size: 100px; position: absolute; left: 0; top: 0; opacity: 0; cursor: pointer; height: 100%; }
        .btn-upload-ui { background-color: #f8fafc; color: #64748b; border: 2px dashed #cbd5e1; border-radius: 16px; padding: 20px; text-align: center; font-weight: 600; transition: all 0.3s; width: 100%; display: flex; flex-direction: column; align-items: center; justify-content: center; min-height: 120px; }
        .file-upload-wrapper:hover .btn-upload-ui { background-color: #fef2f2; border-color: #e52d27; color: #e52d27; }
        
        .btn-custom-deliver { background: linear-gradient(135deg, #e52d27, #b31217); border: none; color: white; border-radius: 14px; font-weight: 600; padding: 14px; width: 100%; box-shadow: 0 8px 20px rgba(229, 45, 39, 0.25); transition: all 0.3s; }
        .btn-custom-deliver:hover { transform: translateY(-2px); box-shadow: 0 10px 25px rgba(229, 45, 39, 0.35); color: white; }

        .preview-btn { background: rgba(16, 185, 129, 0.1); color: #10b981; border: 1px solid rgba(16, 185, 129, 0.2); border-radius: 10px; padding: 6px 15px; font-weight: 600; transition: all 0.2s; cursor: pointer; }
        .preview-btn:hover { background: #10b981; color: white; }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom sticky-top">
        <div class="container py-2">
            <a class="navbar-brand fw-bold fs-4" href="#"><i class="fa-solid fa-motorcycle me-2 text-warning"></i>Saha Lojistik</a>
            <div class="d-flex align-items-center">
                <span class="text-light me-4 d-none d-sm-inline opacity-75"><i class="fa-solid fa-helmet-safety me-2"></i><?= htmlspecialchars($_SESSION['full_name'] ?? 'Kurye') ?></span>
                <a href="logout.php" class="btn btn-dark btn-sm rounded-pill px-4 fw-bold shadow"><i class="fa-solid fa-right-from-bracket me-2"></i>Çıkış</a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="d-flex justify-content-center mb-4 animated-card" style="animation-delay: 0.1s;">
            <ul class="nav nav-pills nav-pills-custom" id="sahaTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?= $active_tab == 'bekleyen' ? 'active' : '' ?>" id="bekleyen-tab" data-bs-toggle="tab" data-bs-target="#bekleyen" type="button" role="tab"><i class="fa-solid fa-route me-2"></i>Dağıtılacaklar <span class="badge bg-white text-danger ms-1 rounded-pill"><?= count($talepler) ?></span></button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?= $active_tab == 'gecmis' ? 'active' : '' ?>" id="gecmis-tab" data-bs-toggle="tab" data-bs-target="#gecmis" type="button" role="tab"><i class="fa-solid fa-check-double me-2"></i>Teslim Ettiklerim</button>
                </li>
            </ul>
        </div>

        <div class="tab-content animated-card" style="animation-delay: 0.2s;" id="sahaTabsContent">
            
            <div class="tab-pane fade <?= $active_tab == 'bekleyen' ? 'show active' : '' ?>" id="bekleyen" role="tabpanel">
                <div class="row justify-content-center">
                    <?php if(count($talepler) > 0): ?>
                        <?php foreach($talepler as $talep): ?>
                            <div class="col-md-8 col-lg-6">
                                <div class="delivery-card">
                                    <div class="d-flex justify-content-between align-items-center border-bottom pb-3 mb-4">
                                        <div>
                                            <h4 class="fw-bold text-dark mb-1"><?= htmlspecialchars($talep['product_name']) ?></h4>
                                            <div class="text-danger fw-bold fs-6"><i class="fa-solid fa-location-dot me-2"></i><?= htmlspecialchars($talep['birim_adi']) ?></div>
                                        </div>
                                        <div class="text-center bg-danger bg-opacity-10 rounded-4 p-3 border border-danger border-opacity-25">
                                            <span class="d-block small text-danger fw-bold text-uppercase mb-1" style="font-size: 0.75rem;">Miktar</span>
                                            <strong class="fs-2 text-danger lh-1"><?= $talep['approved_qty'] ?></strong>
                                        </div>
                                    </div>
                                    <form method="POST" enctype="multipart/form-data">
                                        <input type="hidden" name="islem" value="teslim_et">
                                        <input type="hidden" name="talep_id" value="<?= $talep['id'] ?>">
                                        <input type="hidden" name="approved_qty" value="<?= $talep['approved_qty'] ?>">
                                        <input type="hidden" name="stock_id" value="<?= $talep['stock_id'] ?>">
                                        <div class="mb-4">
                                            <label class="small text-muted fw-bold text-uppercase mb-2"><i class="fa-solid fa-camera text-danger me-2"></i>Teslimat Fişi (Islak İmza)</label>
                                            <div class="file-upload-wrapper">
                                                <div class="btn-upload-ui">
                                                    <i class="fa-solid fa-image fa-2x mb-2 text-secondary"></i>
                                                    <span>Kamerayı Aç / Fotoğraf Seç</span>
                                                </div>
                                                <input type="file" name="kanit_foto" class="file-input" accept="image/*" capture="environment" required>
                                            </div>
                                        </div>
                                        <button type="submit" class="btn btn-custom-deliver"><i class="fa-solid fa-check-double me-2"></i>Teslim Edildi İşaretle</button>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="col-12"><div class="text-center py-5 text-muted bg-white rounded-4 shadow-sm"><i class="fa-solid fa-mug-hot fa-4x mb-3 d-block opacity-25 text-danger"></i><h5 class="fw-bold">Tüm siparişler dağıtıldı, bekleyen iş yok.</h5></div></div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="tab-pane fade <?= $active_tab == 'gecmis' ? 'show active' : '' ?>" id="gecmis" role="tabpanel">
                <div class="row">
                    <?php if(count($gecmis_teslimatlar) > 0): ?>
                        <?php foreach($gecmis_teslimatlar as $gecmis): ?>
                            <div class="col-md-6 col-lg-4">
                                <div class="history-card">
                                    <div class="d-flex justify-content-between mb-3">
                                        <h5 class="fw-bold text-dark mb-0"><?= htmlspecialchars($gecmis['product_name']) ?></h5>
                                        <div class="text-end">
                                            <span class="badge bg-light text-dark border fs-6"><?= $gecmis['approved_qty'] ?> Adet</span>
                                        </div>
                                    </div>
                                    <div class="text-muted mb-3"><i class="fa-solid fa-location-dot text-success me-2"></i><?= htmlspecialchars($gecmis['birim_adi']) ?></div>
                                    <div class="d-flex justify-content-between align-items-center border-top pt-3">
                                        <div>
                                            <span class="text-success fw-bold small d-block"><i class="fa-solid fa-check-circle me-1"></i>Tamamlandı</span>
                                            <span class="small text-muted opacity-75"><?= date('d.m.Y H:i', strtotime($gecmis['updated_at'])) ?></span>
                                        </div>
                                        <?php if($gecmis['photo_path']): ?>
                                            <button type="button" onclick="resmiBuyut('<?= $gecmis['photo_path'] ?>')" class="preview-btn"><i class="fa-solid fa-expand me-1"></i>Fişi Gör</button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="col-12"><div class="text-center py-5 text-muted bg-white rounded-4 shadow-sm"><i class="fa-solid fa-box-open fa-3x mb-3 d-block opacity-25"></i><h6 class="fw-bold">Henüz teslimat geçmişiniz yok.</h6></div></div>
                    <?php endif; ?>
                </div>
            </div>

        </div>
    </div>

    <div class="modal fade" id="imageModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content bg-transparent border-0">
                <div class="modal-body p-0 text-center position-relative">
                    <button type="button" class="btn-close btn-close-white position-absolute top-0 end-0 m-3 shadow" data-bs-dismiss="modal" style="z-index: 10;"></button>
                    <img src="" id="modalImage" class="img-fluid rounded-4 shadow-lg" style="max-height: 85vh; border: 4px solid white;">
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Dosya seçildiğinde UI'ı değiştirme (Akıllı Buton)
            const fileInputs = document.querySelectorAll('.file-input');
            fileInputs.forEach(input => {
                input.addEventListener('change', function(e) {
                    if(e.target.files.length > 0) {
                        const fileName = e.target.files[0].name;
                        const ui = this.previousElementSibling;
                        ui.innerHTML = `<i class="fa-solid fa-circle-check fa-2x mb-2 text-success"></i>
                                        <span class="text-success fw-bold d-block">Fotoğraf Seçildi</span>
                                        <small class="text-muted text-truncate w-100 px-3 mt-1 d-block">${fileName}</small>`;
                        ui.style.borderColor = '#10b981';
                        ui.style.backgroundColor = '#ecfdf5';
                    }
                });
            });

            // SweetAlert2 Başarı/Hata Bildirimleri
            const urlParams = new URLSearchParams(window.location.search);
            if(urlParams.has('durum')) {
                let durum = urlParams.get('durum');
                if(durum === 'basarili') {
                    Swal.fire({
                        title: 'Harika!',
                        text: 'Teslimat onaylandı ve stoktan düşüldü.',
                        icon: 'success',
                        confirmButtonColor: '#10b981',
                        timer: 2500,
                        timerProgressBar: true
                    }).then(() => {
                        window.history.replaceState(null, null, window.location.pathname + '?tab=bekleyen');
                    });
                } else if(durum === 'hata') {
                    Swal.fire({
                        title: 'Hata!',
                        text: 'Teslimat sırasında bir sorun oluştu.',
                        icon: 'error',
                        confirmButtonColor: '#e52d27'
                    }).then(() => {
                        window.history.replaceState(null, null, window.location.pathname + '?tab=bekleyen');
                    });
                }
            }
        });

        // Fiş Fotoğrafını Modalda Açma Fonksiyonu
        function resmiBuyut(src) {
            document.getElementById('modalImage').src = src;
            new bootstrap.Modal(document.getElementById('imageModal')).show();
        }
    </script>
</body>
</html>