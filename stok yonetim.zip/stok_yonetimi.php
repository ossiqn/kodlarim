<?php
require 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit;
}

// Yeni Ürün Ekleme İşlemi
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['islem']) && $_POST['islem'] == 'yeni_ekle') {
    $product_name = $_POST['product_name'];
    $sku = $_POST['sku'];
    $quantity = $_POST['quantity'];
    $unit_type = $_POST['unit_type'];
    $low_limit = $_POST['low_limit'];

    $ekle = $db->prepare("INSERT INTO stocks (product_name, sku, quantity, unit_type, low_limit) VALUES (?, ?, ?, ?, ?)");
    $ekle->execute([$product_name, $sku, $quantity, $unit_type, $low_limit]);
    
    header("Location: stok_yonetimi.php?durum=eklendi");
    exit;
}

// Mevcut Stoğu Güncelleme İşlemi
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['islem']) && $_POST['islem'] == 'stok_guncelle') {
    $stock_id = $_POST['stock_id'];
    $eklenen_miktar = $_POST['eklenen_miktar'];

    $guncelle = $db->prepare("UPDATE stocks SET quantity = quantity + ? WHERE id = ?");
    $guncelle->execute([$eklenen_miktar, $stock_id]);
    
    header("Location: stok_yonetimi.php?durum=guncellendi");
    exit;
}

$stoklar = $db->query("SELECT * FROM stocks ORDER BY product_name ASC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stok Yönetimi - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap');
        body { font-family: 'Poppins', sans-serif; background-color: #f0f4f8; padding-bottom: 50px; }
        .navbar-custom { background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%); box-shadow: 0 4px 15px rgba(30, 60, 114, 0.3); }
        .glass-panel { background: #ffffff; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); border: none; overflow: hidden; }
        .form-control-custom { border-radius: 10px; border: 2px solid #eee; transition: all 0.3s; }
        .form-control-custom:focus { border-color: #2a5298; box-shadow: 0 0 0 0.2rem rgba(42, 82, 152, 0.25); }
        .btn-custom { background: linear-gradient(135deg, #1e3c72, #2a5298); border: none; color: white; border-radius: 10px; font-weight: bold; transition: all 0.3s; }
        .btn-custom:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(30, 60, 114, 0.4); color: white; }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom sticky-top">
        <div class="container-fluid py-1">
            <a class="navbar-brand fw-bold" href="admin_panel.php"><i class="fa-solid fa-shield-halved me-2"></i>Admin Paneli</a>
            <div class="d-flex align-items-center">
                <a href="admin_panel.php" class="btn btn-sm btn-light text-primary rounded-pill px-3 fw-bold shadow-sm me-2"><i class="fa-solid fa-arrow-left me-1"></i>Taleplere Dön</a>
                <a href="logout.php" class="btn btn-sm btn-danger rounded-pill px-3 fw-bold shadow-sm"><i class="fa-solid fa-power-off"></i></a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <?php if(isset($_GET['durum']) && $_GET['durum'] == 'eklendi'): ?>
            <div class="alert alert-success rounded-4 shadow-sm fw-bold"><i class="fa-solid fa-circle-check me-2"></i>Yeni ürün depoya başarıyla eklendi!</div>
        <?php elseif(isset($_GET['durum']) && $_GET['durum'] == 'guncellendi'): ?>
            <div class="alert alert-info rounded-4 shadow-sm fw-bold"><i class="fa-solid fa-boxes-stacked me-2"></i>Mevcut ürünün stoğu başarıyla artırıldı!</div>
        <?php endif; ?>

        <div class="row">
            <div class="col-lg-4 mb-4">
                <div class="glass-panel p-4">
                    <h5 class="fw-bold mb-4 text-dark"><i class="fa-solid fa-plus-circle text-primary me-2"></i>Sıfırdan Ürün Ekle</h5>
                    <form method="POST">
                        <input type="hidden" name="islem" value="yeni_ekle">
                        <div class="mb-3">
                            <label class="form-label small fw-bold text-muted text-uppercase">Ürün Adı</label>
                            <input type="text" name="product_name" class="form-control form-control-custom" placeholder="Örn: Nitril Eldiven" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label small fw-bold text-muted text-uppercase">Barkod / SKU Kodu</label>
                            <input type="text" name="sku" class="form-control form-control-custom" placeholder="Örn: ELD-001" required>
                        </div>
                        <div class="row mb-3">
                            <div class="col-6">
                                <label class="form-label small fw-bold text-muted text-uppercase">Miktar</label>
                                <input type="number" name="quantity" class="form-control form-control-custom" min="0" required>
                            </div>
                            <div class="col-6">
                                <label class="form-label small fw-bold text-muted text-uppercase">Birim</label>
                                <select name="unit_type" class="form-select form-control-custom" required>
                                    <option value="Adet">Adet</option>
                                    <option value="Kutu">Kutu</option>
                                    <option value="Koli">Koli</option>
                                    <option value="Litre">Litre</option>
                                </select>
                            </div>
                        </div>
                        <div class="mb-4">
                            <label class="form-label small fw-bold text-muted text-uppercase">Kritik Stok Uyarı Sınırı</label>
                            <input type="number" name="low_limit" class="form-control form-control-custom" value="10" min="1" required>
                            <div class="form-text small">Bu rakamın altına düşerse panelde kırmızı uyarı verir.</div>
                        </div>
                        <button type="submit" class="btn btn-custom w-100 fs-6"><i class="fa-solid fa-save me-2"></i>Depoya Kaydet</button>
                    </form>
                </div>
            </div>

            <div class="col-lg-8 mb-4">
                <div class="glass-panel p-4">
                    <h5 class="fw-bold mb-4 text-dark"><i class="fa-solid fa-warehouse text-secondary me-2"></i>Mevcut Depo Durumu</h5>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light text-muted small text-uppercase">
                                <tr>
                                    <th>Ürün Adı</th>
                                    <th>Kodu</th>
                                    <th class="text-center">Mevcut Stok</th>
                                    <th>Hızlı Stok Ekle</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($stoklar) > 0): ?>
                                    <?php foreach($stoklar as $stok): ?>
                                        <tr>
                                            <td class="fw-bold text-dark"><?= htmlspecialchars($stok['product_name']) ?></td>
                                            <td class="text-muted small"><?= htmlspecialchars($stok['sku']) ?></td>
                                            <td class="text-center">
                                                <?php if($stok['quantity'] <= $stok['low_limit']): ?>
                                                    <span class="badge bg-danger rounded-pill px-3 py-2 animate__animated animate__pulse animate__infinite"><?= $stok['quantity'] ?> <?= $stok['unit_type'] ?></span>
                                                <?php else: ?>
                                                    <span class="badge bg-success rounded-pill px-3 py-2"><?= $stok['quantity'] ?> <?= $stok['unit_type'] ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <td style="width: 200px;">
                                                <form method="POST" class="d-flex">
                                                    <input type="hidden" name="islem" value="stok_guncelle">
                                                    <input type="hidden" name="stock_id" value="<?= $stok['id'] ?>">
                                                    <div class="input-group input-group-sm">
                                                        <input type="number" name="eklenen_miktar" class="form-control form-control-custom text-center" placeholder="+ Ekle" min="1" required>
                                                        <button type="submit" class="btn btn-success"><i class="fa-solid fa-plus"></i></button>
                                                    </div>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr><td colspan="4" class="text-center py-4 text-muted">Depoda hiç ürün yok. Sol taraftan ürün ekleyin.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>