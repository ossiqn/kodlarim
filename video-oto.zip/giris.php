<?php
session_start();
require_once 'config.php';

if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$error = '';
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username && $password) {
        $stmt = $db->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$username, $username]);
        $user = $stmt->fetch();

        if ($user) {
            $isPasswordCorrect = false;
            
            if (password_verify($password, $user['password'])) {
                $isPasswordCorrect = true;
            } elseif ($password === $user['password']) {
                $isPasswordCorrect = true;
                $newHash = password_hash($password, PASSWORD_DEFAULT);
                $db->prepare("UPDATE users SET password = ? WHERE id = ?")->execute([$newHash, $user['id']]);
            }

            if ($isPasswordCorrect) {
                if ($user['is_banned'] == 1) {
                    $error = 'Hesabınız sistemden uzaklaştırılmış.';
                } else {
                    $_SESSION['user_id'] = $user['id'];
                    $success = true;
                }
            } else {
                $error = 'Kullanıcı adı veya şifre hatalı.';
            }
        } else {
            $error = 'Kullanıcı adı veya şifre hatalı.';
        }
    } else {
        $error = 'Lütfen tüm alanları doldurun.';
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Giriş Yap · ossiqn</title>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<style>
:root {
    --bg: #050505;
    --panel: #0f0f13;
    --border: rgba(255, 255, 255, 0.06);
    --text-m: #ffffff;
    --text-s: #8a8f98;
    --primary: #6366f1;
    --accent: #ec4899;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
body { background-color: var(--bg); color: var(--text-m); font-family: 'Outfit', sans-serif; min-height: 100vh; display: flex; align-items: center; justify-content: center; background-image: radial-gradient(circle at 50% 0%, rgba(99, 102, 241, 0.15), transparent 40%); }
.auth-box { width: 100%; max-width: 400px; background: var(--panel); border: 1px solid var(--border); border-radius: 24px; padding: 40px; backdrop-filter: blur(20px); box-shadow: 0 25px 50px rgba(0,0,0,0.5); }
.brand { text-align: center; margin-bottom: 30px; }
.brand i { font-size: 40px; color: var(--primary); margin-bottom: 10px; }
.brand h1 { font-size: 28px; font-weight: 800; letter-spacing: -1px; }
.brand p { color: var(--text-s); font-size: 14px; margin-top: 5px; }
.inp-group { margin-bottom: 20px; }
.inp-group label { display: block; font-size: 13px; font-weight: 600; color: var(--text-s); margin-bottom: 8px; text-transform: uppercase; letter-spacing: 1px; }
.inp-field { width: 100%; background: rgba(0, 0, 0, 0.3); border: 1px solid var(--border); border-radius: 14px; padding: 14px 18px; color: var(--text-m); font-family: inherit; font-size: 15px; transition: all 0.3s; }
.inp-field:focus { outline: none; border-color: var(--primary); background: rgba(99, 102, 241, 0.05); }
.btn-submit { width: 100%; background: linear-gradient(135deg, var(--primary), var(--accent)); color: #fff; border: none; border-radius: 14px; padding: 16px; font-size: 16px; font-weight: 700; font-family: inherit; cursor: pointer; transition: all 0.3s; margin-top: 10px; box-shadow: 0 10px 25px rgba(99, 102, 241, 0.2); }
.btn-submit:hover { transform: translateY(-2px); box-shadow: 0 15px 35px rgba(99, 102, 241, 0.4); }
.auth-links { text-align: center; margin-top: 24px; font-size: 14px; color: var(--text-s); }
.auth-links a { color: var(--primary); text-decoration: none; font-weight: 600; transition: 0.3s; }
.auth-links a:hover { color: var(--accent); }
.swal2-popup { background: var(--panel) !important; color: var(--text-m) !important; border: 1px solid var(--border) !important; border-radius: 24px !important; font-family: 'Outfit', sans-serif !important; }
</style>
</head>
<body>

<div class="auth-box">
    <div class="brand">
        <i class="fas fa-layer-group"></i>
        <h1>ossiqn'e Giriş Yap</h1>
        <p>Hesaplarını yönetmek için oturum aç.</p>
    </div>

    <form method="POST">
        <div class="inp-group">
            <label>Kullanıcı Adı veya E-posta</label>
            <input type="text" name="username" class="inp-field" required>
        </div>
        <div class="inp-group">
            <label>Şifre</label>
            <input type="password" name="password" class="inp-field" required>
        </div>
        <button type="submit" class="btn-submit">Giriş Yap</button>
    </form>

    <div class="auth-links">
        Hesabın yok mu? <a href="kayit.php">Hemen Kayıt Ol</a>
    </div>
</div>

<?php if ($error): ?>
<script>
Swal.fire({
    icon: 'error',
    title: 'Giriş Başarısız',
    text: '<?= sanitize($error) ?>',
    confirmButtonColor: '#ef4444'
});
</script>
<?php endif; ?>

<?php if ($success): ?>
<script>
Swal.fire({
    icon: 'success',
    title: 'Giriş Başarılı!',
    text: 'Sisteme yönlendiriliyorsunuz, lütfen bekleyin...',
    timer: 3000,
    timerProgressBar: true,
    showConfirmButton: false,
    allowOutsideClick: false
}).then(() => {
    window.location.href = 'index.php';
});
</script>
<?php endif; ?>

</body>
</html>