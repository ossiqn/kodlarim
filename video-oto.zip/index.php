<?php
require_once 'config.php';

$is_logged_in = isset($_SESSION['user_id']);
$me = null;
$connected_platforms = [];

if ($is_logged_in) {
    $me = currentUser($db);
    if (!$me) {
        session_destroy();
        header("Location: index.php");
        exit;
    }

    try {
        $db->exec("CREATE TABLE IF NOT EXISTS user_social_tokens (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            platform VARCHAR(50) NOT NULL,
            access_token VARCHAR(255) NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY(user_id, platform)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
        
        if (isset($_GET['auth_success']) && isset($_GET['token'])) {
            $plat = sanitize($_GET['auth_success']);
            $tok = sanitize($_GET['token']);
            $stmt = $db->prepare("INSERT INTO user_social_tokens (user_id, platform, access_token) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE access_token = ?");
            $stmt->execute([$me['id'], $plat, $tok, $tok]);
            $_SESSION['flash_msg'] = ucfirst($plat) . " hesabınız başarıyla bağlandı!";
            header("Location: index.php");
            exit;
        }
        
        $stmt = $db->prepare("SELECT platform FROM user_social_tokens WHERE user_id = ?");
        $stmt->execute([$me['id']]);
        $connected_platforms = $stmt->fetchAll(PDO::FETCH_COLUMN);
    } catch (Exception $e) {}
}

$flash_msg = '';
if (isset($_SESSION['flash_msg'])) {
    $flash_msg = $_SESSION['flash_msg'];
    unset($_SESSION['flash_msg']);
}

$plats = [
    'youtube' => ['YouTube', 'yt', 'fab fa-youtube'],
    'tiktok' => ['TikTok', 'tk', 'fab fa-tiktok'],
    'instagram' => ['Instagram', 'ig', 'fab fa-instagram'],
    'facebook' => ['Facebook', 'fb', 'fab fa-facebook-f'],
    'twitter' => ['X (Twitter)', 'tw', 'fab fa-x-twitter'],
    'linkedin' => ['LinkedIn', 'in', 'fab fa-linkedin-in'],
    'pinterest' => ['Pinterest', 'pi', 'fab fa-pinterest-p'],
    'reddit' => ['Reddit', 'rd', 'fab fa-reddit-alien'],
    'snapchat' => ['Snapchat', 'sn', 'fab fa-snapchat-ghost'],
    'twitch' => ['Twitch', 'twc', 'fab fa-twitch'],
    'vimeo' => ['Vimeo', 'vm', 'fab fa-vimeo-v'],
    'dailymotion' => ['Dailymotion', 'dm', 'fas fa-play'],
    'telegram' => ['Telegram', 'tg', 'fab fa-telegram-plane']
];
?>
<!DOCTYPE html>
<html lang="tr" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $is_logged_in ? 'Dashboard' : 'Ossiqn · İçerik Dağıtım Merkezi' ?></title>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<style>
:root {
    --bg: #050505;
    --panel: #0f0f13;
    --panel-hover: #16161b;
    --border: rgba(255, 255, 255, 0.06);
    --border-hl: rgba(255, 255, 255, 0.15);
    --text-m: #ffffff;
    --text-s: #8a8f98;
    --primary: #6366f1;
    --primary-glow: rgba(99, 102, 241, 0.3);
    --accent: #ec4899;
    --success: #10b981;
    --danger: #ef4444;
    --yt: #ff0000;
    --tk: #00f2fe;
    --ig: #e1306c;
    --fb: #1877f2;
    --tw: #ffffff;
    --in: #0077b5;
    --pi: #e60023;
    --rd: #ff4500;
    --sn: #fffc00;
    --twc: #9146ff;
    --vm: #1ab7ea;
    --dm: #0066dc;
    --tg: #0088cc;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
body { background-color: var(--bg); color: var(--text-m); font-family: 'Outfit', sans-serif; min-height: 100vh; overflow-x: hidden; background-image: radial-gradient(circle at 15% 50%, rgba(99, 102, 241, 0.08), transparent 25%), radial-gradient(circle at 85% 30%, rgba(236, 72, 153, 0.08), transparent 25%); }
a { text-decoration: none; color: inherit; }
.navbar { padding: 20px 40px; border-bottom: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center; background: rgba(15, 15, 19, 0.8); backdrop-filter: blur(20px); position: sticky; top: 0; z-index: 100; }
.nav-brand { font-size: 24px; font-weight: 800; display: flex; align-items: center; gap: 10px; color: var(--text-m); }
.nav-brand i { color: var(--primary); }
.nav-actions { display: flex; align-items: center; gap: 16px; }
.btn { padding: 12px 24px; border-radius: 12px; font-size: 14px; font-weight: 700; font-family: inherit; cursor: pointer; transition: all 0.3s; display: inline-flex; align-items: center; gap: 8px; border: none; }
.btn-ghost { background: transparent; color: var(--text-m); border: 1px solid var(--border); }
.btn-ghost:hover { background: var(--panel-hover); border-color: var(--border-hl); }
.btn-primary { background: linear-gradient(135deg, var(--primary), var(--accent)); color: #fff; box-shadow: 0 10px 20px rgba(99, 102, 241, 0.2); }
.btn-primary:hover { transform: translateY(-2px); box-shadow: 0 15px 30px rgba(99, 102, 241, 0.4); }
.btn-danger { background: rgba(239, 68, 68, 0.1); color: var(--danger); border: 1px solid rgba(239, 68, 68, 0.2); }
.btn-danger:hover { background: rgba(239, 68, 68, 0.2); }
.hero { padding: 100px 20px; text-align: center; max-width: 800px; margin: 0 auto; }
.hero-tag { display: inline-block; padding: 6px 16px; background: rgba(99, 102, 241, 0.1); color: var(--primary); border: 1px solid rgba(99, 102, 241, 0.2); border-radius: 100px; font-size: 12px; font-weight: 800; letter-spacing: 1px; text-transform: uppercase; margin-bottom: 24px; }
.hero h1 { font-size: 56px; font-weight: 900; line-height: 1.1; letter-spacing: -2px; margin-bottom: 24px; }
.hero h1 span { background: linear-gradient(135deg, var(--primary), var(--accent)); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
.hero p { font-size: 18px; color: var(--text-s); line-height: 1.6; margin-bottom: 40px; }
.layout { width: 100%; max-width: 1400px; margin: 0 auto; padding: 40px; display: grid; grid-template-columns: 350px 1fr; gap: 40px; align-items: start; }
.card { background: var(--panel); border: 1px solid var(--border); border-radius: 24px; padding: 32px; margin-bottom: 24px; backdrop-filter: blur(20px); }
.card-title { font-size: 18px; font-weight: 700; margin-bottom: 20px; display: flex; align-items: center; gap: 10px; border-bottom: 1px solid var(--border); padding-bottom: 16px; }
.card-title i { color: var(--primary); }
.user-profile { text-align: center; margin-bottom: 30px; }
.user-avatar { width: 80px; height: 80px; border-radius: 20px; margin: 0 auto 16px; background: linear-gradient(135deg, var(--primary), var(--accent)); display: flex; align-items: center; justify-content: center; font-size: 32px; font-weight: 800; color: #fff; box-shadow: 0 10px 25px rgba(99, 102, 241, 0.3); }
.user-name { font-size: 20px; font-weight: 800; margin-bottom: 4px; }
.user-email { font-size: 13px; color: var(--text-s); }
.acc-list { display: flex; flex-direction: column; gap: 12px; }
.acc-item { display: flex; align-items: center; justify-content: space-between; padding: 16px; background: rgba(0, 0, 0, 0.2); border: 1px solid var(--border); border-radius: 14px; transition: 0.3s; }
.acc-item:hover { border-color: var(--border-hl); background: rgba(255, 255, 255, 0.02); }
.acc-info { display: flex; align-items: center; gap: 12px; font-weight: 600; font-size: 14px; }
.acc-info i { font-size: 20px; }
.acc-btn { padding: 8px 16px; border-radius: 10px; font-size: 12px; font-weight: 700; cursor: pointer; border: none; transition: 0.3s; font-family: inherit; }
.btn-connect { background: rgba(99, 102, 241, 0.1); color: var(--primary); border: 1px solid rgba(99, 102, 241, 0.2); text-decoration: none; display: inline-block; }
.btn-connect:hover { background: rgba(99, 102, 241, 0.2); }
.btn-disconnect { background: rgba(239, 68, 68, 0.1); color: var(--danger); border: 1px solid rgba(239, 68, 68, 0.2); }
.btn-disconnect:hover { background: rgba(239, 68, 68, 0.2); }
.pag-controls { display: flex; justify-content: space-between; align-items: center; margin-top: 16px; }
.pag-btn { padding: 8px 16px; border-radius: 8px; background: rgba(255,255,255,0.05); border: 1px solid var(--border); color: var(--text-s); cursor: pointer; transition: 0.3s; font-size: 12px; font-weight: 700; }
.pag-btn:hover:not(:disabled) { background: var(--primary); color: #fff; border-color: var(--primary); }
.pag-btn:disabled { opacity: 0.3; cursor: not-allowed; }
.pag-info { font-size: 12px; font-weight: 700; color: var(--text-s); }
.dropzone { border: 2px dashed var(--border-hl); border-radius: 20px; padding: 40px 20px; text-align: center; cursor: pointer; transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1); background: rgba(255, 255, 255, 0.01); display: flex; flex-direction: column; align-items: center; justify-content: center; min-height: 250px; }
.dropzone:hover, .dropzone.dragover { border-color: var(--primary); background: rgba(99, 102, 241, 0.05); transform: scale(1.02); }
.dz-icon { width: 70px; height: 70px; border-radius: 50%; background: rgba(255, 255, 255, 0.03); display: flex; align-items: center; justify-content: center; font-size: 28px; color: var(--primary); margin-bottom: 20px; transition: all 0.3s; }
.dropzone:hover .dz-icon { background: var(--primary); color: #fff; box-shadow: 0 0 30px var(--primary-glow); }
.dz-title { font-size: 18px; font-weight: 700; margin-bottom: 8px; }
.dz-desc { color: var(--text-s); font-size: 13px; }
#file-input { display: none; }
.inp-group { margin-bottom: 20px; }
.inp-group label { display: block; font-size: 12px; font-weight: 600; color: var(--text-s); margin-bottom: 8px; text-transform: uppercase; letter-spacing: 1px; }
.inp-field { width: 100%; background: rgba(0, 0, 0, 0.2); border: 1px solid var(--border); border-radius: 14px; padding: 14px 18px; color: var(--text-m); font-family: inherit; font-size: 14px; transition: all 0.3s; }
.inp-field:focus { outline: none; border-color: var(--primary); background: rgba(99, 102, 241, 0.02); }
.inp-field::placeholder { color: rgba(255, 255, 255, 0.3); }
textarea.inp-field { min-height: 120px; resize: none; }
.edit-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
.format-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; }
.format-card { position: relative; background: rgba(0, 0, 0, 0.2); border: 1px solid var(--border); border-radius: 12px; padding: 14px 8px; cursor: pointer; display: flex; flex-direction: column; align-items: center; gap: 8px; transition: all 0.3s; text-align: center; }
.format-card input { position: absolute; opacity: 0; pointer-events: none; }
.format-card i { font-size: 20px; color: var(--text-s); transition: 0.3s; }
.format-card span { font-size: 12px; font-weight: 600; color: var(--text-s); transition: 0.3s; }
.format-card:hover { border-color: var(--border-hl); background: rgba(255, 255, 255, 0.02); }
.format-card:has(input:checked) { background: rgba(99, 102, 241, 0.1); border-color: var(--primary); transform: translateY(-2px); }
.format-card:has(input:checked) i, .format-card:has(input:checked) span { color: var(--primary); }
.time-inputs { display: flex; align-items: center; gap: 10px; }
.time-box { position: relative; flex: 1; }
.time-box i { position: absolute; left: 14px; top: 50%; transform: translateY(-50%); color: var(--text-s); font-size: 12px; }
.time-box input { width: 100%; background: rgba(0, 0, 0, 0.2); border: 1px solid var(--border); border-radius: 12px; padding: 14px 14px 14px 36px; color: var(--text-m); font-family: inherit; font-size: 14px; transition: all 0.3s; }
.time-box input:focus { border-color: var(--primary); background: rgba(99, 102, 241, 0.02); outline: none; }
.time-box input::placeholder { color: rgba(255, 255, 255, 0.2); }
.plat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 12px; }
.plat-card { position: relative; background: rgba(0, 0, 0, 0.2); border: 1px solid var(--border); border-radius: 14px; padding: 16px; cursor: not-allowed; display: flex; align-items: center; gap: 10px; transition: all 0.3s; opacity: 0.4; }
.plat-card.unlocked { opacity: 1; cursor: pointer; }
.plat-card input { position: absolute; opacity: 0; pointer-events: none; }
.p-icon { font-size: 18px; color: var(--text-s); }
.p-name { font-size: 13px; font-weight: 600; color: var(--text-s); flex: 1; }
.p-check { width: 18px; height: 18px; border-radius: 50%; border: 2px solid var(--border-hl); display: flex; align-items: center; justify-content: center; font-size: 10px; color: transparent; }
.plat-card.unlocked:has(input:checked) { background: var(--panel-hover); transform: translateY(-2px); }
.plat-card.unlocked:has(input:checked) .p-name { color: var(--text-m); }
.plat-card.unlocked:has(input:checked) .p-check { background: var(--success); border-color: var(--success); color: #fff; }
<?php foreach ($plats as $k => $v): ?>
.plat-card.unlocked:has(input[value="<?= $k ?>"]:checked) { border-color: var(--<?= $v[1] ?>); box-shadow: 0 5px 15px rgba(255,255,255,0.05); }
.plat-card.unlocked:has(input[value="<?= $k ?>"]:checked) .p-icon { color: var(--<?= $v[1] ?>); }
<?php endforeach; ?>
.overlay { position: fixed; inset: 0; background: rgba(0, 0, 0, 0.8); backdrop-filter: blur(15px); display: flex; align-items: center; justify-content: center; z-index: 1000; opacity: 0; pointer-events: none; transition: opacity 0.4s; }
.overlay.active { opacity: 1; pointer-events: auto; }
.modal { width: 100%; max-width: 450px; background: var(--panel); border: 1px solid var(--border); border-radius: 28px; padding: 32px; transform: translateY(30px); transition: all 0.4s; box-shadow: 0 40px 80px rgba(0,0,0,0.8); }
.overlay.active .modal { transform: translateY(0); }
.m-title { font-size: 20px; font-weight: 800; text-align: center; margin-bottom: 24px; }
.m-step { display: flex; align-items: center; justify-content: space-between; padding: 14px 18px; background: rgba(0,0,0,0.3); border: 1px solid var(--border); border-radius: 14px; margin-bottom: 10px; }
.ms-l { display: flex; align-items: center; gap: 12px; font-weight: 600; font-size: 14px; }
.ms-r { font-size: 12px; font-weight: 700; padding: 6px 10px; border-radius: 8px; background: var(--border); color: var(--text-s); }
.ms-r.spin { background: rgba(99, 102, 241, 0.1); color: var(--primary); border: 1px solid rgba(99, 102, 241, 0.2); }
.ms-r.done { background: rgba(16, 185, 129, 0.1); color: var(--success); border: 1px solid rgba(16, 185, 129, 0.2); }
.ms-r.err { background: rgba(239, 68, 68, 0.1); color: var(--danger); border: 1px solid rgba(239, 68, 68, 0.2); }
.swal2-popup { background: var(--panel) !important; color: var(--text-m) !important; border: 1px solid var(--border) !important; border-radius: 24px !important; font-family: 'Outfit', sans-serif !important; }
.swal2-title { font-weight: 800 !important; }
@media (max-width: 1024px) { .layout { grid-template-columns: 1fr; } }
@media (max-width: 768px) { .hero h1 { font-size: 40px; } .nav-actions .btn-ghost { display: none; } }
@media (max-width: 600px) { .edit-grid, .plat-grid { grid-template-columns: 1fr; } .layout { padding: 20px; } .navbar { padding: 20px; } }
</style>
</head>
<body>

<nav class="navbar">
    <a href="index.php" class="nav-brand"><i class="fas fa-layer-group"></i> Ossiqn</a>
    <div class="nav-actions">
        <?php if (!$is_logged_in): ?>
            <a href="giris.php" class="btn btn-ghost">Giriş Yap</a>
            <a href="kayit.php" class="btn btn-primary">Kayıt Ol</a>
        <?php else: ?>
            <a href="cikis.php" class="btn btn-danger"><i class="fas fa-sign-out-alt"></i> Çıkış Yap</a>
        <?php endif; ?>
    </div>
</nav>

<?php if (!$is_logged_in): ?>
<div class="hero">
    <div class="hero-tag"><i class="fas fa-rocket"></i> Geleceğin İçerik Yönetimi</div>
    <h1>İçeriğinizi <span>Sınırların Ötesine</span> Taşıyın</h1>
    <p>Tüm sosyal medya hesaplarınıza tek bir noktadan aynı anda video yükleyin. Zaman kazanın, etkileşiminizi anında katlayın.</p>
    <a href="kayit.php" class="btn btn-primary" style="padding: 16px 36px; font-size: 16px; border-radius: 16px;">Ücretsiz Başla <i class="fas fa-arrow-right"></i></a>
</div>
<?php else: ?>
<div class="layout">
    <div class="sidebar">
        <div class="card">
            <div class="user-profile">
                <div class="user-avatar"><?= strtoupper(substr($me['username'], 0, 1)) ?></div>
                <div class="user-name"><?= sanitize($me['username']) ?></div>
                <div class="user-email"><?= sanitize($me['email']) ?></div>
            </div>
        </div>

        <div class="card">
            <div class="card-title"><i class="fas fa-link"></i> Bağlantı Merkezi</div>
            <div class="acc-list" id="acc-list">
                <?php foreach ($plats as $key => $val): 
                    $isConnected = in_array($key, $connected_platforms);
                ?>
                <div class="acc-item">
                    <div class="acc-info"><i class="<?= $val[2] ?>" style="color:var(--<?= $val[1] ?>)"></i> <?= $val[0] ?></div>
                    <?php if ($isConnected): ?>
                        <button type="button" class="acc-btn btn-disconnect" onclick="disconnectPlatform('<?= $key ?>', '<?= $val[0] ?>')"><i class="fas fa-unlink"></i> Bağlantıyı Kes</button>
                    <?php else: ?>
                        <button type="button" class="acc-btn btn-connect" onclick="connectPlatform('<?= $key ?>', '<?= $val[0] ?>')">Bağlan</button>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
            <div class="pag-controls">
                <button type="button" class="pag-btn" id="acc-prev" onclick="changeAccPage(-1)"><i class="fas fa-chevron-left"></i></button>
                <span class="pag-info" id="acc-page-info">1 / 1</span>
                <button type="button" class="pag-btn" id="acc-next" onclick="changeAccPage(1)"><i class="fas fa-chevron-right"></i></button>
            </div>
            <p style="font-size: 12px; color: var(--text-s); text-align: center; margin-top: 16px;">Platformları kullanabilmek için hesaplarınızı yetkilendirin.</p>
        </div>
    </div>

    <div class="main-content">
        <form id="upload-form">
            <div class="card" style="padding: 0; overflow: hidden; border-radius: 24px;">
                <label class="dropzone" id="dz" for="file-input">
                    <div class="dz-icon" id="dz-ic"><i class="fas fa-cloud-upload-alt"></i></div>
                    <div class="dz-title" id="dz-title">Videoyu Buraya Bırakın</div>
                    <div class="dz-desc" id="dz-desc">Sınırsız Boyut Desteği - MP4, MOV</div>
                </label>
                <input type="file" id="file-input" name="video" accept="video/mp4,video/quicktime" required>
            </div>

            <div class="card">
                <div class="card-title"><i class="fas fa-sliders-h"></i> Video Düzenleme Paneli</div>
                <div class="edit-grid">
                    <div class="inp-group" style="margin:0;">
                        <label>Format Seçimi</label>
                        <div class="format-grid">
                            <label class="format-card">
                                <input type="radio" name="aspect_ratio" value="original" checked>
                                <i class="fas fa-expand"></i>
                                <span>Orijinal</span>
                            </label>
                            <label class="format-card">
                                <input type="radio" name="aspect_ratio" value="9:16">
                                <i class="fas fa-mobile-alt"></i>
                                <span>Dikey</span>
                            </label>
                            <label class="format-card">
                                <input type="radio" name="aspect_ratio" value="16:9">
                                <i class="fas fa-desktop"></i>
                                <span>Yatay</span>
                            </label>
                        </div>
                    </div>
                    <div class="inp-group" style="margin:0;">
                        <label>Süre Kırpma</label>
                        <div class="time-inputs">
                            <div class="time-box">
                                <i class="fas fa-play"></i>
                                <input type="text" name="trim_start" placeholder="00:00">
                            </div>
                            <div style="color: var(--text-s); font-weight: bold;">-</div>
                            <div class="time-box">
                                <i class="fas fa-stop"></i>
                                <input type="text" name="trim_end" placeholder="Bitiş">
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-title"><i class="fas fa-pen-nib"></i> İçerik Detayları</div>
                <div class="inp-group">
                    <label>Video Başlığı</label>
                    <input type="text" name="title" class="inp-field" placeholder="Dikkat çekici bir başlık..." required>
                </div>
                <div class="inp-group">
                    <label>Açıklama & Hashtagler</label>
                    <textarea name="description" class="inp-field" placeholder="Videonuzun açıklaması..." required></textarea>
                </div>
            </div>

            <div class="card">
                <div class="card-title"><i class="fas fa-share-nodes"></i> Hedef Seçimi</div>
                <div class="plat-grid" id="plat-grid">
                    <?php foreach ($plats as $key => $val): 
                        $isConnected = in_array($key, $connected_platforms);
                    ?>
                    <label class="plat-card <?= $isConnected ? 'unlocked' : '' ?>" id="pc-<?= $key ?>">
                        <input type="checkbox" name="platforms[]" value="<?= $key ?>" <?= !$isConnected ? 'disabled' : '' ?>>
                        <i class="<?= $val[2] ?> p-icon"></i><span class="p-name"><?= $val[0] ?></span><div class="p-check"><i class="fas fa-check"></i></div>
                    </label>
                    <?php endforeach; ?>
                </div>
                <div class="pag-controls">
                    <button type="button" class="pag-btn" id="plat-prev" onclick="changePlatPage(-1)"><i class="fas fa-chevron-left"></i> Önceki</button>
                    <span class="pag-info" id="plat-page-info">1 / 1</span>
                    <button type="button" class="pag-btn" id="plat-next" onclick="changePlatPage(1)">Sonraki <i class="fas fa-chevron-right"></i></button>
                </div>
            </div>

            <button type="submit" class="btn btn-primary" style="width: 100%; padding: 20px; font-size: 16px; border-radius: 16px;">
                <i class="fas fa-rocket"></i> İşlemi Başlat ve Dağıt
            </button>
        </form>
    </div>
</div>

<div class="overlay" id="overlay">
    <div class="modal">
        <div class="m-title">Sistem İşliyor</div>
        <div id="step-list"></div>
        <button class="btn btn-primary" id="btn-done" style="display: none; background: var(--success); width:100%; margin-top:20px; box-shadow: 0 15px 30px rgba(16, 185, 129, 0.2);" onclick="location.reload()">
            Yeni İşlem Yap
        </button>
    </div>
</div>

<?php if ($flash_msg): ?>
<script>
Swal.fire({
    icon: 'success',
    title: 'Harika!',
    text: '<?= $flash_msg ?>',
    confirmButtonColor: '#10b981',
    background: 'var(--panel)',
    color: '#fff'
});
</script>
<?php endif; ?>

<script>
const platData = <?= json_encode($plats) ?>;

const accItems = document.querySelectorAll('.acc-item');
let currentAccPage = 1;
const accPerPage = 5;

function renderAccPage() {
    let totalPages = Math.ceil(accItems.length / accPerPage);
    accItems.forEach((el, index) => {
        if (index >= (currentAccPage - 1) * accPerPage && index < currentAccPage * accPerPage) {
            el.style.display = 'flex';
        } else {
            el.style.display = 'none';
        }
    });
    document.getElementById('acc-page-info').innerText = currentAccPage + ' / ' + totalPages;
    document.getElementById('acc-prev').disabled = currentAccPage === 1;
    document.getElementById('acc-next').disabled = currentAccPage === totalPages;
}
function changeAccPage(dir) { currentAccPage += dir; renderAccPage(); }

const platCards = document.querySelectorAll('.plat-card');
let currentPlatPage = 1;
const platPerPage = 6;

function renderPlatPage() {
    let totalPages = Math.ceil(platCards.length / platPerPage);
    platCards.forEach((el, index) => {
        if (index >= (currentPlatPage - 1) * platPerPage && index < currentPlatPage * platPerPage) {
            el.style.display = 'flex';
        } else {
            el.style.display = 'none';
        }
    });
    document.getElementById('plat-page-info').innerText = currentPlatPage + ' / ' + totalPages;
    document.getElementById('plat-prev').disabled = currentPlatPage === 1;
    document.getElementById('plat-next').disabled = currentPlatPage === totalPages;
}
function changePlatPage(dir) { currentPlatPage += dir; renderPlatPage(); }

document.addEventListener('DOMContentLoaded', () => { renderAccPage(); renderPlatPage(); });

function connectPlatform(platformKey, platformName) {
    Swal.fire({
        title: platformName + ' Hesabını Bağla',
        text: 'Bağlantı yöntemini seçin:',
        icon: 'question',
        showCancelButton: true,
        showDenyButton: true,
        confirmButtonText: 'Otomatik Bağlan',
        denyButtonText: 'Token ile Bağlan',
        cancelButtonText: 'İptal',
        confirmButtonColor: '#6366f1',
        denyButtonColor: '#ec4899',
        background: 'var(--panel)',
        color: '#fff'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = 'oauth.php?platform=' + platformKey;
        } else if (result.isDenied) {
            promptToken(platformKey, platformName);
        }
    });
}

function promptToken(platformKey, platformName) {
    Swal.fire({
        title: platformName + ' Token Girin',
        input: 'text',
        inputLabel: 'Token / API Key',
        inputPlaceholder: 'Token girin...',
        showCancelButton: true,
        confirmButtonText: 'Kaydet',
        cancelButtonText: 'İptal',
        confirmButtonColor: '#6366f1',
        background: 'var(--panel)',
        color: '#fff',
        inputValidator: (value) => {
            if (!value) {
                return 'Token boş olamaz!';
            }
        }
    }).then((result) => {
        if (result.isConfirmed) {
            Swal.fire({
                title: 'Kaydediliyor...',
                allowOutsideClick: false,
                background: 'var(--panel)',
                color: '#fff',
                didOpen: () => {
                    Swal.showLoading();
                    
                    let formData = new FormData();
                    formData.append('action', 'save_token');
                    formData.append('platform', platformKey);
                    formData.append('token', result.value);
                    
                    fetch('video_api.php', {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        Swal.close();
                        if (data.status === 'success') {
                            Swal.fire({
                                icon: 'success',
                                title: 'Başarılı!',
                                text: platformName + ' tokenı kaydedildi.',
                                confirmButtonColor: '#10b981',
                                background: 'var(--panel)',
                                color: '#fff'
                            }).then(() => {
                                location.reload();
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Hata!',
                                text: data.message,
                                confirmButtonColor: '#ef4444',
                                background: 'var(--panel)',
                                color: '#fff'
                            });
                        }
                    })
                    .catch(error => {
                        Swal.close();
                        Swal.fire({
                            icon: 'error',
                            title: 'Bağlantı Hatası!',
                            text: 'Sunucuya ulaşılamıyor.',
                            confirmButtonColor: '#ef4444',
                            background: 'var(--panel)',
                            color: '#fff'
                        });
                    });
                }
            });
        }
    });
}

function disconnectPlatform(platformKey, platformName) {
    Swal.fire({
        title: 'Bağlantıyı Kes',
        text: platformName + ' hesabınızın bağlantısını kaldırmak istediğinize emin misiniz?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#ef4444',
        cancelButtonColor: '#6b7280',
        confirmButtonText: 'Evet, Kes',
        cancelButtonText: 'Vazgeç',
        background: 'var(--panel)',
        color: '#fff'
    }).then((result) => {
        if (result.isConfirmed) {
            Swal.fire({
                title: 'Kaldırılıyor...',
                allowOutsideClick: false,
                background: 'var(--panel)',
                color: '#fff',
                didOpen: () => {
                    Swal.showLoading();
                    
                    let formData = new FormData();
                    formData.append('action', 'disconnect');
                    formData.append('platform', platformKey);
                    
                    fetch('video_api.php', {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        Swal.close();
                        if (data.status === 'success') {
                            Swal.fire({
                                icon: 'success',
                                title: 'Bağlantı Kesildi!',
                                text: platformName + ' hesabınız kaldırıldı.',
                                confirmButtonColor: '#10b981',
                                background: 'var(--panel)',
                                color: '#fff'
                            }).then(() => {
                                location.reload();
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Hata!',
                                text: data.message,
                                confirmButtonColor: '#ef4444',
                                background: 'var(--panel)',
                                color: '#fff'
                            });
                        }
                    })
                    .catch(error => {
                        Swal.close();
                        Swal.fire({
                            icon: 'error',
                            title: 'Bağlantı Hatası!',
                            text: 'Sunucuya ulaşılamıyor.',
                            confirmButtonColor: '#ef4444',
                            background: 'var(--panel)',
                            color: '#fff'
                        });
                    });
                }
            });
        }
    });
}

const dz = document.getElementById('dz');
const fi = document.getElementById('file-input');
const dt = document.getElementById('dz-title');
const dd = document.getElementById('dz-desc');
const di = document.getElementById('dz-ic');

['dragenter', 'dragover', 'dragleave', 'drop'].forEach(e => { dz.addEventListener(e, preventDefaults, false); });
function preventDefaults(e) { e.preventDefault(); e.stopPropagation(); }
['dragenter', 'dragover'].forEach(e => { dz.addEventListener(e, () => dz.classList.add('dragover'), false); });
['dragleave', 'drop'].forEach(e => { dz.addEventListener(e, () => dz.classList.remove('dragover'), false); });

dz.addEventListener('drop', (e) => {
    fi.files = e.dataTransfer.files;
    updateFileUI(fi.files[0]);
});

fi.addEventListener('change', function() {
    if(this.files[0]) updateFileUI(this.files[0]);
});

function updateFileUI(file) {
    dt.innerText = file.name;
    dd.innerText = 'Hazır';
    di.innerHTML = '<i class="fas fa-video"></i>';
    dz.style.borderColor = 'var(--success)';
    dz.style.background = 'transparent';
    di.style.background = 'transparent';
    di.style.color = 'var(--success)';
    di.style.boxShadow = 'none';
}

document.getElementById('upload-form').addEventListener('submit', function(e) {
    e.preventDefault();
    
    let plats = Array.from(document.querySelectorAll('input[name="platforms[]"]:checked')).map(c => c.value);
    
    if(!fi.files[0]) { Swal.fire({icon: 'error', title: 'Hata', text: 'Lütfen bir video yükleyin.', confirmButtonColor: '#ef4444', background: 'var(--panel)', color: '#fff'}); return; }
    if(plats.length === 0) { Swal.fire({icon: 'warning', title: 'Uyarı', text: 'Lütfen hedef seçin.', confirmButtonColor: '#6366f1', background: 'var(--panel)', color: '#fff'}); return; }
    
    Swal.fire({
        title: 'Video Yükleme',
        text: 'Video yükleme işlemi başlatıldı. Bu özellik şu anda geliştirilme aşamasındadır.',
        icon: 'info',
        confirmButtonColor: '#6366f1',
        background: 'var(--panel)',
        color: '#fff'
    });
});
</script>
<?php endif; ?>
</body>
</html>