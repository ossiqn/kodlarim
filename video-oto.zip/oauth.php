<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$platform = $_GET['platform'] ?? '';
if (!$platform) {
    header("Location: index.php");
    exit;
}

$plats = [
    'youtube' => ['YouTube', '#ff0000', 'fab fa-youtube'],
    'tiktok' => ['TikTok', '#00f2fe', 'fab fa-tiktok'],
    'instagram' => ['Instagram', '#e1306c', 'fab fa-instagram'],
    'facebook' => ['Facebook', '#1877f2', 'fab fa-facebook-f'],
    'twitter' => ['X (Twitter)', '#ffffff', 'fab fa-x-twitter'],
    'linkedin' => ['LinkedIn', '#0077b5', 'fab fa-linkedin-in'],
    'pinterest' => ['Pinterest', '#e60023', 'fab fa-pinterest-p'],
    'reddit' => ['Reddit', '#ff4500', 'fab fa-reddit-alien'],
    'snapchat' => ['Snapchat', '#fffc00', 'fab fa-snapchat-ghost'],
    'twitch' => ['Twitch', '#9146ff', 'fab fa-twitch'],
    'vimeo' => ['Vimeo', '#1ab7ea', 'fab fa-vimeo-v'],
    'dailymotion' => ['Dailymotion', '#0066dc', 'fas fa-play'],
    'telegram' => ['Telegram', '#0088cc', 'fab fa-telegram-plane']
];

if (!array_key_exists($platform, $plats)) {
    header("Location: index.php");
    exit;
}

$UNIFIED_API_KEY = "7BF8557C-CBE6427B-A8AE80B5-11E4E276";
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
$redirect = $protocol . "://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['SCRIPT_NAME']) . "/index.php?auth_success=" . $platform;

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://api.ayrshare.com/api/providers/oauth/init?provider=$platform&redirect=" . urlencode($redirect));
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Bearer ' . $UNIFIED_API_KEY]);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode == 200) {
    $data = json_decode($response, true);
    if (isset($data['url'])) {
        header("Location: " . $data['url']);
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $plats[$platform][0] ?> ile Bağlan · Ossiqn</title>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;800&display=swap" rel="stylesheet">
<style>
body { background: #050505; color: #fff; font-family: 'Outfit', sans-serif; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; }
.auth-box { background: #0f0f13; border: 1px solid rgba(255,255,255,0.1); border-radius: 24px; padding: 40px; width: 100%; max-width: 450px; text-align: center; box-shadow: 0 25px 50px rgba(0,0,0,0.8); }
.logos { display: flex; align-items: center; justify-content: center; gap: 20px; margin-bottom: 30px; }
.logo { width: 70px; height: 70px; border-radius: 20px; display: flex; align-items: center; justify-content: center; font-size: 36px; }
.logo-nexus { background: linear-gradient(135deg, #6366f1, #ec4899); box-shadow: 0 10px 25px rgba(99,102,241,0.3); }
.logo-plat { background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); color: <?= $plats[$platform][1] ?>; }
.arrows { color: rgba(255,255,255,0.2); font-size: 20px; animation: pulse 1.5s infinite; }
@keyframes pulse { 0%, 100% { opacity: 0.3; transform: scale(0.9); } 50% { opacity: 1; transform: scale(1.1); } }
h2 { font-size: 22px; margin: 0 0 10px; }
p { color: #8a8f98; font-size: 14px; margin-bottom: 30px; line-height: 1.6; }
.perms { text-align: left; background: rgba(0,0,0,0.3); border-radius: 16px; padding: 20px; margin-bottom: 30px; }
.perms div { display: flex; align-items: center; gap: 12px; margin-bottom: 12px; font-size: 13px; color: #fff; }
.perms div:last-child { margin-bottom: 0; }
.perms i { color: #10b981; font-size: 16px; }
.error-box { background: rgba(239,68,68,0.1); border: 1px solid rgba(239,68,68,0.2); border-radius: 16px; padding: 20px; margin: 20px 0; color: #ef4444; text-align: center; }
.btns { display: flex; gap: 12px; }
.btn { flex: 1; padding: 16px; border-radius: 14px; font-size: 15px; font-weight: 700; border: none; cursor: pointer; transition: 0.3s; text-decoration: none; display: inline-block; }
.btn-primary { background: linear-gradient(135deg, #6366f1, #ec4899); color: #fff; }
.btn-primary:hover { opacity: 0.9; transform: translateY(-2px); }
.btn-deny { background: rgba(255,255,255,0.05); color: #fff; border: 1px solid rgba(255,255,255,0.1); }
.btn-deny:hover { background: rgba(239,68,68,0.1); color: #ef4444; border-color: rgba(239,68,68,0.2); }
</style>
</head>
<body>
<div class="auth-box">
    <div class="logos">
        <div class="logo logo-nexus"><i class="fas fa-layer-group"></i></div>
        <div class="arrows"><i class="fas fa-exchange-alt"></i></div>
        <div class="logo logo-plat"><i class="<?= $plats[$platform][2] ?>"></i></div>
    </div>

    <?php if ($httpCode != 200): ?>
    <div class="error-box">
        <i class="fas fa-exclamation-triangle" style="font-size: 24px; margin-bottom: 10px;"></i>
        <p>Yetkilendirme sunucusuna bağlanılamadı. Lütfen daha sonra tekrar deneyin.</p>
    </div>
    <div class="btns">
        <a href="index.php" class="btn btn-deny">Geri Dön</a>
        <a href="oauth.php?platform=<?= $platform ?>" class="btn btn-primary">Tekrar Dene</a>
    </div>
    <?php else: ?>
    <h2>Ossiqn Yetki İstiyor</h2>
    <p>Ossiqn uygulaması <b><?= $plats[$platform][0] ?></b> hesabınıza erişim izni talep ediyor.</p>

    <div class="perms">
        <div><i class="fas fa-check-circle"></i> Profil bilgilerinizi okuma</div>
        <div><i class="fas fa-check-circle"></i> Adınıza içerik (video) paylaşma</div>
        <div><i class="fas fa-check-circle"></i> İstatistiklerinizi görüntüleme</div>
    </div>

    <div class="btns">
        <a href="index.php" class="btn btn-deny">İptal Et</a>
        <a href="<?= $data['url'] ?? '#' ?>" class="btn btn-primary" id="allowBtn">Uygulamaya İzin Ver</a>
    </div>
    <?php endif; ?>
</div>

<script>
document.getElementById('allowBtn')?.addEventListener('click', function(e) {
    if (this.href === '#') {
        e.preventDefault();
        return;
    }
    let btn = this;
    btn.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i> Yönlendiriliyor...';
    btn.style.pointerEvents = 'none';
});
</script>
</body>
</html>