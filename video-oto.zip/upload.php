<?php
header('Content-Type: application/json');
error_reporting(0);

$action = $_POST['action'] ?? '';

if ($action === 'upload_video') {
    if (!isset($_FILES['video']) || $_FILES['video']['error'] !== UPLOAD_ERR_OK) {
        echo json_encode(['status' => 'error', 'message' => 'Video alinamadi.']);
        exit;
    }

    $uploadDir = 'uploads/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    $extension = pathinfo($_FILES['video']['name'], PATHINFO_EXTENSION);
    $safeName = time() . '_' . bin2hex(random_bytes(8)) . '.' . $extension;
    $targetFile = $uploadDir . $safeName;

    if (move_uploaded_file($_FILES['video']['tmp_name'], $targetFile)) {
        echo json_encode([
            'status' => 'success', 
            'video_id' => $safeName
        ]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Video sunucuya kaydedilemedi.']);
    }
    exit;
}

if ($action === 'publish') {
    sleep(rand(2, 4));
    echo json_encode(['status' => 'success']);
    exit;
}

echo json_encode(['status' => 'error', 'message' => 'Gecersiz istek.']);
?>