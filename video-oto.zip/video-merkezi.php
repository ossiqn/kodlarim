<?php
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: giris.php");
    exit;
}
$me = currentUser($db);

$page_title = 'Multi-Upload Merkezi';
?>
<!DOCTYPE html>
<html lang="tr" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= sanitize($site_name) ?> · Multi-Upload Merkezi</title>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<style>
:root {
    --bg: #050505;
    --panel: #0f0f13;
    --panel-hover: #16161b;
    --border: rgba(255, 255, 255, 0.06);
    --border-hl: rgba(255, 255, 255, 0.15);
    --text-m: #ffffff;
    --text-s: #8a8f98;
    --primary: #6366f1;
    --primary-glow: rgba(99, 102, 241, 0.3);
    --accent: #ec4899;
    --success: #10b981;
    --danger: #ef4444;
    --warning: #f59e0b;
    --yt: #ff0000;
    --tk: #00f2fe;
    --ig: #e1306c;
    --fb: #1877f2;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
body { background-color: var(--bg); color: var(--text-m); font-family: 'Outfit', sans-serif; min-height: 100vh; background-image: radial-gradient(circle at 15% 50%, rgba(99, 102, 241, 0.08), transparent 25%), radial-gradient(circle at 85% 30%, rgba(236, 72, 153, 0.08), transparent 25%); }
.nav-top { padding: 20px 40px; border-bottom: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center; background: rgba(15, 15, 19, 0.8); backdrop-filter: blur(20px); position: sticky; top: 0; z-index: 100; }
.nav-brand { font-size: 20px; font-weight: 800; display: flex; align-items: center; gap: 10px; color: var(--text-m); text-decoration: none; }
.nav-brand i { color: var(--primary); }
.nav-user { display: flex; align-items: center; gap: 12px; font-size: 14px; font-weight: 600; }
.nav-user img { width: 36px; height: 36px; border-radius: 10px; }
.layout { width: 100%; max-width: 1400px; margin: 0 auto; padding: 40px; display: grid; grid-template-columns: 1fr 450px; gap: 40px; align-items: start; }
.card { background: var(--panel); border: 1px solid var(--border); border-radius: 24px; padding: 32px; margin-bottom: 24px; backdrop-filter: blur(20px); }
.card-title { font-size: 18px; font-weight: 700; margin-bottom: 20px; display: flex; align-items: center; gap: 10px; }
.card-title i { color: var(--primary); }
.dropzone { border: 2px dashed var(--border-hl); border-radius: 20px; padding: 40px 20px; text-align: center; cursor: pointer; transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1); background: rgba(255, 255, 255, 0.01); display: flex; flex-direction: column; align-items: center; justify-content: center; min-height: 250px; }
.dropzone:hover, .dropzone.dragover { border-color: var(--primary); background: rgba(99, 102, 241, 0.05); transform: scale(1.02); }
.dz-icon { width: 70px; height: 70px; border-radius: 50%; background: rgba(255, 255, 255, 0.03); display: flex; align-items: center; justify-content: center; font-size: 28px; color: var(--primary); margin-bottom: 20px; transition: all 0.3s; }
.dropzone:hover .dz-icon { background: var(--primary); color: #fff; box-shadow: 0 0 30px var(--primary-glow); }
.dz-title { font-size: 18px; font-weight: 700; margin-bottom: 8px; }
.dz-desc { color: var(--text-s); font-size: 13px; }
#file-input { display: none; }
.inp-group { margin-bottom: 20px; }
.inp-group label { display: block; font-size: 12px; font-weight: 600; color: var(--text-s); margin-bottom: 8px; text-transform: uppercase; letter-spacing: 1px; }
.inp-field { width: 100%; background: rgba(0, 0, 0, 0.2); border: 1px solid var(--border); border-radius: 14px; padding: 14px 18px; color: var(--text-m); font-family: inherit; font-size: 14px; transition: all 0.3s; }
.inp-field:focus { outline: none; border-color: var(--primary); background: rgba(99, 102, 241, 0.02); }
textarea.inp-field { min-height: 120px; resize: none; }
.edit-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.acc-list { display: flex; flex-direction: column; gap: 12px; margin-bottom: 24px; }
.acc-item { display: flex; align-items: center; justify-content: space-between; padding: 16px; background: rgba(0, 0, 0, 0.2); border: 1px solid var(--border); border-radius: 14px; }
.acc-info { display: flex; align-items: center; gap: 12px; font-weight: 600; font-size: 14px; }
.acc-info i { font-size: 20px; }
.acc-btn { padding: 8px 16px; border-radius: 10px; font-size: 12px; font-weight: 700; cursor: pointer; border: none; transition: 0.3s; font-family: inherit; }
.btn-connect { background: rgba(99, 102, 241, 0.1); color: var(--primary); border: 1px solid rgba(99, 102, 241, 0.2); }
.btn-connect:hover { background: rgba(99, 102, 241, 0.2); }
.btn-active { background: rgba(16, 185, 129, 0.1); color: var(--success); border: 1px solid rgba(16, 185, 129, 0.2); }
.plat-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; }
.plat-card { position: relative; background: rgba(0, 0, 0, 0.2); border: 1px solid var(--border); border-radius: 14px; padding: 16px; cursor: pointer; display: flex; align-items: center; gap: 12px; transition: all 0.3s; opacity: 0.5; pointer-events: none; }
.plat-card.linked { opacity: 1; pointer-events: auto; }
.plat-card input { position: absolute; opacity: 0; }
.p-icon { font-size: 20px; color: var(--text-s); }
.p-name { font-size: 14px; font-weight: 600; color: var(--text-s); flex: 1; }
.p-check { width: 20px; height: 20px; border-radius: 50%; border: 2px solid var(--border-hl); display: flex; align-items: center; justify-content: center; font-size: 10px; color: transparent; }
.plat-card:has(input:checked) { background: var(--panel-hover); border-color: var(--border-hl); transform: translateY(-2px); }
.plat-card:has(input:checked) .p-name { color: var(--text-m); }
.plat-card:has(input:checked) .p-check { background: var(--success); border-color: var(--success); color: #fff; }
.plat-card:has(input[value="youtube"]:checked) { border-color: var(--yt); }
.plat-card:has(input[value="youtube"]:checked) .p-icon { color: var(--yt); }
.plat-card:has(input[value="tiktok"]:checked) { border-color: var(--tk); }
.plat-card:has(input[value="tiktok"]:checked) .p-icon { color: var(--tk); }
.plat-card:has(input[value="instagram"]:checked) { border-color: var(--ig); }
.plat-card:has(input[value="instagram"]:checked) .p-icon { color: var(--ig); }
.btn-submit { width: 100%; background: linear-gradient(135deg, var(--primary), var(--accent)); color: #fff; border: none; border-radius: 14px; padding: 18px; font-size: 15px; font-weight: 700; font-family: inherit; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 10px; margin-top: 24px; transition: all 0.3s; }
.btn-submit:hover { transform: translateY(-2px); box-shadow: 0 15px 30px rgba(99, 102, 241, 0.3); }
.overlay { position: fixed; inset: 0; background: rgba(0, 0, 0, 0.8); backdrop-filter: blur(15px); display: flex; align-items: center; justify-content: center; z-index: 1000; opacity: 0; pointer-events: none; transition: opacity 0.4s; }
.overlay.active { opacity: 1; pointer-events: auto; }
.modal { width: 100%; max-width: 450px; background: var(--panel); border: 1px solid var(--border); border-radius: 28px; padding: 32px; transform: translateY(30px); transition: all 0.4s; box-shadow: 0 40px 80px rgba(0,0,0,0.8); }
.overlay.active .modal { transform: translateY(0); }
.m-title { font-size: 20px; font-weight: 800; text-align: center; margin-bottom: 24px; }
.m-step { display: flex; align-items: center; justify-content: space-between; padding: 14px 18px; background: rgba(0,0,0,0.3); border: 1px solid var(--border); border-radius: 14px; margin-bottom: 10px; }
.ms-l { display: flex; align-items: center; gap: 12px; font-weight: 600; font-size: 14px; }
.ms-r { font-size: 12px; font-weight: 700; padding: 6px 10px; border-radius: 8px; background: var(--border); color: var(--text-s); }
.ms-r.spin { background: rgba(99, 102, 241, 0.1); color: var(--primary); border: 1px solid rgba(99, 102, 241, 0.2); }
.ms-r.done { background: rgba(16, 185, 129, 0.1); color: var(--success); border: 1px solid rgba(16, 185, 129, 0.2); }
.ms-r.err { background: rgba(239, 68, 68, 0.1); color: var(--danger); border: 1px solid rgba(239, 68, 68, 0.2); }
.swal2-popup { background: var(--panel) !important; color: var(--text-m) !important; border: 1px solid var(--border) !important; border-radius: 24px !important; font-family: 'Outfit', sans-serif !important; }
.swal2-title { font-weight: 800 !important; }
@media (max-width: 1024px) { .layout { grid-template-columns: 1fr; } }
@media (max-width: 600px) { .plat-grid, .edit-grid { grid-template-columns: 1fr; } .layout { padding: 20px; } }
</style>
</head>
<body>

<header class="nav-top">
    <a href="index.php" class="nav-brand"><i class="fas fa-layer-group"></i> Nexus</a>
    <div class="nav-user">
        <span><?= sanitize($me['username']) ?></span>
        <img src="https://mc-heads.net/avatar/<?= sanitize($me['mc_username'] ?? $me['username']) ?>/36" alt="">
    </div>
</header>

<div class="layout">
    <div class="left-col">
        <form id="upload-form">
            <div class="card" style="padding: 0; overflow: hidden; border-radius: 24px;">
                <label class="dropzone" id="dz" for="file-input">
                    <div class="dz-icon" id="dz-ic"><i class="fas fa-cloud-upload-alt"></i></div>
                    <div class="dz-title" id="dz-title">Videoyu Buraya Bırakın</div>
                    <div class="dz-desc" id="dz-desc">MP4, MOV (Maksimum 100MB)</div>
                </label>
                <input type="file" id="file-input" name="video" accept="video/mp4,video/quicktime" required>
            </div>

            <div class="card">
                <div class="card-title"><i class="fas fa-sliders-h"></i> Video Düzenleme (Sanal)</div>
                <div class="edit-grid">
                    <div class="inp-group">
                        <label>Format</label>
                        <select name="aspect_ratio" class="inp-field">
                            <option value="original">Orijinal Boyut (Dokunma)</option>
                            <option value="9:16">Dikey (9:16 - Reels/Shorts)</option>
                            <option value="16:9">Yatay (16:9 - YouTube)</option>
                            <option value="1:1">Kare (1:1 - Instagram Feed)</option>
                        </select>
                    </div>
                    <div class="inp-group">
                        <label>Video Kesme</label>
                        <div style="display:flex;gap:10px;">
                            <input type="text" name="trim_start" class="inp-field" placeholder="00:00" style="text-align:center">
                            <input type="text" name="trim_end" class="inp-field" placeholder="Bitiş" style="text-align:center">
                        </div>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-title"><i class="fas fa-pen-nib"></i> İçerik Detayları</div>
                <div class="inp-group">
                    <label>Video Başlığı</label>
                    <input type="text" name="title" class="inp-field" placeholder="Dikkat çekici bir başlık..." required>
                </div>
                <div class="inp-group" style="margin: 0;">
                    <label>Açıklama & Hashtagler</label>
                    <textarea name="description" class="inp-field" placeholder="Videonuzun açıklaması..." required></textarea>
                </div>
            </div>
    </div>

    <div class="right-col">
        <div class="card">
            <div class="card-title"><i class="fas fa-link"></i> Hesap Bağlantıları</div>
            <div class="acc-list">
                <div class="acc-item">
                    <div class="acc-info"><i class="fab fa-youtube" style="color:var(--yt)"></i> YouTube</div>
                    <button type="button" class="acc-btn btn-connect" onclick="simOAuth('youtube')">Bağlan</button>
                </div>
                <div class="acc-item">
                    <div class="acc-info"><i class="fab fa-tiktok" style="color:var(--tk)"></i> TikTok</div>
                    <button type="button" class="acc-btn btn-connect" onclick="simOAuth('tiktok')">Bağlan</button>
                </div>
                <div class="acc-item">
                    <div class="acc-info"><i class="fab fa-instagram" style="color:var(--ig)"></i> Instagram</div>
                    <button type="button" class="acc-btn btn-connect" onclick="simOAuth('instagram')">Bağlan</button>
                </div>
            </div>
            
            <div class="inp-group" style="margin-top: 32px; margin-bottom: 0;">
                <label>Hedefleri Seç</label>
                <div class="plat-grid">
                    <label class="plat-card" id="pc-youtube">
                        <input type="checkbox" name="platforms[]" value="youtube">
                        <i class="fab fa-youtube p-icon"></i><span class="p-name">YouTube</span><div class="p-check"><i class="fas fa-check"></i></div>
                    </label>
                    <label class="plat-card" id="pc-tiktok">
                        <input type="checkbox" name="platforms[]" value="tiktok">
                        <i class="fab fa-tiktok p-icon"></i><span class="p-name">TikTok</span><div class="p-check"><i class="fas fa-check"></i></div>
                    </label>
                    <label class="plat-card" id="pc-instagram">
                        <input type="checkbox" name="platforms[]" value="instagram">
                        <i class="fab fa-instagram p-icon"></i><span class="p-name">Instagram</span><div class="p-check"><i class="fas fa-check"></i></div>
                    </label>
                </div>
            </div>

            <button type="submit" class="btn-submit">
                <span>İşlemi Başlat</span>
                <i class="fas fa-rocket"></i>
            </button>
        </div>
        </form>
    </div>
</div>

<div class="overlay" id="overlay">
    <div class="modal">
        <div class="m-title">Sistem İşliyor</div>
        <div id="step-list"></div>
        <button class="btn-submit" id="btn-done" style="display: none; background: var(--success); box-shadow: 0 15px 30px rgba(16, 185, 129, 0.2);" onclick="location.reload()">
            Yeni İşlem
        </button>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
let linkedAccounts = [];

function simOAuth(platform) {
    Swal.fire({
        title: 'Bağlantı Kuruluyor',
        html: `Lütfen bekleyin, <b>${platform.toUpperCase()}</b> API servisine yönlendiriliyorsunuz...`,
        allowOutsideClick: false,
        didOpen: () => { Swal.showLoading(); },
        timer: 1500
    }).then(() => {
        Swal.fire({
            icon: 'success',
            title: 'Bağlantı Başarılı!',
            text: `${platform.toUpperCase()} hesabınız başarıyla eklendi.`,
            confirmButtonColor: '#6366f1'
        });
        
        const btn = document.querySelector(`button[onclick="simOAuth('${platform}')"]`);
        btn.className = 'acc-btn btn-active';
        btn.innerHTML = '<i class="fas fa-check"></i> Bağlı';
        btn.onclick = null;
        
        const card = document.getElementById(`pc-${platform}`);
        card.classList.add('linked');
        card.querySelector('input').checked = true;
        linkedAccounts.push(platform);
    });
}

const dz = document.getElementById('dz');
const fi = document.getElementById('file-input');
const dt = document.getElementById('dz-title');
const dd = document.getElementById('dz-desc');
const di = document.getElementById('dz-ic');

['dragenter', 'dragover', 'dragleave', 'drop'].forEach(e => { dz.addEventListener(e, preventDefaults, false); });
function preventDefaults(e) { e.preventDefault(); e.stopPropagation(); }
['dragenter', 'dragover'].forEach(e => { dz.addEventListener(e, () => dz.classList.add('dragover'), false); });
['dragleave', 'drop'].forEach(e => { dz.addEventListener(e, () => dz.classList.remove('dragover'), false); });

dz.addEventListener('drop', (e) => {
    fi.files = e.dataTransfer.files;
    updateFileUI(fi.files[0]);
});

fi.addEventListener('change', function() {
    if(this.files[0]) updateFileUI(this.files[0]);
});

function updateFileUI(file) {
    dt.innerText = file.name;
    let mb = (file.size / (1024*1024)).toFixed(2);
    dd.innerText = mb + ' MB Hazır';
    di.innerHTML = '<i class="fas fa-video"></i>';
    dz.style.borderColor = 'var(--success)';
    di.style.background = 'var(--success)';
    di.style.color = '#fff';
    di.style.boxShadow = '0 0 30px rgba(16, 185, 129, 0.3)';
}

document.getElementById('upload-form').addEventListener('submit', function(e) {
    e.preventDefault();
    
    let plats = Array.from(document.querySelectorAll('input[name="platforms[]"]:checked')).map(c => c.value);
    
    if(plats.length === 0) {
        Swal.fire({icon: 'warning', title: 'Uyarı', text: 'Lütfen önce hesap bağlayın ve hedef seçin.', confirmButtonColor: '#6366f1'});
        return;
    }
    
    let fd = new FormData(this);
    fd.append('action', 'upload_video');
    
    document.getElementById('overlay').classList.add('active');
    
    let sl = document.getElementById('step-list');
    sl.innerHTML = `
        <div class="m-step">
            <div class="ms-l"><i class="fas fa-server" style="color:var(--primary)"></i> Sunucuya Yükleniyor (<span id="up-pct">0%</span>)</div>
            <div class="ms-r spin" id="st-main"><i class="fas fa-circle-notch fa-spin"></i> Devam Ediyor</div>
        </div>
    `;
    
    plats.forEach(p => {
        let n = p.charAt(0).toUpperCase() + p.slice(1);
        let ic = p === 'youtube' ? 'fab fa-youtube' : (p === 'tiktok' ? 'fab fa-tiktok' : 'fab fa-instagram');
        let col = `var(--${p === 'youtube' ? 'yt' : (p === 'tiktok' ? 'tk' : 'ig')})`;
        sl.innerHTML += `
            <div class="m-step">
                <div class="ms-l"><i class="${ic}" style="color:${col}"></i> ${n} İşlemi</div>
                <div class="ms-r" id="st-${p}"><i class="fas fa-clock"></i> Bekliyor</div>
            </div>
        `;
    });

    let xhr = new XMLHttpRequest();
    xhr.open('POST', 'video_api.php', true);
    
    xhr.upload.onprogress = function(e) {
        if (e.lengthComputable) {
            document.getElementById('up-pct').innerText = Math.round((e.loaded / e.total) * 100) + '%';
        }
    };
    
    xhr.onload = function() {
        if (xhr.status === 200) {
            try {
                let res = JSON.parse(xhr.responseText);
                if(res.status === 'success') {
                    document.getElementById('st-main').className = 'ms-r done';
                    document.getElementById('st-main').innerHTML = '<i class="fas fa-check"></i> Tamamlandı';
                    distribute(plats, res.video_id, 0);
                } else {
                    document.getElementById('overlay').classList.remove('active');
                    Swal.fire({icon: 'error', title: 'Hata', text: res.message || 'Geçersiz İstek', confirmButtonColor: '#ef4444'});
                }
            } catch(err) {
                document.getElementById('overlay').classList.remove('active');
                Swal.fire({icon: 'error', title: 'Hata', text: 'Sunucu yanıtı hatalı veya video çok büyük (Geçersiz istek).', confirmButtonColor: '#ef4444'});
            }
        }
    };
    
    xhr.onerror = function() {
        document.getElementById('overlay').classList.remove('active');
        Swal.fire({icon: 'error', title: 'Hata', text: 'Bağlantı koptu.', confirmButtonColor: '#ef4444'});
    };
    
    xhr.send(fd);
});

function distribute(plats, vid, i) {
    if(i >= plats.length) {
        document.getElementById('btn-done').style.display = 'flex';
        return;
    }
    
    let p = plats[i];
    let st = document.getElementById('st-' + p);
    st.className = 'ms-r spin';
    st.innerHTML = '<i class="fas fa-cog fa-spin"></i> İşleniyor ve Gönderiliyor';
    
    let title = document.querySelector('input[name="title"]').value;
    let desc = document.querySelector('textarea[name="description"]').value;
    
    let formData = new FormData();
    formData.append('action', 'publish');
    formData.append('platform', p);
    formData.append('video_id', vid);
    formData.append('title', title);
    formData.append('description', desc);
    
    fetch('video_api.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if(data.status === 'success') {
            st.className = 'ms-r done';
            st.innerHTML = '<i class="fas fa-check"></i> Onaylandı';
        } else {
            st.className = 'ms-r err';
            st.innerHTML = '<i class="fas fa-times"></i> Hata';
        }
        distribute(plats, vid, i + 1);
    })
    .catch(error => {
        st.className = 'ms-r err';
        st.innerHTML = '<i class="fas fa-wifi"></i> Bağlantı Hatası';
        distribute(plats, vid, i + 1);
    });
}
</script>
</body>
</html>