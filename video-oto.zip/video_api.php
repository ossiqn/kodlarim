<?php
session_start();
require_once 'config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Oturum bulunamadı.']);
    exit;
}

$user_id = $_SESSION['user_id'];
$action = isset($_POST['action']) ? $_POST['action'] : '';

if (empty($action)) {
    echo json_encode(['status' => 'error', 'message' => 'Aksiyon belirtilmedi.']);
    exit;
}

if ($action === 'disconnect') {
    $platform = isset($_POST['platform']) ? $_POST['platform'] : '';
    
    if (empty($platform)) {
        echo json_encode(['status' => 'error', 'message' => 'Platform belirtilmedi.']);
        exit;
    }
    
    try {
        $stmt = $db->prepare("DELETE FROM user_social_tokens WHERE user_id = ? AND platform = ?");
        $stmt->execute([$user_id, $platform]);
        echo json_encode(['status' => 'success', 'message' => 'Bağlantı kesildi.']);
    } catch(Exception $e) {
        echo json_encode(['status' => 'error', 'message' => 'Veritabanı hatası.']);
    }
    exit;
}

if ($action === 'save_token') {
    $platform = isset($_POST['platform']) ? $_POST['platform'] : '';
    $token = isset($_POST['token']) ? $_POST['token'] : '';
    
    if (empty($platform) || empty($token)) {
        echo json_encode(['status' => 'error', 'message' => 'Platform veya token eksik.']);
        exit;
    }
    
    try {
        $stmt = $db->prepare("INSERT INTO user_social_tokens (user_id, platform, access_token) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE access_token = ?");
        $stmt->execute([$user_id, $platform, $token, $token]);
        echo json_encode(['status' => 'success', 'message' => 'Token kaydedildi.']);
    } catch(Exception $e) {
        echo json_encode(['status' => 'error', 'message' => 'Kaydedilemedi.']);
    }
    exit;
}

echo json_encode(['status' => 'error', 'message' => 'Bilinmeyen aksiyon: ' . $action]);
?>